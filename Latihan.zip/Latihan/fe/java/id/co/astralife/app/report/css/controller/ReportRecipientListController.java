package id.co.astralife.app.report.css.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.controller.MainController;
import id.co.astralife.app.report.common.util.CryptoService;
import id.co.astralife.app.report.css.service.ReportRecipientListService;
import id.co.astralife.app.report.local.entity.CssDeliveryRecipientRelationship;
import id.co.astralife.app.report.local.entity.CssReportRecipient;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.nio.file.Files;
import java.util.*;

@Controller
@RequestMapping(value = "/admin/css_report_management/scheduler/report_recipient_list")
public class ReportRecipientListController extends MainController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReportRecipientListController.class);
    private static final String recipientListTitle = "Report Recipient List";
    private static final String recipientPage = "admin/css_report_management/scheduler/report_recipient_list";
    private static final String recipientPageRedirect = "redirect:/admin/css_report_management/scheduler/report_recipient_list";

    @Autowired
    private ReportRecipientListService reportRecipientService;

    @Autowired
    private CryptoService cryptoService;

    @Autowired
    private Environment env;

    @RequestMapping(method = RequestMethod.GET)
    private String recipientListPage(Model model) {
        List<CssReportRecipient> cssReportRecipientList = reportRecipientService.findAllRecipient();
        model.addAttribute("cssReportRecipientsList", cssReportRecipientList);
        model.addAttribute(ReportConstant.PAGE_TITLE, recipientListTitle);
        model.addAttribute("recipientPage", recipientPage);
        return "css_report_management/scheduler/report_recipient_list";
    }

    @RequestMapping(value = "/delete/{cssRecipientId}", method = RequestMethod.GET)
    private String deleteRecipient(@PathVariable("cssRecipientId") UUID cssRecipientId) {
        CssReportRecipient cssReportRecipient = reportRecipientService.findRecipientByCssRecipientID(cssRecipientId);
        List<CssDeliveryRecipientRelationship> cssDeliveryRecipientRelationshipList = reportRecipientService.findByCssRecipientId(cssRecipientId);
        if (cssDeliveryRecipientRelationshipList != null && !cssDeliveryRecipientRelationshipList.isEmpty()) {
            reportRecipientService.deleteDeliveryRecipientRel(cssDeliveryRecipientRelationshipList);
        }
        reportRecipientService.deleteRecipient(cssReportRecipient);
        return recipientPageRedirect;
    }

    @RequestMapping(value = "/create", method = RequestMethod.GET)
    private String createRecipientForm(Model model) {
        model.addAttribute(ReportConstant.PAGE_TITLE, "Create Report Recipient");
        model.addAttribute("recipientPage", recipientPage);
        return "css_report_management/scheduler/report_recipient_list/create";
    }

    @RequestMapping(value = "/createRecipient", method = RequestMethod.POST)
    private String createRecipient(HttpServletRequest request, CssReportRecipient cssReportRecipient) {
        Map<String, String[]> getParams = request.getParameterMap();
        Map<String, String> setParams = new HashMap<>();

        for (Map.Entry<String, String[]> paramRequest : getParams.entrySet()) {
            String key = paramRequest.getKey();
            String keyValue = getParams.get(key)[0];
            setParams.put(key, keyValue);
        }

        try {
            String typeAddress = setParams.get("typeAddress");
            Map<String, Object> map = new HashMap<>();
            ObjectMapper mapper = new ObjectMapper();
            if (setParams.get("excelReadonly") == null) {
                map.put("excelReadonly", "false");
            } else {
                map.put("excelReadonly", setParams.get("excelReadonly"));
            }
            if (typeAddress.equals("sftp:")) {
                map.put("ip", setParams.get("ip"));
                map.put("username", setParams.get("username"));
                map.put("sftpPassword", setParams.get("confirmPassword"));
                map.put("port", setParams.get("port"));
                map.put("folder", setParams.get("folder"));
                map.put("public key", setParams.get("publicKey"));
                map.put("excelPassword", setParams.get("confirmExcelPasswordSftp"));
                SortedMap<String, Object> sortedMap = new TreeMap<>(map);
                String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(sortedMap);
                cssReportRecipient.setCssRecipientAddress(typeAddress + json);
                cssReportRecipient.setCssRecipientName(setParams.get("cssRecipientName"));
                reportRecipientService.save(cssReportRecipient);
            } else if (typeAddress.equals("email:")) {
                map.put("excelPassword", setParams.get("confirmExcelPasswordEmail"));
                map.put("to", setParams.get("cssRecipientAddressTo"));
                map.put("cc", setParams.get("cssRecipientAddressCc"));
                map.put("subject", setParams.get("cssSubjectEmail"));
                map.put("content", setParams.get("cssRecipientContent"));
                SortedMap<String, Object> sortedMap = new TreeMap<>(map);
                String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(sortedMap);
                cssReportRecipient.setCssRecipientAddress(typeAddress + json);
                cssReportRecipient.setCssRecipientName(setParams.get("cssRecipientName"));
                reportRecipientService.save(cssReportRecipient);
            }
        } catch (Exception e) {
            LOGGER.error("ERROR When Saving Recipient: \r\n" + e.getMessage(), e);
        }
        return recipientPageRedirect;
    }

    @RequestMapping(value = "/edit", method = RequestMethod.GET)
    private String editRecipientForm(@RequestParam(value = "cssRecipientId") UUID cssRecipientId, Model model) {
        CssReportRecipient cssReportRecipient = reportRecipientService.findRecipientByCssRecipientID(cssRecipientId);

        try {
            File privateKeyFile = new File(env.getProperty("css.privateKey"));
            byte[] privateKeyByte = Files.readAllBytes(privateKeyFile.toPath());
            String privateKeyString = new String(privateKeyByte);
            byte[] decrypted = cryptoService.decrypt(new Base64().decode(cssReportRecipient.getCssRecipientAddress()), privateKeyString, env.getProperty("css.passPhrase"));
            String recipientAddressPlain = new String(decrypted);
            cssReportRecipient.setCssRecipientAddress(recipientAddressPlain);
        } catch (Exception e) {
            LOGGER.error("ERROR when decrypting\r\n" + e.getMessage(), e);
        }

        model.addAttribute("cssReportRecipient", cssReportRecipient);
        return "css_report_management/scheduler/report_recipient_list/edit";
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    private String updateRecipient(CssReportRecipient cssReportRecipient) {
        reportRecipientService.save(cssReportRecipient);
        return recipientPageRedirect;
    }

    @RequestMapping(value = "/detail", method = RequestMethod.GET)
    private String detailRecipientForm(@RequestParam(value = "cssRecipientId") UUID cssRecipientId, Model model) {
        CssReportRecipient cssReportRecipient = reportRecipientService.findRecipientByCssRecipientID(cssRecipientId);
        try {
            File privateKeyFile = new File(env.getProperty("css.privateKey"));
            byte[] privateKeyByte = Files.readAllBytes(privateKeyFile.toPath());
            String privateKeyString = new String(privateKeyByte);
            byte[] decrypted = cryptoService.decrypt(new Base64().decode(cssReportRecipient.getCssRecipientAddress()), privateKeyString, env.getProperty("css.passPhrase"));
            String recipientAddressPlain = new String(decrypted);
            cssReportRecipient.setCssRecipientAddress(recipientAddressPlain);
            if (cssReportRecipient.getCssRecipientAddress().startsWith("email:")) {
                String emailJson = cssReportRecipient.getCssRecipientAddress().substring(6);
                final ObjectNode objectNode = new ObjectMapper().readValue(emailJson, ObjectNode.class);
                JsonNode ccJson = objectNode.get("cc");
                JsonNode excelPasswordJson = objectNode.get("excelPassword");
                JsonNode excelReadOnlyJson = objectNode.get("excelReadonly");
                JsonNode toJson = objectNode.get("to");
                JsonNode subjectJson = objectNode.get("subject");
                JsonNode contentJson = objectNode.get("content");
                model.addAttribute("email", cssReportRecipient.getCssRecipientAddress().substring(0, 5));
                model.addAttribute("cc", ccJson.asText());
                model.addAttribute("excelPassword", excelPasswordJson.asText());
                model.addAttribute("excelReadonly", excelReadOnlyJson.asText());
                model.addAttribute("to", toJson.asText());
                model.addAttribute("subject", subjectJson.asText());
                model.addAttribute("content", contentJson.asText());
            } else {
                String sftpJson = cssReportRecipient.getCssRecipientAddress().substring(5);
                final ObjectNode objectNode = new ObjectMapper().readValue(sftpJson, ObjectNode.class);
                JsonNode excelPasswordJson = objectNode.get("excelPassword");
                JsonNode excelReadOnlyJson = objectNode.get("excelReadonly");
                JsonNode folderJson = objectNode.get("folder");
                JsonNode ipJson = objectNode.get("ip");
                JsonNode sftpPasswordJson = objectNode.get("password");
                JsonNode usernameJson = objectNode.get("username");
                JsonNode portJson = objectNode.get("port");
                JsonNode publicKeyJson = objectNode.get("public key");
                model.addAttribute("sftp", cssReportRecipient.getCssRecipientAddress().substring(0, 4));
                model.addAttribute("excelPassword", excelPasswordJson.asText());
                model.addAttribute("excelReadonly", excelReadOnlyJson.asText());
                model.addAttribute("folder", folderJson.asText());
                model.addAttribute("ip", ipJson.asText());
                model.addAttribute("sftpPassword", sftpPasswordJson.asText());
                model.addAttribute("username", usernameJson.asText());
                model.addAttribute("port", portJson.asText());
                model.addAttribute("publicKey", publicKeyJson.asText());
            }
            model.addAttribute("cssReportRecipient", cssReportRecipient);
        } catch (Exception e) {
            LOGGER.error("ERROR when decrypting\r\n" + e.getMessage(), e);
        }
        return "css_report_management/scheduler/report_recipient_list/detail";
    }
}
