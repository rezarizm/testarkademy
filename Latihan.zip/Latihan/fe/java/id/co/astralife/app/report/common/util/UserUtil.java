package id.co.astralife.app.report.common.util;

import org.springframework.security.core.context.SecurityContextHolder;

public class UserUtil {
	
	private UserUtil(){		
	}
	
	public static String getCurrentUsername() {
		return SecurityContextHolder.getContext().getAuthentication().getName().toLowerCase();
	}
}
