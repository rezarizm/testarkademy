package id.co.astralife.app.report.css.service;

import id.co.astralife.app.report.local.entity.CssReportCategory;

import java.util.List;

public interface ReportCategoryListService {
    List<CssReportCategory> findAllReportCategory();

    CssReportCategory save (CssReportCategory cssReportCategory);

    CssReportCategory findCssReportCategoryByCssCategoryId(String cssCategoryId);

    void delete (CssReportCategory cssReportCategory);
}
