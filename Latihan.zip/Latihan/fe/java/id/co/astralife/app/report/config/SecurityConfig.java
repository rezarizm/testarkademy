package id.co.astralife.app.report.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.ldap.authentication.ad.ActiveDirectoryLdapAuthenticationProvider;
import org.springframework.security.web.authentication.rememberme.AbstractRememberMeServices;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;

import javax.sql.DataSource;

/**
 * @author fadil.wiranata
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final int TOKEN_VALIDITY_SECONDS = 60 * 60 * 24;
    private final String APPLICATION_SECURITY_KEY = "iSeeYou";

    @Autowired
    @Qualifier(value = "customContextMapper")
    private CustomUserDetailsContextMapper userDetailsContextMapper;

    @Autowired
    @Qualifier(value = "authenticationRememberMe")
    private UserDetailsService userDetailsService;

    @Autowired
    private DataSource dataSource;

    @Value("${spring.ldap.url}")
    private String ldapUrl;

    @Autowired
    protected void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(activeDirectoryLdapAuthenticationProvider());
    }
    
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .headers()
                    .cacheControl();
        http
                .sessionManagement()
                    .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
                    .sessionFixation().none()
                .and()
                .authorizeRequests()
                    .antMatchers("/error", "/resources/**").permitAll()
                    .antMatchers("/admin/**").hasRole("ADM")
                    .anyRequest().authenticated()
                .and()
                .formLogin()
                    .loginPage("/login").permitAll()
                    .defaultSuccessUrl("/")
                .and()
                .exceptionHandling()
                    .accessDeniedPage("/login?denied")
                .and()
                .logout()
                    .logoutSuccessUrl("/login?logout")
                    .invalidateHttpSession(true)
                    .deleteCookies("JSESSIONID", AbstractRememberMeServices.SPRING_SECURITY_REMEMBER_ME_COOKIE_KEY)
                .and()
                    .rememberMe().key(this.APPLICATION_SECURITY_KEY)
                    .rememberMeServices(rememberMeServices())
        ;
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/resources/**");
    }

    @Bean
    protected PersistentTokenRepository jdbcTokenRepository() {
        JdbcTokenRepositoryImpl jdbcTokenRepository = new JdbcTokenRepositoryImpl();
        jdbcTokenRepository.setCreateTableOnStartup(false);
        jdbcTokenRepository.setDataSource(dataSource);
        return jdbcTokenRepository;
    }

    @Bean
    protected AbstractRememberMeServices rememberMeServices() {
        PersistentTokenBasedRememberMeServices services = new PersistentTokenBasedRememberMeServices(this.APPLICATION_SECURITY_KEY, userDetailsService, jdbcTokenRepository());
        services.setAlwaysRemember(false);
        services.setParameter("remember-me");
        services.setCookieName("remember-me-rptsys");
        services.setTokenValiditySeconds(this.TOKEN_VALIDITY_SECONDS);
        return services;
    }

    
    /*@Override
    protected void configure(AuthenticationManagerBuilder auth)
            throws Exception {
        auth
             .inMemoryAuthentication()
                  .withUser("admin")
                       .password("admin")
                       .roles("ADM","OPS","USR")
                       .and()
                  .withUser("adminr")
                       .password("password")
                       .roles("ADMIN","USER")
                       .and()
                   .withUser("adminf")
                        .password("adminf")
                        .roles("FIN");
    }*/
	

   @Bean
    protected AuthenticationProvider activeDirectoryLdapAuthenticationProvider() {
        ActiveDirectoryLdapAuthenticationProvider authenticationProvider = new ActiveDirectoryLdapAuthenticationProvider("AVIVAID.local", ldapUrl);
        authenticationProvider.setConvertSubErrorCodesToExceptions(true);
        authenticationProvider.setUseAuthenticationRequestCredentials(true);
        authenticationProvider.setUserDetailsContextMapper(userDetailsContextMapper);
        return authenticationProvider;
    }
}
