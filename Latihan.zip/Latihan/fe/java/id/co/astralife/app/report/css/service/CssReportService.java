package id.co.astralife.app.report.css.service;

import id.co.astralife.app.report.local.entity.*;

import java.util.List;
import java.util.UUID;

public interface CssReportService {
    List<CssReportFileGroupAndTemplateRelationship> getTemplatesByFileGroupId(String fileGroupId);

    List<CssReportFileGroupRptRoleRelationship> getFileGroupIdByRoleId(UUID roleId);

    List<CssReportFileGroupRptRoleRelationship> getFileGroupIdByCategoryIdAndRoleId(String categoryId, UUID roleId);

    List<CssReportTargetDropdown> findAllDropdown();

    CssReportCategory findCssReportCategoryByCssCategoryId(String cssCategoryId);

    CssReportFileGroup findCssReportFileGroupByCssFileGroupId(String fileGroupId);

    CssReportTemplate findCssReportTemplateByCssTemplateId(String cssTemplateId);

    CssReportCategoryFileGroupRelationship getCategoryIdByCssFileGroupId(String cssFileGroupId);

    CssReportFileGroupRptRoleRelationship findFileGroupByIdRel(UUID idRel);
}
