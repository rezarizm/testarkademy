package id.co.astralife.app.report.css.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import id.co.astralife.app.report.common.controller.MainController;
import id.co.astralife.app.report.css.service.CssReportService;
import id.co.astralife.app.report.local.entity.*;
import id.co.astralife.app.report.model.FileFilterForm;
import id.co.astralife.app.report.user.service.UserRoleService;
import org.apache.commons.codec.binary.Base64;
import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping(value = "/css_report")
public class CssReportController extends MainController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CssReportController.class);
    private static final String CONTENT_TYPE = "application/json";
    private static final String CONTENT_DISPOSITION = "Content-Disposition";
    private static final String ATTACH_VALUE = "attachment; filename = \"";
    private static final String FILE_TITLE = "CSS Report";

    @Autowired
    private UserRoleService userRoleService;

    @Autowired
    private CssReportService cssReportService;

    @Autowired
    private Environment env;

    @ModelAttribute(value = "fileFilterForm")
    private FileFilterForm initFileFilterForm() {
        return new FileFilterForm();
    }

    @RequestMapping(method = {RequestMethod.GET, RequestMethod.POST})
    private String filePagePost(@ModelAttribute("fileFilterForm") FileFilterForm form, Model model, HttpSession session,
                                @PageableDefault(sort = {"createDate"}, direction = Sort.Direction.DESC) Pageable pageable) {
        List<UUID> listRoleId = new ArrayList<>();
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UUID currentUserId = user.getUserId();

        List<UserRole> userRole = userRoleService.findByUserId(currentUserId);
        List<CssReportFileGroupRptRoleRelationship> listReportFileGroup = new ArrayList<>();
        UUID roleId = null;

        for (UserRole userRoles : userRole) {
            roleId = userRoles.getRoleId();
            List<CssReportFileGroupRptRoleRelationship> tmpCssReportFileGroupRptRoleRelationships = cssReportService.getFileGroupIdByRoleId(roleId);
            if (tmpCssReportFileGroupRptRoleRelationships != null && !tmpCssReportFileGroupRptRoleRelationships.isEmpty()) {
                listReportFileGroup.addAll(tmpCssReportFileGroupRptRoleRelationships);
                listRoleId.add(roleId);
            }
        }

        session.setAttribute("listRoleIdSession", listRoleId);

        String fileGroupId;
        List<CssReportCategoryFileGroupRelationship> listCategory = new ArrayList<>();
        for (CssReportFileGroupRptRoleRelationship tmpCssReportFileGroupRptRoleRelationship2 : listReportFileGroup) {
            fileGroupId = tmpCssReportFileGroupRptRoleRelationship2.getFileGroupId();
            CssReportCategoryFileGroupRelationship cssReportCategoryFileGroupRelationship = cssReportService.getCategoryIdByCssFileGroupId(fileGroupId);

            int counter = 0;
            for (CssReportCategoryFileGroupRelationship rel : listCategory) {
                if (rel.getCssCategoryId().equals(cssReportCategoryFileGroupRelationship.getCssCategoryId())) {
                    break;
                }
                counter++;
            }

            if (counter == listCategory.size()) {
                listCategory.add(cssReportCategoryFileGroupRelationship);
            }
        }

        model.addAttribute("pageTitle", FILE_TITLE);
        model.addAttribute("form", form);
        model.addAttribute("menuCategory", listCategory);
        model.addAttribute("viewName", "css_report");

        return "css_report";
    }

    @RequestMapping(value = "/getReportFileGroupAndTemplateRelationship", method = RequestMethod.GET)
    private @ResponseBody
    List<CssReportFileGroupAndTemplateRelationship> getReportFileGroupAndTemplateRelationship(@RequestParam(value = "cssGroupId") String cssFileGroupId) {
        return cssReportService.getTemplatesByFileGroupId(cssFileGroupId);
    }

    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/getFileGroup", method = RequestMethod.GET)
    private @ResponseBody
    List<CssReportFileGroupRptRoleRelationship> getFileGroup(HttpSession session, @RequestParam(value = "cssCategoryId") String categoryId) {
        List<CssReportFileGroupRptRoleRelationship> listGetFileGroup = new ArrayList<>();
        List<UUID> listRoleId = (List<UUID>) session.getAttribute("listRoleIdSession");
        for (UUID roleIdObject : listRoleId) {
            List<CssReportFileGroupRptRoleRelationship> tmpListFileGroup = cssReportService.getFileGroupIdByCategoryIdAndRoleId(categoryId, roleIdObject);
            if (tmpListFileGroup != null && !tmpListFileGroup.isEmpty()) {
                listGetFileGroup.addAll(tmpListFileGroup);
            }
        }

        List<CssReportFileGroupRptRoleRelationship> newFileGroupList = new ArrayList<>();
        for (CssReportFileGroupRptRoleRelationship fileGroupRptRoleRelationship : listGetFileGroup) {
            UUID idRel = fileGroupRptRoleRelationship.getIdRel();
            CssReportFileGroupRptRoleRelationship cssReportFileGroupRptRoleRelationship = cssReportService.findFileGroupByIdRel(idRel);
            if (cssReportFileGroupRptRoleRelationship != null) {
                int counter = 0;
                for (CssReportFileGroupRptRoleRelationship rel : newFileGroupList) {
                    if (rel.getFileGroupId().equals(cssReportFileGroupRptRoleRelationship.getFileGroupId())) {
                        break;
                    }
                    counter++;
                }

                if (counter == newFileGroupList.size()) {
                    newFileGroupList.add(cssReportFileGroupRptRoleRelationship);
                }
            }
        }

        return newFileGroupList;
    }

    @RequestMapping(value = "/generateReport", method = RequestMethod.GET)
    private void generateReport(HttpServletResponse response, HttpServletRequest request) {

        Map<String, String[]> servicesParam = new HashMap<>();
        Map<String, String[]> reportsParam = new HashMap<>();
        Map<String, String[]> paramsRequest = request.getParameterMap();

        try {
            String result = "";
            for (Map.Entry<String, String[]> paramRequest : paramsRequest.entrySet()) {
                String key = paramRequest.getKey();
                if (key.startsWith("srv_")) {
                    servicesParam.put(key.replaceAll("srv_", ""), paramRequest.getValue());
                } else {
                    reportsParam.put(key.replaceAll("rpt_", ""), paramRequest.getValue());
                }
                String keyValue = paramsRequest.get(key)[0];
                result += key + "=" + keyValue + "&";
            }
            result = result.substring(0, result.length() - 1);
            String cssReportBl = env.getProperty("blcssaddress") + "?" + result;
            URL bl = new URL(cssReportBl);
            HttpURLConnection connection = (HttpURLConnection) bl.openConnection();
            connection.setRequestProperty("Accept", CONTENT_TYPE);
            LOGGER.info("Connection Result from BL:  {}", connection.getResponseCode());
            InputStream responseInputStream = connection.getInputStream();
            String jsonResponse;
            jsonResponse = new String(IOUtils.toByteArray(responseInputStream));

            byte[] returnedResult = new byte[0];

            String responseType = servicesParam.get("responseType")[0];
            String generateType = servicesParam.get("generateType")[0];
            String categoryId = reportsParam.get("reportCategory")[0];
            String startDate = reportsParam.get("startDate")[0];
            String endDate = reportsParam.get("endDate")[0];
            final ObjectNode objectNode = new ObjectMapper().readValue(jsonResponse, ObjectNode.class);

            String uiPattern = "dd-MMMM-yyyy";
            String downloadPattern = "yyyyMMdd";
            String currentDatePattern = "yyyyMMdd'_'HHmm";
            SimpleDateFormat sdf = new SimpleDateFormat(currentDatePattern);
            String currentDate = sdf.format(new Date());
            if (startDate != null && !startDate.isEmpty()) {
                SimpleDateFormat sdfUi = new SimpleDateFormat(uiPattern);
                Date uiDate = sdfUi.parse(startDate);
                sdfUi.applyPattern(downloadPattern);
                startDate = sdfUi.format(uiDate);
            }

            if (endDate != null && !endDate.isEmpty()) {
                SimpleDateFormat sdfUi = new SimpleDateFormat(uiPattern);
                Date uiDate = sdfUi.parse(endDate);
                sdfUi.applyPattern(downloadPattern);
                endDate = sdfUi.format(uiDate);
            }

            String cssCategoryName = cssReportService.findCssReportCategoryByCssCategoryId(categoryId).getCssCategoryName();
            ServletOutputStream sos = response.getOutputStream();
            File file = null;
            if (responseType.equals("fileSystem")) {
                JsonNode fileSystemJson = objectNode.get("fileName");
                file = new File(env.getProperty("dir.pathTempFolder") + fileSystemJson.asText());

                switch (generateType) {
                    case "view":
                        response.setContentType("text/html");
                        response.setHeader(CONTENT_DISPOSITION, "inline");
                        break;
                    case "download":
                        String templateId = reportsParam.get("templateId")[0];
                        String cssTemplateName = cssReportService.findCssReportTemplateByCssTemplateId(templateId).getCssTemplateName();
                        if (cssTemplateName.startsWith("*")) {
                            cssTemplateName = cssTemplateName.substring(1);
                        }
                        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                        if (startDate != null && !startDate.isEmpty()) {
                            response.setHeader(CONTENT_DISPOSITION, ATTACH_VALUE + cssCategoryName + "_" + cssTemplateName + "_" + startDate + "-" + endDate + "_[" + currentDate + "].xlsx\"");
                        } else {
                            response.setHeader(CONTENT_DISPOSITION, ATTACH_VALUE + cssCategoryName + "_" + cssTemplateName + "_" + endDate + "_[" + currentDate + "].xlsx\"");
                        }
                        break;
                    case "downloadAll":
                        String fileGroupId = reportsParam.get("fileGroupId")[0];
                        String cssFileGroupValue = cssReportService.findCssReportFileGroupByCssFileGroupId(fileGroupId).getCssReportFileGroupName();
                        if (file.getPath().endsWith(".xlsx")) {
                            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                            if (startDate != null && !startDate.isEmpty()) {
                                response.setHeader(CONTENT_DISPOSITION, ATTACH_VALUE + cssCategoryName + "_" + cssFileGroupValue + "_" + startDate + "-" + endDate + "_[" + currentDate + "].xlsx\"");
                            } else {
                                response.setHeader(CONTENT_DISPOSITION, ATTACH_VALUE + cssCategoryName + "_" + cssFileGroupValue + "_" + endDate + "_[" + currentDate + "].xlsx\"");
                            }
                        } else if (file.getPath().endsWith(".zip")) {
                            response.setContentType("application/zip");
                            if (startDate != null && !startDate.isEmpty()) {
                                response.setHeader(CONTENT_DISPOSITION, ATTACH_VALUE + cssCategoryName + "_" + cssFileGroupValue + "_" + startDate + "-" + endDate + "_[" + currentDate + "].zip\"");
                            } else {
                                response.setHeader(CONTENT_DISPOSITION, ATTACH_VALUE + cssCategoryName + "_" + cssFileGroupValue + "_" + endDate + "_[" + currentDate + "].zip\"");
                            }
                        }
                        break;
                }

                sos.write(Files.readAllBytes(file.toPath()));
                sos.flush();
            } else if (responseType.equals("body")) {
                JsonNode bodyJson = objectNode.get("base64");
                String decoded = bodyJson.asText();
                returnedResult = new Base64().decode(decoded);
                sos.write(returnedResult);
                sos.flush();
            }
            sos.close();
            connection.disconnect();
            if (file != null) {
                Files.delete(file.toPath());
                LOGGER.info("Temporary File Deleted");
            }
            LOGGER.info("Generate Template SUCCEEDED, Generate Type: {}", generateType);
        } catch (Exception e) {
            LOGGER.error("ERROR When Generate Template: \r\n" + e.getMessage(), e);
        }
    }
}