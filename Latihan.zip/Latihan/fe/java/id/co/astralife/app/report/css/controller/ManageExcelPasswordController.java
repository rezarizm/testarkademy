package id.co.astralife.app.report.css.controller;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.controller.MainController;
import id.co.astralife.app.report.common.util.CryptoService;
import id.co.astralife.app.report.css.service.ManageExcelPasswordService;
import id.co.astralife.app.report.local.entity.CssExcelPassword;
import id.co.astralife.app.report.local.entity.CssReportRecipient;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping(value = "/admin/css_report_management/scheduler/manage_excel_password")
public class ManageExcelPasswordController extends MainController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ManageExcelPasswordController.class);
    private static final String manageExcelPasswordTitle = "Manage Excel Password";

    @Autowired
    private ManageExcelPasswordService manageExcelPasswordService;

    @Autowired
    private CryptoService cryptoService;

    @Autowired
    private Environment env;

    @RequestMapping(method = RequestMethod.GET)
    private String ManageExcelPasswordPage(Model model) {
        List<CssExcelPassword> cssExcelPasswordList = manageExcelPasswordService.findAllCssExcelPassword();
        List<String> reportRecipientNameList = new ArrayList<>();
        for (CssExcelPassword cssExcelPassword : cssExcelPasswordList) {
            try {
                File privateKeyFile = new File(env.getProperty("css.privateKey"));
                byte[] privateKeyByte = Files.readAllBytes(privateKeyFile.toPath());
                String privateKeyString = new String(privateKeyByte);
                byte[] decrypted = cryptoService.decrypt(new Base64().decode(cssExcelPassword.getPassword()), privateKeyString, env.getProperty("css.passPhrase"));
                String passwordPlain = new String(decrypted);
                cssExcelPassword.setPassword(passwordPlain);
                for (CssReportRecipient reportRecipient : manageExcelPasswordService.findAllRecipient()) {
                    if (cssExcelPassword.getCssRecipientId().equals(reportRecipient.getCssRecipientId())) {
                        reportRecipientNameList.add(reportRecipient.getCssRecipientName());
                    }
                }
            } catch (Exception e) {
                LOGGER.error("ERROR when decrypting\r\n" + e.getMessage(), e);
            }
        }
        model.addAttribute("reportRecipientNameList", reportRecipientNameList);
        model.addAttribute("excelPasswordList", cssExcelPasswordList);
        model.addAttribute("reportRecipientList", manageExcelPasswordService.findAllRecipient());
        model.addAttribute(ReportConstant.PAGE_TITLE, manageExcelPasswordTitle);
        return "css_report_management/scheduler/manage_excel_password";
    }

    @RequestMapping(value = "/create", method = RequestMethod.GET)
    private String createExcelPasswordPage(Model model) {
        model.addAttribute("reportRecipientList", manageExcelPasswordService.findAllRecipient());
        return "css_report_management/scheduler/manage_excel_password/create";
    }

    @RequestMapping(value = "/createPassword", method = RequestMethod.POST)
    private String createPassword(HttpServletRequest request, CssExcelPassword cssExcelPassword) {
        try {
            String password = request.getParameter("confirmPassword");
            cssExcelPassword.setPassword(password);
            cssExcelPassword.setCreateBy("SYSTEM");
            manageExcelPasswordService.save(cssExcelPassword);
            LOGGER.info("PASSWORD SAVED SUCCESSFULLY\r\n{}", cssExcelPassword);
        } catch (Exception e) {
            LOGGER.error("ERROR When Saving Excel Password: \r\n" + e.getMessage(), e);
        }
        return "redirect:../manage_excel_password";
    }

    @RequestMapping(value = "/deletePassword", method = RequestMethod.GET)
    private String deletePassword(@RequestParam(value = "id") UUID id) {
        CssExcelPassword cssExcelPassword = manageExcelPasswordService.findCssExcelPasswordById(id);
        manageExcelPasswordService.delete(cssExcelPassword);
        return "redirect:../manage_excel_password";
    }

    @RequestMapping(value = "/detailPassword", method = RequestMethod.GET)
    private String detailPassword(@RequestParam(value = "id") UUID id, Model model) {
        CssExcelPassword cssExcelPassword = manageExcelPasswordService.findCssExcelPasswordById(id);
        try {
            File privateKeyFile = new File(env.getProperty("css.privateKey"));
            byte[] privateKeyByte = Files.readAllBytes(privateKeyFile.toPath());
            String privateKeyString = new String(privateKeyByte);
            byte[] decrypted = cryptoService.decrypt(new Base64().decode(cssExcelPassword.getPassword()), privateKeyString, env.getProperty("css.passPhrase"));
            String passwordPlain = new String(decrypted);
            cssExcelPassword.setPassword(passwordPlain);
            UUID cssRecipientId = cssExcelPassword.getCssRecipientId();
            String recipientName = manageExcelPasswordService.findRecipientByCssRecipientId(cssRecipientId).getCssRecipientName();
            model.addAttribute("cssExcelPassword", cssExcelPassword);
            model.addAttribute("recipientName", recipientName);
        } catch (Exception e) {
            LOGGER.error("ERROR when decrypting\r\n" + e.getMessage(), e);
        }
        return "css_report_management/scheduler/manage_excel_password/detail";
    }
}
