package id.co.astralife.app.report.css.service;

import id.co.astralife.app.report.local.entity.CssReportCategory;
import id.co.astralife.app.report.local.entity.CssReportFileGroup;
import id.co.astralife.app.report.local.entity.CssReportFileGroupRoleRelationship;
import id.co.astralife.app.report.local.entity.Role;

import java.util.List;
import java.util.UUID;

public interface ReportFileGroupListService {
    List<CssReportCategory> findAllCssReportCategory();

    List<CssReportFileGroup> findAllCssReportFileGroup();

    List<Role> findAllRole();

    List<CssReportFileGroupRoleRelationship> findRolesByCssFileGroupId(String cssFileGroupId);

    CssReportFileGroup save(CssReportFileGroup cssReportFileGroup);

    CssReportFileGroup findCssReportFileGroupByCssFileGroupId(String cssFileGroupId);

    CssReportCategory findCssCategoryNameByCssCategoryId(String cssCategoryId);

    CssReportFileGroupRoleRelationship updateRoles(CssReportFileGroupRoleRelationship cssReportFileGroupRoleRelationship);

    Role findByRoleId(UUID roleId);

    void delete(CssReportFileGroup cssReportFileGroup);

    void deleteRoles(List<CssReportFileGroupRoleRelationship> cssReportFileGroupRoleRelationship);
}
