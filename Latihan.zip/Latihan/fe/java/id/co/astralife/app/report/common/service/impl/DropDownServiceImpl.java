package id.co.astralife.app.report.common.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.service.DropDownService;
import id.co.astralife.app.report.local.entity.DropDown;
import id.co.astralife.app.report.local.enumeration.DropDownGroup;
import id.co.astralife.app.report.local.repository.DropDownRepository;

@Service
public class DropDownServiceImpl implements DropDownService {

	@Autowired
	private DropDownRepository dropDownRepository;
	
	@Override
	public List<DropDown> findAllByGroup(DropDownGroup drownGroup) {
		return dropDownRepository.findAllByGroup(drownGroup);
	}

}
