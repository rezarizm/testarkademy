package id.co.astralife.app.report.css.controller;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.controller.MainController;
import id.co.astralife.app.report.common.util.CryptoService;
import id.co.astralife.app.report.css.service.ReportDeliveryListService;
import id.co.astralife.app.report.local.entity.*;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping(value = "/admin/css_report_management/scheduler/report_delivery_list")
public class ReportDeliveryListController extends MainController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReportDeliveryListController.class);
    private static final String deliveryListTitle = "Report Delivery List";
    private static final String deliveryGroupRedirect = "redirect:/admin/css_report_management/scheduler/report_delivery_list";

    @Autowired
    private ReportDeliveryListService reportDeliveryListService;

    @Autowired
    private CryptoService cryptoService;

    @Autowired
    private Environment env;

    @RequestMapping(method = RequestMethod.GET)
    private String reportDeliveryListPage(Model model) {
        List<String> cssDeliveryGroupIdList = new ArrayList<>();
        for (CssReportDeliveryGroup tmpCssReportDeliveryGroup : reportDeliveryListService.findAllDeliveryGroup()) {
            String deliveryGroupList = tmpCssReportDeliveryGroup.getCssDeliveryGroupId();
            cssDeliveryGroupIdList.add(deliveryGroupList);
        }

        model.addAttribute(ReportConstant.PAGE_TITLE, deliveryListTitle);
        model.addAttribute("cssDeliveryGroupIdList", cssDeliveryGroupIdList);
        model.addAttribute("cssReportDeliveryGroupList", reportDeliveryListService.findAllDeliveryGroup());
        return "css_report_management/scheduler/report_delivery_list";
    }

    @RequestMapping(value = "/create", method = RequestMethod.GET)
    private String createDeliveryGroupForm() {
        return "css_report_management/scheduler/report_delivery_list/create";
    }

    @RequestMapping(value = "/createDeliveryGroup", method = RequestMethod.POST)
    private String createDeliveryGroup(CssReportDeliveryGroup cssReportDeliveryGroup) {
        reportDeliveryListService.save(cssReportDeliveryGroup);
        return deliveryGroupRedirect;
    }

    @RequestMapping(value = "/edit", method = RequestMethod.GET)
    private String editDeliveryGroupForm(Model model, HttpServletRequest request) {
        String cssDeliveryGroupId = request.getParameter("reportDeliveryGroupId");
        CssReportDeliveryGroup cssReportDeliveryGroup = reportDeliveryListService.findCssReportDeliveryGroupByCssDeliveryGroupId(cssDeliveryGroupId);
        model.addAttribute("cssReportDeliveryGroup", cssReportDeliveryGroup);
        return "css_report_management/scheduler/report_delivery_list/edit";
    }

    @RequestMapping(value = "/editDeliveryGroup", method = RequestMethod.POST)
    private String editDeliveryGroup(HttpServletRequest request, CssReportDeliveryGroup cssReportDeliveryGroup) {
        reportDeliveryListService.save(cssReportDeliveryGroup);
        return deliveryGroupRedirect;
    }

    @RequestMapping(value = "/deleteDeliveryGroup/{cssDeliveryGroupId}", method = RequestMethod.GET)
    private String deleteDeliveryGroup(@PathVariable("cssDeliveryGroupId") String cssDeliveryGroupId) {
        List<CssReportDeliveryGroupTemplateRelation> deliveryGroupTemplateRelationList = reportDeliveryListService.findTemplateByCssDeliveryGroupId(cssDeliveryGroupId);
        List<CssDeliveryRecipientRelationship> deliveryRecipientRelationshipList = reportDeliveryListService.findRecipientByCssDeliveryGroupId(cssDeliveryGroupId);
        CssReportDeliveryGroup cssReportDeliveryGroup = reportDeliveryListService.findCssReportDeliveryGroupByCssDeliveryGroupId(cssDeliveryGroupId);

        if (deliveryGroupTemplateRelationList != null && !deliveryGroupTemplateRelationList.isEmpty()) {
            reportDeliveryListService.deleteDeliveryTemplateRelList(deliveryGroupTemplateRelationList);
        }

        if (deliveryRecipientRelationshipList != null && !deliveryRecipientRelationshipList.isEmpty()) {
            reportDeliveryListService.deleteDeliveryRecipientRelList(deliveryRecipientRelationshipList);
        }

        reportDeliveryListService.deleteDeliveryGroup(cssReportDeliveryGroup);
        return deliveryGroupRedirect;
    }

    @RequestMapping(value = "/addTemplates", method = RequestMethod.GET)
    private String addTemplatesPage(Model model, HttpServletRequest request) {
        String cssDeliveryGroupId = request.getParameter("deliveryGroupId");
        model.addAttribute("cssTemplateList", reportDeliveryListService.findAllCssTemplates());
        model.addAttribute("deliveryTemplateList", reportDeliveryListService.findAllByCssDeliveryGroupId(cssDeliveryGroupId));
        model.addAttribute("deliveryGroupId", cssDeliveryGroupId);
        return "css_report_management/scheduler/report_delivery_list/addTemplates";
    }

    @RequestMapping(value = "/saveTemplate", method = RequestMethod.POST)
    private String saveTemplate(HttpServletRequest request, CssReportDeliveryGroupTemplateRelation cssReportDeliveryGroupTemplateRelation) {
        String cssDeliveryGroupId = "";
        try {
            cssDeliveryGroupId = request.getParameter("cssDeliveryGroupId");
            String parameter = request.getParameter("parameter");
            cssReportDeliveryGroupTemplateRelation.setParameter(parameter);
            reportDeliveryListService.save(cssReportDeliveryGroupTemplateRelation);
            LOGGER.info("Delivery Template has been saved successfully\r\n {}", cssReportDeliveryGroupTemplateRelation);
        } catch (Exception e) {
            LOGGER.error("ERROR when saving delivery template\r\n" + e.getMessage(), e);
        }
        return "redirect:addTemplates?deliveryGroupId=" + cssDeliveryGroupId;
    }

    @RequestMapping(value = "/addRecipient", method = RequestMethod.GET)
    private String addRecipientPage(Model model, HttpServletRequest request) {
        String cssDeliveryGroupId = request.getParameter("deliveryGroupId");
        List<CssReportRecipient> cssReportRecipientList = reportDeliveryListService.findAllRecipient();
        List<CssReportDeliveryRecipientRelView> cssReportDeliveryRecipientRelViewList = reportDeliveryListService.findDeliveryRecipientByCssDeliveryGroupId(cssDeliveryGroupId);
        try {
            File privateKeyFile = new File(env.getProperty("css.privateKey"));
            byte[] privateKeyByte = Files.readAllBytes(privateKeyFile.toPath());
            String privateKeyString = new String(privateKeyByte);
            for (CssReportDeliveryRecipientRelView cssReportDeliveryRecipientRelView : cssReportDeliveryRecipientRelViewList) {
                if (cssReportDeliveryRecipientRelView != null) {
                    byte[] decrypted = cryptoService.decrypt(new Base64().decode(cssReportDeliveryRecipientRelView.getCssRecipientAddress()), privateKeyString, env.getProperty("css.passPhrase"));
                    String recipientAddressPlain = new String(decrypted);
                    cssReportDeliveryRecipientRelView.setCssRecipientAddress(recipientAddressPlain);
                }
            }
        } catch (Exception e) {
            LOGGER.error("ERROR when decrypting\r\n" + e.getMessage(), e);
        }

        model.addAttribute("recipientList", cssReportRecipientList);
        model.addAttribute("deliveryRecipientList", cssReportDeliveryRecipientRelViewList);
        model.addAttribute("deliveryGroupId", cssDeliveryGroupId);
        return "css_report_management/scheduler/report_delivery_list/addRecipient";
    }

    @RequestMapping(value = "/saveRecipient", method = RequestMethod.POST)
    private String saveRecipient(HttpServletRequest request, CssDeliveryRecipientRelationship cssDeliveryRecipientRelationship) {
        String cssDeliveryGroupId = request.getParameter("cssDeliveryGroupId");
        reportDeliveryListService.save(cssDeliveryRecipientRelationship);
        LOGGER.info("Delivery recipient relation data has been saved successfully");
        return "redirect:addRecipient?deliveryGroupId=" + cssDeliveryGroupId;
    }


    @RequestMapping(value = "/deleteDeliveryTemplate", method = RequestMethod.GET)
    private String deleteDeliveryTemplate(HttpServletRequest request) {
        String idRelString = request.getParameter("idRel");
        UUID idRel = UUID.fromString(idRelString);
        CssReportDeliveryGroupTemplateRelation cssReportDeliveryGroupTemplateRelation = reportDeliveryListService.findDeliveryTemplatesByIdRel(idRel);
        reportDeliveryListService.deleteDeliveryTemplateRel(cssReportDeliveryGroupTemplateRelation);
        String cssDeliveryGroupId = cssReportDeliveryGroupTemplateRelation.getCssDeliveryGroupId();
        return "redirect:addTemplates?deliveryGroupId=" + cssDeliveryGroupId;
    }

    @RequestMapping(value = "/deleteRecipient", method = RequestMethod.GET)
    private String deleteDeliveryRecipient(HttpServletRequest request) {
        String idRelString = request.getParameter("idRel");
        UUID idRel = UUID.fromString(idRelString);
        CssDeliveryRecipientRelationship cssDeliveryRecipientRelationship = reportDeliveryListService.findDeliveryRecipientByIdRel(idRel);
        reportDeliveryListService.deleteDeliveryRecipientRel(cssDeliveryRecipientRelationship);
        String cssDeliveryGroupId = cssDeliveryRecipientRelationship.getCssDeliveryGroupId();
        return "redirect:addRecipient?deliveryGroupId=" + cssDeliveryGroupId;
    }
}
