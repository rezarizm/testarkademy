package id.co.astralife.app.report.css.service;

import id.co.astralife.app.report.local.entity.Config;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.List;

public interface CssReportTargetProductService {

    List<String> validateFile(XSSFWorkbook workbook);

    List<Config> getProductHeaders();

    void saveDataFile(XSSFWorkbook workbook, String user);

}
