package id.co.astralife.app.report.common.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.service.AuditTrailService;
import id.co.astralife.app.report.local.entity.AuditTrail;
import id.co.astralife.app.report.local.repository.AuditTrailRepository;

@Service
public class AuditTrailServiceImpl implements AuditTrailService {

	@Autowired
	AuditTrailRepository auditTrailRepository;    
	
	@Override
	public List<AuditTrail> findAll() {
		return findAll();
	}

	@Override
	public void save(AuditTrail auditTrail) {
		auditTrailRepository.save(auditTrail);
	}

	@Override
	public List<AuditTrail> findByAuditTrailId(UUID auditTrailId) {
		return findByAuditTrailId(auditTrailId);
	}

}
