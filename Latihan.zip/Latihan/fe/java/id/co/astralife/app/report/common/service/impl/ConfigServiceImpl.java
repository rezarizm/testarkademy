package id.co.astralife.app.report.common.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.service.ConfigService;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.repository.ConfigRepository;

@Service
public class ConfigServiceImpl implements ConfigService {

	@Autowired
	private ConfigRepository configRepository;
	
	@Override
	public String get(String configName) {
		Config config = configRepository.findByConfigName(configName);
		if(config==null){
			return "";
		} else {
			return config.getConfigValue();
		}
	}

}
