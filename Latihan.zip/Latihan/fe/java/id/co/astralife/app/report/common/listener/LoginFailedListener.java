package id.co.astralife.app.report.common.listener;

import java.sql.Timestamp;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;

import id.co.astralife.app.report.common.AuditTrailConstant;
import id.co.astralife.app.report.common.service.AuditTrailService;
import id.co.astralife.app.report.local.entity.AuditTrail;

@Component
public class LoginFailedListener implements ApplicationListener<AuthenticationFailureBadCredentialsEvent> {

	private static final Logger logger = LoggerFactory.getLogger(LoginListener.class);

    @Autowired
    AuditTrailService auditTrailService; 
    
    @Override
    public void onApplicationEvent(AuthenticationFailureBadCredentialsEvent event) {
        logger.debug("Login event: " + event.getException());
        logger.debug("Authentication: " + event.getAuthentication().getName());
        
        AuditTrail auditTrail = new AuditTrail(); 
        
        User user = (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String name = user.getUsername();
        Date date= new Date();
        
        if (name == null){
        	auditTrail.setLoginId("Anonymous");
        } else {
        	auditTrail.setLoginId(name);
        }
        auditTrail.setTransactionTime(new Timestamp(date.getTime()));
        auditTrail.setTransactionType(AuditTrailConstant.TRANSACTION_TYPE_LOGIN);
        auditTrail.setTransactionStatus(AuditTrailConstant.STATUS_FAILED);
        auditTrail.setDescription("Login To Application");
        
        auditTrailService. save(auditTrail);
    }
}

	
