package id.co.astralife.app.report.common.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Voucher {
	
	private String agentCode;
	private String name;
	private String email;
	private String categoryCode;
	private Integer quantity;
	private String orderNo;

}
