package id.co.astralife.app.report.css.service;

import id.co.astralife.app.report.local.entity.CssDeliveryRecipientRelationship;
import id.co.astralife.app.report.local.entity.CssReportRecipient;

import java.util.List;
import java.util.UUID;

public interface ReportRecipientListService {
    List<CssReportRecipient> findAllRecipient();

    CssReportRecipient findRecipientByCssRecipientID(UUID cssRecipientId);

    List<CssDeliveryRecipientRelationship> findByCssRecipientId(UUID cssRecipientId);

    CssReportRecipient save(CssReportRecipient cssReportRecipient);

    void deleteRecipient(CssReportRecipient cssReportRecipient);

    void deleteDeliveryRecipientRel(List<CssDeliveryRecipientRelationship> cssDeliveryRecipientRelationship);
}
