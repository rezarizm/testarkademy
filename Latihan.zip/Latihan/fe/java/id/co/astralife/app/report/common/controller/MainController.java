package id.co.astralife.app.report.common.controller;

import id.co.astralife.app.report.common.util.UserUtil;
import id.co.astralife.app.report.local.entity.Menu;
import id.co.astralife.app.report.local.entity.User;
import id.co.astralife.app.report.menu.service.MenuService;
import id.co.astralife.app.report.user.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.*;

@Controller
public class MainController {

    @Autowired
    private UserService userService;

    @Autowired
    private MenuService menuService;

    @ModelAttribute(value = "menu")
    public Set<Menu> getMenu() {
        User user = userService.findUserByLoginId(UserUtil.getCurrentUsername());
        List<Menu> menus = menuService.findByUserId(user.getUserId());
        return buildMenuTree(menus);
    }

    private Set<Menu> buildMenuTree(List<Menu> menus) {
        Set<Menu> menuTree = new HashSet<>();
        // First level, get all root
        for (Menu item : menus) {
            if (item.getParentId() == null) {
                //Second level
                for (Menu item2 : menus) {
                    if (item2.getParentId() != null && item2.getParentId().equals(item.getId())) {
                        //Third level
                        for (Menu item3 : menus) {
                            if (item3.getParentId() != null && item3.getParentId().equals(item2.getId())) {
                                for (Menu item4 : menus) {
                                    if (item4.getParentId() != null && item4.getParentId().equals(item3.getId())) {
                                        item3.getChildren().add(item4);
                                    }
                                }
                            	item2.getChildren().add(item3);
                            }
                        }
                        item.getChildren().add(item2);
                    }
                }
                menuTree.add(item);
            }
        }
        return new TreeSet<>(menuTree);
    }
}
