package id.co.astralife.app.report.common.service;

public interface ConfigService {
	String get(String configName);
}
