package id.co.astralife.app.report.css.service.impl;

import id.co.astralife.app.report.css.service.ReportFileGroupListService;
import id.co.astralife.app.report.local.entity.CssReportCategory;
import id.co.astralife.app.report.local.entity.CssReportFileGroup;
import id.co.astralife.app.report.local.entity.CssReportFileGroupRoleRelationship;
import id.co.astralife.app.report.local.entity.Role;
import id.co.astralife.app.report.local.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ReportFileGroupListServiceImpl implements ReportFileGroupListService {

    @Autowired
    private CssReportFileGroupRepository cssReportFileGroupRepository;

    @Autowired
    private CssReportCategoryRepository cssReportCategoryRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private CssReportFileGroupRoleRelationshipRepository cssReportFileGroupRoleRelationshipRepository;

    @Override
    public List<CssReportCategory> findAllCssReportCategory() {
        return cssReportCategoryRepository.findAll();
    }

    @Override
    public List<CssReportFileGroup> findAllCssReportFileGroup() {
        return cssReportFileGroupRepository.findAll();
    }

    @Override
    public List<Role> findAllRole() {
        return roleRepository.findAll();
    }

    @Override
    public CssReportFileGroup save(CssReportFileGroup cssReportFileGroup) {
        return cssReportFileGroupRepository.save(cssReportFileGroup);
    }

    @Override
    public CssReportFileGroup findCssReportFileGroupByCssFileGroupId(String cssFileGroupId) {
        return cssReportFileGroupRepository.findCssReportFileGroupByCssFileGroupId(cssFileGroupId);
    }

    @Override
    public List<CssReportFileGroupRoleRelationship> findRolesByCssFileGroupId(String cssFileGroupId) {
        return cssReportFileGroupRoleRelationshipRepository.findRolesByCssFileGroupId(cssFileGroupId);
    }

    @Override
    public CssReportCategory findCssCategoryNameByCssCategoryId(String cssCategoryId) {
        return cssReportCategoryRepository.findCssReportCategoryByCssCategoryId(cssCategoryId);
    }

    @Override
    public CssReportFileGroupRoleRelationship updateRoles(CssReportFileGroupRoleRelationship cssReportFileGroupRoleRelationship) {
        return cssReportFileGroupRoleRelationshipRepository.save(cssReportFileGroupRoleRelationship);
    }

    @Override
    public Role findByRoleId(UUID roleId) {
        return roleRepository.findByRoleId(roleId);
    }

    @Override
    public void delete(CssReportFileGroup cssReportFileGroup) {
        cssReportFileGroupRepository.delete(cssReportFileGroup);
    }

    @Override
    public void deleteRoles(List<CssReportFileGroupRoleRelationship> cssReportFileGroupRoleRelationship) {
        cssReportFileGroupRoleRelationshipRepository.delete(cssReportFileGroupRoleRelationship);
    }
}