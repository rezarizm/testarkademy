package id.co.astralife.app.report.config;

import id.co.astralife.app.report.local.entity.Role;
import id.co.astralife.app.report.local.entity.User;
import id.co.astralife.app.report.user.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author fadil.wiranata
 */
@Component(value = "customContextMapper")
public class CustomUserDetailsContextMapper implements UserDetailsContextMapper {

    static final Logger LOGGER = LoggerFactory.getLogger(CustomUserDetailsContextMapper.class);

    @Autowired
    UserService userService;

    @Override
    public UserDetails mapUserFromContext(DirContextOperations ctx, String username, Collection<? extends GrantedAuthority> authorities) {
        User user = userService.findUserByLoginId(username);
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        if (null != user) {
            for (Role role : userService.getRolesByLoginId(username)) {
                LOGGER.debug("Adding role: ROLE_" + role.getRoleName());
                grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_" + role.getRoleName()));
            }
            user.setAuthorities(grantedAuthorities);
        }
        return user;
    }

    @Override
    public void mapUserToContext(UserDetails userDetails, DirContextAdapter dirContextAdapter) {
    	//
    }
}
