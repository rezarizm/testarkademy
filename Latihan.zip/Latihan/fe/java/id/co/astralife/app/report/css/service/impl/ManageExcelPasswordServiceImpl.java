package id.co.astralife.app.report.css.service.impl;

import id.co.astralife.app.report.common.util.CryptoService;
import id.co.astralife.app.report.css.service.ManageExcelPasswordService;
import id.co.astralife.app.report.local.entity.CssExcelPassword;
import id.co.astralife.app.report.local.entity.CssReportRecipient;
import id.co.astralife.app.report.local.repository.CssExcelPasswordRepository;
import id.co.astralife.app.report.local.repository.CssReportRecipientRepository;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.util.List;
import java.util.UUID;

@Service
public class ManageExcelPasswordServiceImpl implements ManageExcelPasswordService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ManageExcelPasswordServiceImpl.class);

    @Autowired
    private CssExcelPasswordRepository cssExcelPasswordRepository;

    @Autowired
    private CssReportRecipientRepository cssReportRecipientRepository;

    @Autowired
    private CryptoService cryptoService;

    @Autowired
    private Environment env;

    @Override
    public List<CssExcelPassword> findAllCssExcelPassword() {
        return cssExcelPasswordRepository.findAll();
    }

    @Override
    public CssExcelPassword save(CssExcelPassword cssExcelPassword) {
        try {
            File publicKeyFile = new File(env.getProperty("css.publicKey"));
            byte[] publicKeyByte = Files.readAllBytes(publicKeyFile.toPath());
            String publicKeyString = new String(publicKeyByte);
            byte[] encrypted = cryptoService.encrypt(cssExcelPassword.getPassword().getBytes(), publicKeyString);
            String passwordEncrypted = new String(new Base64().encode(encrypted));
            cssExcelPassword.setPassword(passwordEncrypted);
        } catch (Exception e) {
            LOGGER.error("ERROR When Encrypting: \r\n" + e.getMessage(), e);
        }
        return cssExcelPasswordRepository.save(cssExcelPassword);
    }

    @Override
    public CssExcelPassword findCssExcelPasswordById(UUID id) {
        return cssExcelPasswordRepository.findCssExcelPasswordById(id);
    }

    @Override
    public void delete(CssExcelPassword cssExcelPassword) {
        cssExcelPasswordRepository.delete(cssExcelPassword);
    }

    @Override
    public List<CssReportRecipient> findAllRecipient() {
        return cssReportRecipientRepository.findAll();
    }

    @Override
    public CssReportRecipient findRecipientByCssRecipientId(UUID cssRecipientId) {
        return cssReportRecipientRepository.findRecipientByCssRecipientId(cssRecipientId);
    }
}
