package id.co.astralife.app.report.css.service.impl;

import id.co.astralife.app.report.common.UploadConstant;
import id.co.astralife.app.report.css.service.CssReportTargetAreaService;
import id.co.astralife.app.report.dm.entity.CssReportTargetArea;
import id.co.astralife.app.report.dm.repository.CssReportTargetAreaRepository;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CssReportTargetAreaServiceImpl implements CssReportTargetAreaService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CssReportTargetAreaServiceImpl.class);

    @Autowired
    private CssReportTargetAreaRepository targetAreaRepository;

    @Autowired
    private ConfigRepository configRepository;

    @Override
    public List<String> validateFile(XSSFWorkbook workbook) {
        List<String> headersFile = new ArrayList<>();
        List<String> newHeaderList = new ArrayList<>();
        XSSFSheet sheet = workbook.getSheetAt(0);
        XSSFRow headers = sheet.getRow(0);
        if (headers.getLastCellNum() < 1) {
            throw new UnsupportedOperationException();
        } else {
            for (int index = 0; index < headers.getLastCellNum(); index++) {
                headersFile.add(this.getStringCellValue(headers.getCell(index)).toLowerCase().trim());
            }
            List<Config> headerList = this.getAreaHeaders();
            for (Config header : headerList) {
                newHeaderList.add(header.getConfigValue());
            }
        }
        if (headersFile.containsAll(newHeaderList)) {
            return headersFile;
        } else
            return new ArrayList<>();
    }

    private String getStringCellValue(XSSFCell cell) {
        String cellVal;
        CellType cellType = cell.getCellTypeEnum();
        if (cellType == CellType.NUMERIC) {
            Long cellValD = (long) cell.getNumericCellValue();
            cellVal = cellValD.toString();
        } else {
            cellVal = cell.getStringCellValue();
        }
        return cellVal;
    }

    @Override
    public List<Config> getAreaHeaders() {
        return configRepository.findData(UploadConstant.CSS_TARGET_AREA_HEADER);
    }

    @Async
    public void saveDataFile(XSSFWorkbook workbook, String user) {
        List<CssReportTargetArea> agents = new ArrayList<>();

        XSSFSheet sheet = workbook.getSheetAt(0);
        XSSFRow headers = sheet.getRow(0);

        for (int index = 1; index <= sheet.getLastRowNum(); index++) {

            XSSFRow row = sheet.getRow(index);
            CssReportTargetArea targetArea = this.getCellValue(row, headers);

            if (StringUtils.trimToNull(targetArea.getArea()) != null &&
                    StringUtils.trimToNull(targetArea.getRegion()) != null &&
                    StringUtils.trimToNull(targetArea.getMonth().toString()) != null &&
                    StringUtils.trimToNull(targetArea.getYear().toString()) != null &&
                    StringUtils.trimToNull(targetArea.getRsmCode()) != null &&
                    StringUtils.trimToNull(targetArea.getRsmName()) != null &&
                    StringUtils.trimToNull(targetArea.getAsmCode()) != null &&
                    StringUtils.trimToNull(targetArea.getAsmName()) != null &&
                    StringUtils.trimToNull(targetArea.getApe().toString()) != null) {
                agents.add(targetArea);
            }
        }

        targetAreaRepository.deleteAll();
        targetAreaRepository.save(agents);
    }

    private CssReportTargetArea getCellValue(XSSFRow row, XSSFRow header) {
        CssReportTargetArea agent = new CssReportTargetArea();
        try {
            for (int index = 0; index <= header.getLastCellNum(); index++) {
                if (row.getCell(index) != null) {
                    if ((header.getCell(index).getStringCellValue().trim()).equalsIgnoreCase(UploadConstant.TARGET_AREA_APE)) {
                        agent.setApe(Integer.valueOf(this.getStringCellValue(row.getCell(index))));
                    } else if ((header.getCell(index).getStringCellValue().trim()).equalsIgnoreCase(UploadConstant.TARGET_AREA_AREA)) {
                        agent.setArea(this.getStringCellValue(row.getCell(index)));
                    } else if ((header.getCell(index).getStringCellValue().trim()).equalsIgnoreCase(UploadConstant.TARGET_AREA_ASM_CODE)) {
                        agent.setAsmCode(this.getStringCellValue(row.getCell(index)));
                    } else if ((header.getCell(index).getStringCellValue().trim()).equalsIgnoreCase(UploadConstant.TARGET_AREA_ASM_NAME)) {
                        agent.setAsmName(this.getStringCellValue(row.getCell(index)));
                    } else if ((header.getCell(index).getStringCellValue().trim()).equalsIgnoreCase(UploadConstant.TARGET_AREA_RSM_CODE)) {
                        agent.setRsmCode(this.getStringCellValue(row.getCell(index)));
                    } else if ((header.getCell(index).getStringCellValue().trim()).equalsIgnoreCase(UploadConstant.TARGET_AREA_RSM_NAME)) {
                        agent.setRsmName(this.getStringCellValue(row.getCell(index)));
                    } else if ((header.getCell(index).getStringCellValue().trim()).equalsIgnoreCase(UploadConstant.TARGET_AREA_MONTH)) {
                        agent.setMonth(Integer.valueOf(this.getStringCellValue(row.getCell(index))));
                    } else if ((header.getCell(index).getStringCellValue().trim()).equalsIgnoreCase(UploadConstant.TARGET_AREA_YEAR)) {
                        agent.setYear(Integer.valueOf(this.getStringCellValue(row.getCell(index))));
                    } else if ((header.getCell(index).getStringCellValue().trim()).equalsIgnoreCase(UploadConstant.TARGET_AREA_RSM_REGION)) {
                        agent.setRegion(this.getStringCellValue(row.getCell(index)));
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return agent;
    }
}
