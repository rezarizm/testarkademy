package id.co.astralife.app.report.css.service.impl;

import id.co.astralife.app.report.common.util.CryptoService;
import id.co.astralife.app.report.css.service.ReportRecipientListService;
import id.co.astralife.app.report.local.entity.CssDeliveryRecipientRelationship;
import id.co.astralife.app.report.local.entity.CssReportRecipient;
import id.co.astralife.app.report.local.repository.CssDeliveryRecipientRelationshipRepository;
import id.co.astralife.app.report.local.repository.CssReportRecipientRepository;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.util.List;
import java.util.UUID;

@Service
public class ReportRecipientListServiceImpl implements ReportRecipientListService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReportRecipientListServiceImpl.class);

    @Autowired
    private CssReportRecipientRepository cssReportRecipientRepository;

    @Autowired
    private CssDeliveryRecipientRelationshipRepository cssDeliveryRecipientRelationshipRepository;

    @Autowired
    private CryptoService cryptoService;

    @Autowired
    private Environment env;

    @Override
    public List<CssReportRecipient> findAllRecipient() {
        return cssReportRecipientRepository.findAll();
    }

    @Override
    public CssReportRecipient findRecipientByCssRecipientID(UUID cssRecipientId) {
        return cssReportRecipientRepository.findRecipientByCssRecipientId(cssRecipientId);
    }

    @Override
    public List<CssDeliveryRecipientRelationship> findByCssRecipientId(UUID cssRecipientId) {
        return cssDeliveryRecipientRelationshipRepository.findByCssRecipientId(cssRecipientId);
    }

    @Override
    public CssReportRecipient save(CssReportRecipient cssReportRecipient) {
        try {
            File publicKeyFile = new File(env.getProperty("css.publicKey"));
            byte[] publicKeyByte = Files.readAllBytes(publicKeyFile.toPath());
            String publicKeyString = new String(publicKeyByte);
            byte[] encrypted = cryptoService.encrypt(cssReportRecipient.getCssRecipientAddress().getBytes(), publicKeyString);
            String recipientAddressEncrypted = new String(new Base64().encode(encrypted));
            cssReportRecipient.setCssRecipientAddress(recipientAddressEncrypted);
        } catch (Exception e) {
            LOGGER.error("ERROR When Encrypting: \r\n" + e.getMessage(), e);
        }
        return cssReportRecipientRepository.save(cssReportRecipient);
    }

    @Override
    public void deleteRecipient(CssReportRecipient cssReportRecipient) {
        cssReportRecipientRepository.delete(cssReportRecipient);
    }

    @Override
    public void deleteDeliveryRecipientRel(List<CssDeliveryRecipientRelationship> cssDeliveryRecipientRelationship) {
        cssDeliveryRecipientRelationshipRepository.delete(cssDeliveryRecipientRelationship);
    }

}
