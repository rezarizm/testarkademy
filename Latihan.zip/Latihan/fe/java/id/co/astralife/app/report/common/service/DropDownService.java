package id.co.astralife.app.report.common.service;

import java.util.List;

import id.co.astralife.app.report.local.entity.DropDown;
import id.co.astralife.app.report.local.enumeration.DropDownGroup;

public interface DropDownService {

	List<DropDown> findAllByGroup(DropDownGroup drownGroup);
}
