package id.co.astralife.app.report.css.service;

import id.co.astralife.app.report.local.entity.Config;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.List;

public interface CssReportTargetChannelService {

    List<String> validateFile(XSSFWorkbook workbook);

    List<Config> getChannelHeaders();

    void saveDataFile(XSSFWorkbook workbook, String user);
}