package id.co.astralife.app.report.css.service.impl;

import id.co.astralife.app.report.css.service.CssReportService;
import id.co.astralife.app.report.local.entity.*;
import id.co.astralife.app.report.local.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class CssReportServiceImpl implements CssReportService {

    @Autowired
    private CssReportTemplateRepository templateRepository;

    @Autowired
    private CssReportFileGroupRepository fileGroupRepository;

    @Autowired
    private CssReportFileGroupAndTemplateRelationshipRepository fileGroupAndTemplateRelationship;

    @Autowired
    private CssReportFileGroupRptRoleRelationshipRepository cssReportFileGroupRptRoleRelationshipRepository;

    @Autowired
    private CssReportCategoryFileGroupRelationshipRepository cssReportCategoryFileGroupRelationshipRepository;

    @Autowired
    private CssReportTargetDropdownRepository targetDropdownRepository;

    @Autowired
    private CssReportCategoryRepository cssReportCategoryRepository;

    @Override
    public List<CssReportFileGroupAndTemplateRelationship> getTemplatesByFileGroupId(String fileGroupId) {
        return fileGroupAndTemplateRelationship.getTemplatesByFileGroupId(fileGroupId);
    }

    @Override
    public List<CssReportFileGroupRptRoleRelationship> getFileGroupIdByRoleId(UUID roleId) {
        return cssReportFileGroupRptRoleRelationshipRepository.getFileGroupIdByRoleId(roleId);
    }

    @Override
    public List<CssReportFileGroupRptRoleRelationship> getFileGroupIdByCategoryIdAndRoleId(String categoryId, UUID roleId) {
        return cssReportFileGroupRptRoleRelationshipRepository.getFileGroupIdByCategoryIdAndRoleId(categoryId, roleId);
    }

    @Override
    public List<CssReportTargetDropdown> findAllDropdown() {
        return targetDropdownRepository.findAll();
    }

    @Override
    public CssReportCategory findCssReportCategoryByCssCategoryId(String cssCategoryId) {
        return cssReportCategoryRepository.findCssReportCategoryByCssCategoryId(cssCategoryId);
    }

    @Override
    public CssReportTemplate findCssReportTemplateByCssTemplateId(String cssTemplateId) {
        return templateRepository.findCssTemplateByCssTemplateId(cssTemplateId);
    }

    @Override
    public CssReportFileGroup findCssReportFileGroupByCssFileGroupId(String fileGroupId) {
        return fileGroupRepository.findCssReportFileGroupByCssFileGroupId(fileGroupId);
    }

    @Override
    public CssReportCategoryFileGroupRelationship getCategoryIdByCssFileGroupId(String cssfileGroupId) {
        return cssReportCategoryFileGroupRelationshipRepository.getCategoryIdByCssFileGroupId(cssfileGroupId);
    }

    @Override
    public CssReportFileGroupRptRoleRelationship findFileGroupByIdRel(UUID idRel) {
        return cssReportFileGroupRptRoleRelationshipRepository.findFileGroupByIdRel(idRel);
    }
}
