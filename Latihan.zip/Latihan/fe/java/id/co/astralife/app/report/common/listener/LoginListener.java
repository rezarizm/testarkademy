package id.co.astralife.app.report.common.listener;

import id.co.astralife.app.report.common.AuditTrailConstant;
import id.co.astralife.app.report.common.service.AuditTrailService;
import id.co.astralife.app.report.local.entity.AuditTrail;
import id.co.astralife.app.report.local.entity.User;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.InteractiveAuthenticationSuccessEvent;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by fadil.wiranata.
 */
@Component
public class LoginListener implements ApplicationListener<InteractiveAuthenticationSuccessEvent> {

    private static final Logger logger = LoggerFactory.getLogger(LoginListener.class);

    @Autowired
    AuditTrailService auditTrailService; 
    
    @Override
    public void onApplicationEvent(InteractiveAuthenticationSuccessEvent event) {
        logger.debug("Login event: " + event.getGeneratedBy());
        logger.debug("Authentication: " + event.getAuthentication().getName());

        AuditTrail auditTrail = new AuditTrail();

        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String name = user.getUsername();
        Date date = new Date();

        auditTrail.setLoginId(name);
        auditTrail.setTransactionTime(new Timestamp(date.getTime()));
        auditTrail.setTransactionType(AuditTrailConstant.TRANSACTION_TYPE_LOGIN);
        auditTrail.setTransactionStatus(AuditTrailConstant.STATUS_SUCCESS);
        auditTrail.setDescription("Login To Application");

        auditTrailService.save(auditTrail);

    }
}
