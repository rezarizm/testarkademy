package id.co.astralife.app.report.css.service;

import id.co.astralife.app.report.local.entity.*;

import java.util.List;
import java.util.UUID;

public interface ReportDeliveryListService {

    List<CssReportDeliveryGroup> findAllDeliveryGroup();

    List<CssReportTemplate> findAllCssTemplates();

    List<CssReportDeliveryTemplateRelView> findAllByCssDeliveryGroupId(String cssDeliveryGroupId);

    List<CssReportDeliveryRecipientRelView> findDeliveryRecipientByCssDeliveryGroupId(String cssDeliveryGroupId);

    List<CssReportRecipient> findAllRecipient();

    List<CssReportDeliveryGroupTemplateRelation> findTemplateByCssDeliveryGroupId(String cssDeliveryGroupId);

    List<CssDeliveryRecipientRelationship> findRecipientByCssDeliveryGroupId(String cssDeliveryGroupId);

    CssReportDeliveryGroup save(CssReportDeliveryGroup cssReportDeliveryGroup);

    CssReportDeliveryGroup findCssReportDeliveryGroupByCssDeliveryGroupId(String cssDeliveryGroupId);

    CssReportDeliveryGroupTemplateRelation save(CssReportDeliveryGroupTemplateRelation cssReportDeliveryGroupTemplateRelation);

    CssReportDeliveryGroupTemplateRelation findDeliveryTemplatesByIdRel(UUID idRel);

    CssDeliveryRecipientRelationship save(CssDeliveryRecipientRelationship cssDeliveryRecipientRelationship);

    CssDeliveryRecipientRelationship findDeliveryRecipientByIdRel(UUID idRel);

    void deleteDeliveryGroup(CssReportDeliveryGroup cssReportDeliveryGroup);

    void deleteDeliveryTemplateRel(CssReportDeliveryGroupTemplateRelation cssReportDeliveryGroupTemplateRelation);

    void deleteDeliveryRecipientRel(CssDeliveryRecipientRelationship cssDeliveryRecipientRelationship);

    void deleteDeliveryTemplateRelList(List<CssReportDeliveryGroupTemplateRelation> deliveryGroupTemplateRelationList);

    void deleteDeliveryRecipientRelList(List<CssDeliveryRecipientRelationship> deliveryRecipientRelationshipList);
}
