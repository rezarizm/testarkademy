package id.co.astralife.app.report.css.service;

import id.co.astralife.app.report.local.entity.CssExcelPassword;
import id.co.astralife.app.report.local.entity.CssReportRecipient;

import java.util.List;
import java.util.UUID;

public interface ManageExcelPasswordService {

    List<CssExcelPassword> findAllCssExcelPassword();

    CssExcelPassword save(CssExcelPassword cssExcelPassword);

    CssExcelPassword findCssExcelPasswordById(UUID id);

    void delete(CssExcelPassword cssExcelPassword);

    List<CssReportRecipient> findAllRecipient();

    CssReportRecipient findRecipientByCssRecipientId(UUID cssRecipientId);

}
