package id.co.astralife.app.report.css.service.impl;

import id.co.astralife.app.report.css.service.ReportCategoryListService;
import id.co.astralife.app.report.local.entity.CssReportCategory;
import id.co.astralife.app.report.local.repository.CssReportCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportCategoryListServiceImpl implements ReportCategoryListService {

    @Autowired
    private CssReportCategoryRepository cssReportCategoryRepository;

    @Override
    public List<CssReportCategory> findAllReportCategory() {
        return cssReportCategoryRepository.findAll();
    }

    @Override
    public CssReportCategory save(CssReportCategory cssReportCategory) {
        return cssReportCategoryRepository.save(cssReportCategory);
    }


    @Override
    public CssReportCategory findCssReportCategoryByCssCategoryId(String cssCategoryId) {
        return cssReportCategoryRepository.findCssReportCategoryByCssCategoryId(cssCategoryId);
    }

    @Override
    public void delete(CssReportCategory cssReportCategory) {
        cssReportCategoryRepository.delete(cssReportCategory);
    }
}