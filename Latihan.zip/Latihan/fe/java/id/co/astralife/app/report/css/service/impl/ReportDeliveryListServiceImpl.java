package id.co.astralife.app.report.css.service.impl;

import id.co.astralife.app.report.css.service.ReportDeliveryListService;
import id.co.astralife.app.report.local.entity.*;
import id.co.astralife.app.report.local.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class ReportDeliveryListServiceImpl implements ReportDeliveryListService {

    @Autowired
    private CssReportDeliveryGroupRepository cssReportDeliveryGroupRepository;

    @Autowired
    private CssReportTemplateRepository cssReportTemplateRepository;

    @Autowired
    private CssReportDeliveryGroupTemplateRelationRepository cssReportDeliveryGroupTemplateRelationRepository;

    @Autowired
    private CssDeliveryRecipientRelationshipRepository cssDeliveryRecipientRelationshipRepository;

    @Autowired
    private CssReportDeliveryRecipientRelViewRepository cssReportDeliveryRecipientRelViewRepository;

    @Autowired
    private CssReportDeliveryTemplateRelRepository cssReportDeliveryTemplateRelRepository;

    @Autowired
    private CssReportRecipientRepository cssReportRecipientRepository;

    @Override
    public List<CssReportDeliveryGroup> findAllDeliveryGroup() {
        return cssReportDeliveryGroupRepository.findAll();
    }

    @Override
    public List<CssReportTemplate> findAllCssTemplates() {
        return cssReportTemplateRepository.findAll();
    }

    @Override
    public List<CssReportDeliveryTemplateRelView> findAllByCssDeliveryGroupId(String cssDeliveryGroupId) {
        return cssReportDeliveryTemplateRelRepository.findAllByCssDeliveryGroupId(cssDeliveryGroupId);
    }

    @Override
    public List<CssReportDeliveryRecipientRelView> findDeliveryRecipientByCssDeliveryGroupId(String cssDeliveryGroupId) {
        return cssReportDeliveryRecipientRelViewRepository.findDeliveryRecipientByCssDeliveryGroupId(cssDeliveryGroupId);
    }

    @Override
    public List<CssReportRecipient> findAllRecipient() {
        return cssReportRecipientRepository.findAll();
    }

    @Override
    public List<CssReportDeliveryGroupTemplateRelation> findTemplateByCssDeliveryGroupId(String cssDeliveryGroupId) {
        return cssReportDeliveryGroupTemplateRelationRepository.findTemplateByCssDeliveryGroupId(cssDeliveryGroupId);
    }

    @Override
    public List<CssDeliveryRecipientRelationship> findRecipientByCssDeliveryGroupId(String cssDeliveryGroupId) {
        return cssDeliveryRecipientRelationshipRepository.findRecipientByCssDeliveryGroupId(cssDeliveryGroupId);
    }

    @Override
    public CssReportDeliveryGroup save(CssReportDeliveryGroup cssReportDeliveryGroup) {
        return cssReportDeliveryGroupRepository.save(cssReportDeliveryGroup);
    }

    @Override
    public CssReportDeliveryGroup findCssReportDeliveryGroupByCssDeliveryGroupId(String cssDeliveryGroupId) {
        return cssReportDeliveryGroupRepository.findCssReportDeliveryGroupByCssDeliveryGroupId(cssDeliveryGroupId);
    }

    @Override
    public CssReportDeliveryGroupTemplateRelation save(CssReportDeliveryGroupTemplateRelation cssReportDeliveryGroupTemplateRelation) {
        return cssReportDeliveryGroupTemplateRelationRepository.save(cssReportDeliveryGroupTemplateRelation);
    }

    @Override
    public CssReportDeliveryGroupTemplateRelation findDeliveryTemplatesByIdRel(UUID idRel) {
        return cssReportDeliveryGroupTemplateRelationRepository.findDeliveryTemplatesByIdRel(idRel);
    }

    @Override
    public CssDeliveryRecipientRelationship save(CssDeliveryRecipientRelationship cssDeliveryRecipientRelationship) {
        return cssDeliveryRecipientRelationshipRepository.save(cssDeliveryRecipientRelationship);
    }

    @Override
    public CssDeliveryRecipientRelationship findDeliveryRecipientByIdRel(UUID idRel) {
        return cssDeliveryRecipientRelationshipRepository.findDeliveryRecipientByIdRel(idRel);
    }

    @Override
    public void deleteDeliveryGroup(CssReportDeliveryGroup cssReportDeliveryGroup) {
        cssReportDeliveryGroupRepository.delete(cssReportDeliveryGroup);
    }

    @Override
    public void deleteDeliveryTemplateRel(CssReportDeliveryGroupTemplateRelation cssReportDeliveryGroupTemplateRelation) {
        cssReportDeliveryGroupTemplateRelationRepository.delete(cssReportDeliveryGroupTemplateRelation);
    }

    @Override
    public void deleteDeliveryRecipientRel(CssDeliveryRecipientRelationship cssDeliveryRecipientRelationship) {
        cssDeliveryRecipientRelationshipRepository.delete(cssDeliveryRecipientRelationship);
    }

    @Override
    public void deleteDeliveryTemplateRelList(List<CssReportDeliveryGroupTemplateRelation> deliveryGroupTemplateRelationList) {
        cssReportDeliveryGroupTemplateRelationRepository.delete(deliveryGroupTemplateRelationList);
    }

    @Override
    public void deleteDeliveryRecipientRelList(List<CssDeliveryRecipientRelationship> deliveryRecipientRelationshipList) {
        cssDeliveryRecipientRelationshipRepository.delete(deliveryRecipientRelationshipList);
    }
}
