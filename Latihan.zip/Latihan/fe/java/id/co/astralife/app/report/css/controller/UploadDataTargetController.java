package id.co.astralife.app.report.css.controller;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.controller.MainController;
import id.co.astralife.app.report.common.util.UserUtil;
import id.co.astralife.app.report.css.service.*;
import id.co.astralife.app.report.local.entity.CssReportTargetDropdown;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.model.UploadForm;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/css_report/uploadTarget")
public class UploadDataTargetController extends MainController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UploadDataTargetController.class);

    @Autowired
    private CssReportService cssReportService;

    @Autowired
    private CssReportTargetAreaService targetAreaService;

    @Autowired
    private CssReportTargetChannelService targetChannelService;

    @Autowired
    private CssReportTargetProductService targetProductService;

    @Autowired
    private CssReportTargetRMService targetRMService;

    @Autowired
    private CssReportNonRiderService nonRiderService;

    private static final String UPLOAD_FILE = "UPLOAD DATA TARGET FILE";

    @RequestMapping(method = RequestMethod.GET)
    private String getUpload(Model model) {

        List<CssReportTargetDropdown> targetDropdown = cssReportService.findAllDropdown();

        model.addAttribute(ReportConstant.PAGE_TITLE, UPLOAD_FILE);
        model.addAttribute("fileTypes", targetDropdown);
        model.addAttribute("form", new UploadForm());
        return "css_report/upload_target";
    }

    @RequestMapping(method = RequestMethod.POST)
    private String postUpload(@ModelAttribute UploadForm form, Model model) {

        List<CssReportTargetDropdown> targetDropdown = cssReportService.findAllDropdown();

        if (form.getFile().isEmpty()) {
            model.addAttribute(ReportConstant.SUCCESS, false);
            model.addAttribute(ReportConstant.ERROR_MESSAGE, "No files selected!");
        } else {
            if (form.getType().equalsIgnoreCase("target_area")) {
                this.uploadTargetArea(form, model);
            } else if (form.getType().equalsIgnoreCase("target_mapping_channel")) {
                this.uploadTargetChannel(form, model);
            } else if (form.getType().equalsIgnoreCase("target_product")) {
                this.uploadTargetProduct(form, model);
            } else if (form.getType().equalsIgnoreCase("target_rm")) {
                this.uploadTargetRM(form, model);
            } else if (form.getType().equalsIgnoreCase("non_rider")) {
                this.uploadNonRider(form, model);
            }
        }

        model.addAttribute(ReportConstant.PAGE_TITLE, UPLOAD_FILE);
        model.addAttribute("fileTypes", targetDropdown);
        model.addAttribute("form", new UploadForm());
        return "css_report/upload_target";
    }

    private void uploadTargetArea(UploadForm form, Model model) {
        try (InputStream inputStream = form.getFile().getInputStream()) {
            if (!form.getFile().getOriginalFilename().endsWith(".xlsx")) {
                model.addAttribute(ReportConstant.SUCCESS, false);
                model.addAttribute(ReportConstant.ERROR_MESSAGE, "The file must be with extension \".xlsx\"");
            } else {
                XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
                List<String> headersName = targetAreaService.validateFile(workbook);
                if (headersName.isEmpty()) {
                    List<String> headersList = new ArrayList<>();
                    List<Config> headers = targetAreaService.getAreaHeaders();
                    for (Config header : headers) {
                        headersList.add(header.getConfigValue());
                    }
                    model.addAttribute(ReportConstant.SUCCESS, false);
                    model.addAttribute(ReportConstant.ERROR_MESSAGE,
                            "Some headers incorrect or less, headers must have : \""
                                    + headersList.toString().substring(1, headersList.toString().length() - 1)
                                    + "\", please check back or upload with other file!");
                } else {
                    targetAreaService.saveDataFile(workbook, UserUtil.getCurrentUsername());
                    model.addAttribute(ReportConstant.SUCCESS, true);
                    model.addAttribute(ReportConstant.SUCCESS_MESSAGE, "Data Target Agent Has Been Uploaded Successfully!");
                }
            }
        } catch (Exception e) {
            LOGGER.error("ERROR Upload Report: \r\n" + e.getMessage(), e);
            model.addAttribute(ReportConstant.SUCCESS, false);
            model.addAttribute(ReportConstant.ERROR_MESSAGE, "Unable to upload file");
        }
    }

    private void uploadTargetChannel(UploadForm form, Model model) {
        try (InputStream inputStream = form.getFile().getInputStream()) {
            if (!form.getFile().getOriginalFilename().endsWith(".xlsx")) {
                model.addAttribute(ReportConstant.SUCCESS, false);
                model.addAttribute(ReportConstant.ERROR_MESSAGE, "The file must be with extension \".xlsx\"");
            } else {
                XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
                List<String> headersName = targetChannelService.validateFile(workbook);
                if (headersName.isEmpty()) {
                    List<String> headersList = new ArrayList<>();
                    List<Config> headers = targetChannelService.getChannelHeaders();
                    for (Config header : headers) {
                        headersList.add(header.getConfigValue());
                    }
                    model.addAttribute(ReportConstant.SUCCESS, false);
                    model.addAttribute(ReportConstant.ERROR_MESSAGE,
                            "Some headers incorrect or less, headers must have : \""
                                    + headersList.toString().substring(1, headersList.toString().length() - 1)
                                    + "\", please check back or upload with other file!");
                } else {
                    targetChannelService.saveDataFile(workbook, UserUtil.getCurrentUsername());
                    model.addAttribute(ReportConstant.SUCCESS, true);
                    model.addAttribute(ReportConstant.SUCCESS_MESSAGE, "Data Target Channel Has Been Uploaded Successfully!");
                }
            }
        } catch (Exception e) {
            LOGGER.error("ERROR Upload Report: \r\n" + e.getMessage(), e);
            model.addAttribute(ReportConstant.SUCCESS, false);
            model.addAttribute(ReportConstant.ERROR_MESSAGE, "Unable to upload file!");
        }
    }

    private void uploadTargetProduct(UploadForm form, Model model) {
        try (InputStream inputStream = form.getFile().getInputStream()) {
            if (!form.getFile().getOriginalFilename().endsWith(".xlsx")) {
                model.addAttribute(ReportConstant.SUCCESS, false);
                model.addAttribute(ReportConstant.ERROR_MESSAGE, "The file must be with extension \".xlsx\"");
            } else {
                XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
                List<String> headersName = targetProductService.validateFile(workbook);
                if (headersName.isEmpty()) {
                    List<String> headersList = new ArrayList<>();
                    List<Config> headers = targetProductService.getProductHeaders();
                    for (Config header : headers) {
                        headersList.add(header.getConfigValue());
                    }
                    model.addAttribute(ReportConstant.SUCCESS, false);
                    model.addAttribute(ReportConstant.ERROR_MESSAGE,
                            "Some headers incorrect or less, headers must have : \""
                                    + headersList.toString().substring(1, headersList.toString().length() - 1)
                                    + "\", please check back or upload with other file!");
                } else {
                    targetProductService.saveDataFile(workbook, UserUtil.getCurrentUsername());
                    model.addAttribute(ReportConstant.SUCCESS, true);
                    model.addAttribute(ReportConstant.SUCCESS_MESSAGE, "Data Target Product Has Been Uploaded Successfully!");
                }
            }
        } catch (Exception e) {
            LOGGER.error("ERROR Upload Report: \r\n" + e.getMessage(), e);
            model.addAttribute(ReportConstant.SUCCESS, false);
            model.addAttribute(ReportConstant.ERROR_MESSAGE, "Unable to upload file!");
        }
    }

    private void uploadTargetRM(UploadForm form, Model model) {
        try (InputStream inputStream = form.getFile().getInputStream()) {
            if (!form.getFile().getOriginalFilename().endsWith(".xlsx")) {
                model.addAttribute(ReportConstant.SUCCESS, false);
                model.addAttribute(ReportConstant.ERROR_MESSAGE, "The file must be with extension \".xlsx\"");
            } else {
                XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
                List<String> headersName = targetRMService.validateFile(workbook);
                if (headersName.isEmpty()) {
                    List<String> headersList = new ArrayList<>();
                    List<Config> headers = targetRMService.getRMHeaders();
                    for (Config header : headers) {
                        headersList.add(header.getConfigValue());
                    }
                    model.addAttribute(ReportConstant.SUCCESS, false);
                    model.addAttribute(ReportConstant.ERROR_MESSAGE,
                            "Some headers incorrect or less, headers must have : \""
                                    + headersList.toString().substring(1, headersList.toString().length() - 1)
                                    + "\", please check back or upload with other file!");
                } else {
                    targetRMService.saveDataFile(workbook, UserUtil.getCurrentUsername());
                    model.addAttribute(ReportConstant.SUCCESS, true);
                    model.addAttribute(ReportConstant.SUCCESS_MESSAGE, "Data Target RM Has Been Uploaded Successfully!");
                }
            }
        } catch (Exception e) {
            LOGGER.error("ERROR Upload Report: \r\n" + e.getMessage(), e);
            model.addAttribute(ReportConstant.SUCCESS, false);
            model.addAttribute(ReportConstant.ERROR_MESSAGE, "Unable to upload file!");
        }
    }

    private void uploadNonRider(UploadForm form, Model model) {
        try (InputStream inputStream = form.getFile().getInputStream()) {
            if (!form.getFile().getOriginalFilename().endsWith(".xlsx")) {
                model.addAttribute(ReportConstant.SUCCESS, false);
                model.addAttribute(ReportConstant.ERROR_MESSAGE, "The file must be with extension \".xlsx\"");
            } else {
                XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
                List<String> headersName = nonRiderService.validateFile(workbook);
                if (headersName.isEmpty()) {
                    List<String> headersList = new ArrayList<>();
                    List<Config> headers = nonRiderService.getNonRiderHeaders();
                    for (Config header : headers) {
                        headersList.add(header.getConfigValue());
                    }
                    model.addAttribute(ReportConstant.SUCCESS, false);
                    model.addAttribute(ReportConstant.ERROR_MESSAGE,
                            "Some headers incorrect or less, headers must have : \""
                                    + headersList.toString().substring(1, headersList.toString().length() - 1)
                                    + "\", please check back or upload with other file!");
                } else {
                    nonRiderService.saveDataFile(workbook, UserUtil.getCurrentUsername());
                    model.addAttribute(ReportConstant.SUCCESS, true);
                    model.addAttribute(ReportConstant.SUCCESS_MESSAGE, "Data Non Rider Has Been Uploaded Successfully!");
                }
            }
        } catch (Exception e) {
            LOGGER.error("ERROR Upload Report: \r\n" + e.getMessage(), e);
            model.addAttribute(ReportConstant.SUCCESS, false);
            model.addAttribute(ReportConstant.ERROR_MESSAGE, "Unable to upload file!");
        }
    }
}
