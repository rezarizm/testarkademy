package id.co.astralife.app.report.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import id.co.astralife.app.report.common.model.Voucher;
import id.co.astralife.app.report.upload.constant.UploadConstant;

/**
 * Utility class to modify agent code on excel file uploaded by user.
 *
 * @author sayid.sidqi
 * @version 1.0
 * @since 27 Apr 2017
 */
public final class VoucherFileEditor {

    private VoucherFileEditor() {
    }

    private static final Logger LOG = LoggerFactory.getLogger(VoucherFileEditor.class);

    /**
     * Read given excel file, then store the data and given agent code into a
     * {@link List} of {@link Voucher}.
     *
     * @param file      the excel {@link MultipartFile}
     * @param agentCode {@link String} the agent code
     * @return the {@link List}&lt;{@link Voucher}&gt; generated from excel data
     * and agent code, or empty {@link List} if the file doesn't satisfy
     * the desired format
     * @throws IOException
     */
    public static List<Voucher> createVoucherList(MultipartFile file, String agentCode) throws IOException{
        List<Voucher> vouchers = new ArrayList<>();
        try (InputStream stream = file.getInputStream()) {
        	
        	Workbook workbook = new HSSFWorkbook(stream);
        	Sheet sheet = workbook.getSheetAt(0);
            Row headerRow = sheet.getRow(0);

            Iterator<Row> rows = sheet.iterator();
            rows.next();
            
            while (rows.hasNext()) {
                Row row = rows.next();
            	vouchers.add(mapVoucherFileToModel(row, headerRow, agentCode));
            }
        }
        return vouchers;
    }

    /**
     * Write a given data to excel file.
     *
     * @param templatePath the excel template {@link Path}
     * @param vouchers     the {@link List}&lt;{@link Voucher}&gt; data
     * @param outputPath   the {@link Path} of generated excel file
     * @throws IOException
     */
    public static void writeData(Path templatePath, List<Voucher> vouchers, Path outputPath) throws IOException {
        LOG.info("Writing voucher data into excel file: " + outputPath.getFileName());
    	File file = templatePath.toFile();
        
        try (
        	InputStream is = new FileInputStream(file);
            OutputStream os = Files.newOutputStream(outputPath)
        ) {
            
        	Workbook workbook = new HSSFWorkbook(is);
            Sheet sheet = workbook.getSheetAt(0);

            Row headerRow = sheet.getRow(0);
            
            int rowNo = 0;
            int colAmount = headerRow.getLastCellNum();
            
            for (Voucher voucher : vouchers) {
                
            	Row contentRow = sheet.createRow(++rowNo);
            	for (int i = 0; i < colAmount; i++) {

            		Cell headerCell = headerRow.getCell(i);
                    Cell contentCell = contentRow.createCell(i);
                    
                    String headerCellValue = headerCell.getStringCellValue().trim().toUpperCase();
                    
                    switch (headerCellValue) {
                        case UploadConstant.HEADER_NAME.AGENT_CODE:
                            contentCell.setCellValue(voucher.getAgentCode());
                            break;
                        case UploadConstant.HEADER_NAME.NAME:
                            contentCell.setCellValue(voucher.getName());
                            break;
                        case UploadConstant.HEADER_NAME.EMAIL:
                            contentCell.setCellValue(voucher.getEmail());
                            break;
                        case UploadConstant.HEADER_NAME.CATEGORY_CODE:
                            contentCell.setCellValue(voucher.getCategoryCode());
                            break;
                        case UploadConstant.HEADER_NAME.QUANTITY:
                            contentCell.setCellValue(voucher.getQuantity());
                            break;
                        case UploadConstant.HEADER_NAME.ORDER_NO:
                            contentCell.setCellValue(voucher.getOrderNo());
                            break;
                        default:
                            break;
                    }
                }
            }
            LOG.info("Writing file " + outputPath.getFileName() + " to server directory");
            workbook.write(os);
            LOG.info(outputPath.getFileName() + " is successfully created");
        }
    }


    /**
     * Map data to {@link Voucher} POJO.
     */
    private static Voucher mapVoucherFileToModel(Row contentRow, Row headerRow, String agentCode) {
        Voucher model = new Voucher();
        model.setAgentCode(agentCode);
        
        int lastCellNum = headerRow.getLastCellNum();
        
        for (int i = 0; i < lastCellNum; i++) {
        	
        	Cell headerCell = headerRow.getCell(i);
        	Cell contentCell = contentRow.getCell(i);
        	
        	String headerCellValue = headerCell.getStringCellValue();
            
        	switch (headerCellValue) {
                case UploadConstant.HEADER_NAME.NAME:
                    model.setName(contentCell.getStringCellValue());
                    break;
                case UploadConstant.HEADER_NAME.EMAIL:
                    model.setEmail(contentCell.getStringCellValue());
                    break;
                case UploadConstant.HEADER_NAME.CATEGORY_CODE:
                    model.setCategoryCode(contentCell.getStringCellValue());
                    break;
                case UploadConstant.HEADER_NAME.QUANTITY:
                    model.setQuantity((int) contentCell.getNumericCellValue());
                    break;
                case UploadConstant.HEADER_NAME.ORDER_NO:
                    model.setOrderNo(contentCell.getStringCellValue());
                    break;
                default:
                    break;
            }
        }
        return model;
    }

}
