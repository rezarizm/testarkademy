package id.co.astralife.app.report.common.service;

import java.util.List;
import java.util.UUID;

import id.co.astralife.app.report.local.entity.AuditTrail;

public interface AuditTrailService {

	void save(AuditTrail auditTrail);
	List<AuditTrail> findAll();
	List<AuditTrail> findByAuditTrailId(UUID auditTrailId);
}
