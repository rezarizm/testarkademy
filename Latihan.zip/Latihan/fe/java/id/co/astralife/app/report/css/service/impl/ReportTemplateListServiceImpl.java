package id.co.astralife.app.report.css.service.impl;

import id.co.astralife.app.report.css.service.ReportTemplateListService;
import id.co.astralife.app.report.local.entity.CssReportFileGroup;
import id.co.astralife.app.report.local.entity.CssReportFileGroupTemplateRelationship;
import id.co.astralife.app.report.local.entity.CssReportTemplate;
import id.co.astralife.app.report.local.repository.CssReportFileGroupRepository;
import id.co.astralife.app.report.local.repository.CssReportFileGroupTemplateRelationshipRepository;
import id.co.astralife.app.report.local.repository.CssReportTemplateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportTemplateListServiceImpl implements ReportTemplateListService {

    @Autowired
    private CssReportTemplateRepository cssReportTemplateRepository;

    @Autowired
    private CssReportFileGroupRepository cssReportFileGroupRepository;

    @Autowired
    private CssReportFileGroupTemplateRelationshipRepository cssReportFileGroupTemplateRelationshipRepository;

    @Override
    public List<CssReportTemplate> findAllTemplates() {
        return cssReportTemplateRepository.findAll();
    }

    @Override
    public List<CssReportFileGroup> findAllFileGroup() {
        return cssReportFileGroupRepository.findAll();
    }

    @Override
    public CssReportTemplate save(CssReportTemplate cssReportTemplate) {
        return cssReportTemplateRepository.save(cssReportTemplate);
    }

    @Override
    public CssReportFileGroupTemplateRelationship updateRelation(CssReportFileGroupTemplateRelationship cssReportFileGroupTemplateRelationship) {
        return cssReportFileGroupTemplateRelationshipRepository.save(cssReportFileGroupTemplateRelationship);
    }

    @Override
    public CssReportTemplate findCssTemplateByCssTemplateId(String cssTemplateId) {
        return cssReportTemplateRepository.findCssTemplateByCssTemplateId(cssTemplateId);
    }

    @Override
    public CssReportFileGroup findByCssFileGroupId(String cssFileGroupId) {
        return cssReportFileGroupRepository.findCssReportFileGroupByCssFileGroupId(cssFileGroupId);
    }

    @Override
    public List<CssReportFileGroupTemplateRelationship> findTemplateRelationByCssTemplateId(String cssTemplateId) {
        return cssReportFileGroupTemplateRelationshipRepository.findTemplateRelationByCssTemplateId(cssTemplateId);
    }

    @Override
    public void deleteCssReportTemplate(CssReportTemplate cssReportTemplate) {
        cssReportTemplateRepository.delete(cssReportTemplate);
    }

    @Override
    public void deleteTemplateRelation(List<CssReportFileGroupTemplateRelationship> cssReportFileGroupTemplateRelationship) {
        cssReportFileGroupTemplateRelationshipRepository.delete(cssReportFileGroupTemplateRelationship);
    }
}
