package id.co.astralife.app.report.css.controller;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.controller.MainController;
import id.co.astralife.app.report.css.service.ReportTemplateListService;
import id.co.astralife.app.report.local.entity.CssReportFileGroup;
import id.co.astralife.app.report.local.entity.CssReportFileGroupTemplateRelationship;
import id.co.astralife.app.report.local.entity.CssReportTemplate;
import id.co.astralife.app.report.model.TemplateFileGroupRelationForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/admin/css_report_management/adhoc/report_template_list")
public class ReportTemplateListController extends MainController {

    @Autowired
    private ReportTemplateListService reportTemplateListService;

    @RequestMapping(method = RequestMethod.GET)
    private String templateListPage(Model model) {
        List<String> cssTemplateIdList = new ArrayList<>();
        for (CssReportTemplate cssReportTemplate : reportTemplateListService.findAllTemplates()) {
            cssTemplateIdList.add(cssReportTemplate.getCssTemplateId());
        }

        model.addAttribute(ReportConstant.PAGE_TITLE, "Report Template List");
        model.addAttribute("cssTemplateIdList", cssTemplateIdList);
        model.addAttribute("templateList", reportTemplateListService.findAllTemplates());
        return "css_report_management/adhoc/report_template_list";
    }

    @RequestMapping(value = "/create", method = RequestMethod.GET)
    private String createTemplatePage(Model model) {
        model.addAttribute("fileGroupList", reportTemplateListService.findAllFileGroup());
        return "css_report_management/adhoc/report_template_list/create";
    }

    @RequestMapping(value = "/saveTemplate", method = RequestMethod.POST)
    private String saveTemplate(CssReportTemplate cssReportTemplate) {
        reportTemplateListService.save(cssReportTemplate);
        return "redirect:../report_template_list";
    }

    @RequestMapping(value = "/deleteTemplate", method = RequestMethod.GET)
    private String deleteTemplate(@RequestParam(value = "templateId") String cssTemplateId) {
        CssReportTemplate cssReportTemplate = reportTemplateListService.findCssTemplateByCssTemplateId(cssTemplateId);
        List<CssReportFileGroupTemplateRelationship> reportFileGroupTemplateRelationshipList = reportTemplateListService.findTemplateRelationByCssTemplateId(cssTemplateId);
        if (reportFileGroupTemplateRelationshipList != null && !reportFileGroupTemplateRelationshipList.isEmpty()) {
            reportTemplateListService.deleteTemplateRelation(reportFileGroupTemplateRelationshipList);
        }
        reportTemplateListService.deleteCssReportTemplate(cssReportTemplate);
        return "redirect:../report_template_list";
    }

    @RequestMapping(value = "/edit", method = RequestMethod.GET)
    private String editPageTemplate(@RequestParam(value = "templateId") String cssTemplateId, Model model) {
        CssReportTemplate cssReportTemplate = reportTemplateListService.findCssTemplateByCssTemplateId(cssTemplateId);
        model.addAttribute("cssReportTemplate", cssReportTemplate);
        return "css_report_management/adhoc/report_template_list/edit";
    }

    @RequestMapping(value = "/updateTemplate", method = RequestMethod.POST)
    private String updateTemplate(CssReportTemplate cssReportTemplate) {
        reportTemplateListService.save(cssReportTemplate);
        return "redirect:../report_template_list";
    }

    @RequestMapping(value = "/relation", method = RequestMethod.GET)
    private String templateFileGroupRelationPage(@RequestParam(value = "templateId") String cssTemplateId, Model model) {
        CssReportTemplate cssReportTemplate = reportTemplateListService.findCssTemplateByCssTemplateId(cssTemplateId);
        List<CssReportFileGroupTemplateRelationship> reportFileGroupTemplateRelationshipList = reportTemplateListService.findTemplateRelationByCssTemplateId(cssTemplateId);
        List<CssReportFileGroup> fileGroupList = reportTemplateListService.findAllFileGroup();
        List<String> cssFileGroupId = new ArrayList<>();
        for (CssReportFileGroupTemplateRelationship relationship : reportFileGroupTemplateRelationshipList) {
            cssFileGroupId.add(relationship.getCssFileGroupId());
        }
        TemplateFileGroupRelationForm templateFileGroupRelationForm = new TemplateFileGroupRelationForm();
        templateFileGroupRelationForm.setCssFileGroupId(cssFileGroupId);
        model.addAttribute("cssReportTemplate", cssReportTemplate);
        model.addAttribute("templateFileGroupRelationForm", templateFileGroupRelationForm);
        model.addAttribute("fileGroupList", fileGroupList);
        return "css_report_management/adhoc/report_template_list/relation";
    }

    @RequestMapping(value = "/updateRelation", method = RequestMethod.POST)
    private String updateTemplateFileGroupRelation(@ModelAttribute TemplateFileGroupRelationForm templateFileGroupRelationForm) {
        List<CssReportFileGroupTemplateRelationship> reportFileGroupTemplateRelationshipList = reportTemplateListService.findTemplateRelationByCssTemplateId(templateFileGroupRelationForm.getCssTemplateId());
        reportTemplateListService.deleteTemplateRelation(reportFileGroupTemplateRelationshipList);
        if (templateFileGroupRelationForm.getCssFileGroupId() != null) {
            for (String cssFileGroupId : templateFileGroupRelationForm.getCssFileGroupId()) {
                CssReportFileGroupTemplateRelationship cssReportFileGroupTemplateRelationship = new CssReportFileGroupTemplateRelationship();
                cssReportFileGroupTemplateRelationship.setCssFileGroupId(cssFileGroupId);
                cssReportFileGroupTemplateRelationship.setCssTemplateId(templateFileGroupRelationForm.getCssTemplateId());
                reportTemplateListService.updateRelation(cssReportFileGroupTemplateRelationship);
            }
        }
        return "redirect:../report_template_list";
    }

    @RequestMapping(value = "/detail", method = RequestMethod.GET)
    private String detailPage(@RequestParam(value = "templateId") String cssTemplateId, Model model) {
        CssReportTemplate cssReportTemplate = reportTemplateListService.findCssTemplateByCssTemplateId(cssTemplateId);
        List<CssReportFileGroupTemplateRelationship> fileGroupTemplateRelationshipList = reportTemplateListService.findTemplateRelationByCssTemplateId(cssTemplateId);
        String fileGroupId;
        List<CssReportFileGroup> cssReportFileGroupList = new ArrayList<>();
        for (CssReportFileGroupTemplateRelationship rel : fileGroupTemplateRelationshipList) {
            fileGroupId = rel.getCssFileGroupId();
            CssReportFileGroup cssReportFileGroup = reportTemplateListService.findByCssFileGroupId(fileGroupId);
            cssReportFileGroupList.add(cssReportFileGroup);
        }

        model.addAttribute("cssReportTemplate", cssReportTemplate);
        model.addAttribute("cssReportFileGroupList", cssReportFileGroupList);
        return "css_report_management/adhoc/report_template_list/detail";
    }
}
