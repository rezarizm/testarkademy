package id.co.astralife.app.report.css.controller;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.controller.MainController;
import id.co.astralife.app.report.css.service.ReportFileGroupListService;
import id.co.astralife.app.report.local.entity.CssReportCategory;
import id.co.astralife.app.report.local.entity.CssReportFileGroup;
import id.co.astralife.app.report.local.entity.CssReportFileGroupRoleRelationship;
import id.co.astralife.app.report.local.entity.Role;
import id.co.astralife.app.report.model.FileGroupRoleForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping(value = "/admin/css_report_management/adhoc/report_file_group_list")
public class ReportFileGroupListController extends MainController {
    private static final String reportFileGroupListTitle = "Report File Group List";

    @Autowired
    private ReportFileGroupListService reportFileGroupListService;

    @RequestMapping(method = RequestMethod.GET)
    private String fileGroupListPage(Model model) {
        List<String> cssReportFileGroupList = new ArrayList<>();
        for (CssReportFileGroup tmpCssReportFileGroup : reportFileGroupListService.findAllCssReportFileGroup()) {
            String cssFileGroupId = tmpCssReportFileGroup.getCssFileGroupId();
            cssReportFileGroupList.add(cssFileGroupId);
        }
        List<CssReportCategory> categoryList = reportFileGroupListService.findAllCssReportCategory();
        model.addAttribute(ReportConstant.PAGE_TITLE, reportFileGroupListTitle);
        model.addAttribute("cssReportFileGroupIdList", cssReportFileGroupList);
        model.addAttribute("reportFileGroupList", reportFileGroupListService.findAllCssReportFileGroup());
        model.addAttribute("reportCategoryList", categoryList);
        return "css_report_management/adhoc/report_file_group_list";
    }

    @RequestMapping(value = "/create", method = RequestMethod.GET)
    private String createReportFileGroup(Model model) {
        model.addAttribute("reportCategoryList", reportFileGroupListService.findAllCssReportCategory());
        return "css_report_management/adhoc/report_file_group_list/create";
    }

    @RequestMapping(value = "/saveReportFileGroup", method = RequestMethod.POST)
    private String saveReportFileGroup(CssReportFileGroup cssReportCategory) {
        reportFileGroupListService.save(cssReportCategory);
        return "redirect:../report_file_group_list";
    }

    @RequestMapping(value = "/deleteReportFileGroup", method = RequestMethod.GET)
    private String deleteReportFileGroup(@RequestParam(value = "reportFileGroupId") String cssFileGroupId) {
        List<CssReportFileGroupRoleRelationship> cssReportFileGroupRoleRelationshipList = reportFileGroupListService.findRolesByCssFileGroupId(cssFileGroupId);
        if (cssReportFileGroupRoleRelationshipList != null && !cssReportFileGroupRoleRelationshipList.isEmpty()) {
            reportFileGroupListService.deleteRoles(cssReportFileGroupRoleRelationshipList);
        }
        CssReportFileGroup cssReportFileGroup = reportFileGroupListService.findCssReportFileGroupByCssFileGroupId(cssFileGroupId);
        reportFileGroupListService.delete(cssReportFileGroup);
        return "redirect:../report_file_group_list";
    }

    @RequestMapping(value = "/editReportFileGroup", method = RequestMethod.GET)
    private String editReportFileGroup(@RequestParam(value = "reportFileGroupId") String cssFileGroupId, Model model) {
        CssReportFileGroup cssReportFileGroup = reportFileGroupListService.findCssReportFileGroupByCssFileGroupId(cssFileGroupId);
        CssReportCategory cssReportCategory = reportFileGroupListService.findCssCategoryNameByCssCategoryId(cssReportFileGroup.getCssCategoryId());
        List<CssReportCategory> categoryList = reportFileGroupListService.findAllCssReportCategory();

        model.addAttribute("cssReportFileGroup", cssReportFileGroup);
        model.addAttribute("cssReportCategory", cssReportCategory);
        model.addAttribute("reportCategoryList", categoryList);
        return "css_report_management/adhoc/report_file_group_list/edit";
    }

    @RequestMapping(value = "/updateReportFileGroup", method = RequestMethod.POST)
    private String updateReportFileGroup(CssReportFileGroup cssReportFileGroup) {
        reportFileGroupListService.save(cssReportFileGroup);
        return "redirect:../report_file_group_list";
    }

    @RequestMapping(value = "/detailReportFileGroup", method = RequestMethod.GET)
    private String detailReportFileGroup(@RequestParam(value = "reportFileGroupId") String cssFileGroupId, Model model) {
        CssReportFileGroup cssReportFileGroup = reportFileGroupListService.findCssReportFileGroupByCssFileGroupId(cssFileGroupId);
        CssReportCategory cssReportCategory = reportFileGroupListService.findCssCategoryNameByCssCategoryId(cssReportFileGroup.getCssCategoryId());
        List<CssReportCategory> categoryList = reportFileGroupListService.findAllCssReportCategory();
        List<CssReportFileGroupRoleRelationship> cssReportFileGroupRoleRelationshipList = reportFileGroupListService.findRolesByCssFileGroupId(cssFileGroupId);
        List<Role> roleList = new ArrayList<>();
        UUID roleId;
        for (CssReportFileGroupRoleRelationship fileGroupRoleRelationship : cssReportFileGroupRoleRelationshipList) {
            roleId = fileGroupRoleRelationship.getRoleId();
            Role role = reportFileGroupListService.findByRoleId(roleId);
            roleList.add(role);
        }
        model.addAttribute("cssReportFileGroup", cssReportFileGroup);
        model.addAttribute("cssReportCategory", cssReportCategory);
        model.addAttribute("reportCategoryList", categoryList);
        model.addAttribute("roleList", roleList);
        return "css_report_management/adhoc/report_file_group_list/detail";
    }

    @RequestMapping(value = "/roleReportFileGroup", method = RequestMethod.GET)
    private String roleReportFileGroup(@RequestParam(value = "reportFileGroupId") String cssFileGroupId, Model model) {
        String cssReportFileGroupName = reportFileGroupListService.findCssReportFileGroupByCssFileGroupId(cssFileGroupId).getCssReportFileGroupName();
        List<CssReportFileGroupRoleRelationship> cssReportFileGroupRoleRelationshipList = reportFileGroupListService.findRolesByCssFileGroupId(cssFileGroupId);
        List<Role> roleList = reportFileGroupListService.findAllRole();
        FileGroupRoleForm fileGroupRoleForm = new FileGroupRoleForm();
        List<UUID> listUserRole = new ArrayList<>();
        for (CssReportFileGroupRoleRelationship role : cssReportFileGroupRoleRelationshipList) {
            listUserRole.add(role.getRoleId());
        }
        fileGroupRoleForm.setRoleId(listUserRole);

        model.addAttribute("cssFileGroupId", cssFileGroupId);
        model.addAttribute("cssReportFileGroupName", cssReportFileGroupName);
        model.addAttribute("fileGroupRoles", fileGroupRoleForm);
        model.addAttribute("roleList", roleList);
        return "css_report_management/adhoc/report_file_group_list/role";
    }

    @RequestMapping(value = "/updateRoleFileGroup", method = RequestMethod.POST)
    private String updateRoleFileGroup(@ModelAttribute FileGroupRoleForm fileGroupRoleForm) {
        List<CssReportFileGroupRoleRelationship> cssReportFileGroupRoleRelationshipList = reportFileGroupListService.findRolesByCssFileGroupId(fileGroupRoleForm.getCssFileGroupId());
        reportFileGroupListService.deleteRoles(cssReportFileGroupRoleRelationshipList);
        if (fileGroupRoleForm.getRoleId() != null) {
            for (UUID roleId : fileGroupRoleForm.getRoleId()) {
                CssReportFileGroupRoleRelationship cssReportFileGroupRoleRelationship = new CssReportFileGroupRoleRelationship();
                cssReportFileGroupRoleRelationship.setCssFileGroupId(fileGroupRoleForm.getCssFileGroupId());
                cssReportFileGroupRoleRelationship.setRoleId(roleId);
                reportFileGroupListService.updateRoles(cssReportFileGroupRoleRelationship);
            }
        }
        return "redirect:../report_file_group_list";
    }
}
