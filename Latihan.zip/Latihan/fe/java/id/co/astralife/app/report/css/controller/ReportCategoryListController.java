package id.co.astralife.app.report.css.controller;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.controller.MainController;
import id.co.astralife.app.report.css.service.ReportCategoryListService;
import id.co.astralife.app.report.local.entity.CssReportCategory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping(value = "/admin/css_report_management/adhoc/report_category_list")
public class ReportCategoryListController extends MainController {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReportCategoryListController.class);
    private static final String reportCategoryListTitle = "Report Category List";

    @Autowired
    private ReportCategoryListService reportCategoryListService;

    @RequestMapping(method = RequestMethod.GET)
    private String reportCategoryListPage(Model model) {
        List<String> cssReportCategoryIdList = new ArrayList<>();
        for (CssReportCategory tmpCssReportCategory : reportCategoryListService.findAllReportCategory()) {
            String categoryId = tmpCssReportCategory.getCssCategoryId();
            cssReportCategoryIdList.add(categoryId);
        }
        model.addAttribute("cssReportCategoryIdList", cssReportCategoryIdList);
        model.addAttribute("reportCategoryList", reportCategoryListService.findAllReportCategory());
        model.addAttribute(ReportConstant.PAGE_TITLE, reportCategoryListTitle);
        return "css_report_management/adhoc/report_category_list";
    }

    @RequestMapping(value = "/create", method = RequestMethod.GET)
    private String createReportCategory(Model model) {
        model.addAttribute("cssReportCategory", new CssReportCategory());
        return "css_report_management/adhoc/report_category_list/create";
    }

    @RequestMapping(value = "/saveReportCategory", method = RequestMethod.POST)
    private String saveReportCategory(CssReportCategory cssReportCategory) {
        reportCategoryListService.save(cssReportCategory);
        return "redirect:../report_category_list";
    }

    @RequestMapping(value = "/deleteReportCategory", method = RequestMethod.GET)
    private String deleteReportCategory(HttpServletRequest request) {
        String cssCategoryId = request.getParameter("reportCategoryId");
        CssReportCategory cssReportCategory = reportCategoryListService.findCssReportCategoryByCssCategoryId(cssCategoryId);
        reportCategoryListService.delete(cssReportCategory);
        return "redirect:../report_category_list";
    }

    @RequestMapping(value = "/editReportCategory", method = RequestMethod.GET)
    private String editReportCategory(HttpServletRequest request, Model model) {
        String cssCategoryId = request.getParameter("reportCategoryId");
        CssReportCategory cssReportCategory = reportCategoryListService.findCssReportCategoryByCssCategoryId(cssCategoryId);
        model.addAttribute("cssReportCategory", cssReportCategory);
        return "css_report_management/adhoc/report_category_list/edit";
    }

    @RequestMapping(value = "/updateReportCategory", method = RequestMethod.POST)
    private String updateReportCategory(CssReportCategory cssReportCategory) {
        reportCategoryListService.save(cssReportCategory);
        return "redirect:../report_category_list";
    }
}
