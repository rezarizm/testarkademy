package id.co.astralife.app.report.ib.service.impl;

import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.FtpConstant;
import id.co.astralife.app.report.common.IbConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.EmailUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.ib.service.ExportClaimService;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.model.ExportClaimRequest;
import id.co.astralife.app.report.report.service.ReportService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class ExportClaimServiceImpl implements ExportClaimService {

    public static final Logger LOGGER = LoggerFactory.getLogger(ExportClaimServiceImpl.class);

    private final ReportGenerator reportGenerator;
    private final ReportService reportService;
    private final ConfigRepository configRepository;

    @Value("${dir.pathOutput}")
    private String pathOutput;
    
    @Value("${exportClaimPrefixFormat}")
    private String prefixNameFormat;    

	@Autowired
	Environment env;
	
    @Autowired
    public ExportClaimServiceImpl(ReportGenerator reportGenerator, ReportService reportService, ConfigRepository configRepository) {
        this.reportGenerator = reportGenerator;
        this.reportService = reportService;
        this.configRepository = configRepository;
    }

    @Override
    public void generateExportClaim(ExportClaimRequest exportReq) {
        Report report = reportService.findByTemplate(IbConstant.EXPORT_CLAIM);
        String fileName = this.getFileName(exportReq);
        boolean validToSendMail = exportReq.isSend();	
        
        Map<String, Object> params = new HashMap<>();

        params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
        params.put(ReportConstant.FILENAME_PARAM, fileName);
        params.put(IbConstant.START_DATE, exportReq.getStartDate());
        params.put(IbConstant.END_DATE, exportReq.getEndDate());
        
        String outputDir = env.getProperty("dir.sftpExportClaimReport");
        
        if(validToSendMail) {
            params.put(EmailConstant.EMAIL, true);
            params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
            params.put(EmailConstant.PARAM_EMAIL_FROM, EmailConstant.EMAIL_SENDER_NO_REPLY);
            params.put(EmailConstant.PARAM_TO_ID, this.getEmail());
            params.put(EmailConstant.PARAM_SUBJECT, fileName);
            params.put(EmailConstant.PARAM_CONTENT, "This email is autosend by system<br>Please don\'t reply this email message.");
            params.put(EmailConstant.PARAM_ATTACH_NAME, fileName + ".xlsx");
            params.put(EmailConstant.PARAM_FILEPATH, pathOutput + fileName + ".xlsx");
            params.put(EmailConstant.IS_VISIBLE, true);            
        
            params.put(FtpConstant.SFTP, true);
        	params.put(FtpConstant.SFTP_MANUAL_CONNECT, true);
    		params.put(FtpConstant.FTP_HOST_NAME, env.getProperty("sftp.hostname2"));
    		params.put(FtpConstant.FTP_USER_NAME, env.getProperty("sftp.username2"));
    		params.put(FtpConstant.FTP_PASSWORD , env.getProperty("sftp.password2"));
    		params.put(FtpConstant.FTP_PORT, env.getProperty("sftp.port2"));
    		params.put(FtpConstant.FTP_OUTPUT_DIR, outputDir);
    		params.put(FtpConstant.FTP_OUTPUT_NAME, fileName + ".xlsx");            
        }
		
        reportGenerator.generate(report.getReportId(), exportReq.getUser(), params);
    }    
    
    private String getEmail() {
        List<Config> configs = configRepository.findData(IbConstant.EXPORT_CLAIM_EMAIL_TO);
        return EmailUtil.buildIdsFromConfig(configs);
    }

    private String getFileName(ExportClaimRequest exportReq) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Calendar calendar = Calendar.getInstance();
        String uiDate = sdf.format(calendar.getTime());
        String fileName;

        Date jobDate = null;
        try {
            jobDate = sdf.parse(exportReq.getStartDate() + "235959");
        } catch (ParseException e) {
            LOGGER.error("ParseException: {}", e.getMessage());
        }

        String jobDateFormat = sdf.format(jobDate);

        if (exportReq.getUser().equalsIgnoreCase("SYSTEM")) {
//            fileName = "Reimbursement Report-" + jobDateFormat;
            fileName = prefixNameFormat + jobDateFormat;
        } else {
//            fileName = "Reimbursement Report-" + uiDate;
            fileName = prefixNameFormat + exportReq.getStartDate().toString() + "_" + exportReq.getEndDate().toString();
        }

        return fileName;
    }
}
