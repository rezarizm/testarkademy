package id.co.astralife.app.report.schedule.job;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.AutoRenewalConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.AutoRenewalRequest;
import id.co.astralife.app.report.operation.service.AutoRenewalService;
import id.co.astralife.app.report.report.service.ReportService;

public class AutoRenewalJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(AutoRenewalJob.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private AutoRenewalService autoRenewalService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START Bill Auto Renewal Job----------");
		
        Report report = reportService.findByTemplate(AutoRenewalConstant.PROP_AUTO_RENEWAL);
        if (null != report) {
        	AutoRenewalRequest autoRenewReq = new AutoRenewalRequest();
        	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        	autoRenewReq.setUser("SYSTEM");
        	
        	Calendar dateParam = Calendar.getInstance();
        	String getCurrentDate = dateFormat.format(new Date());
        	Date currentDate;
			try {
				
				currentDate = dateFormat.parse(getCurrentDate);
				dateParam.setTime(currentDate);
	        	dateParam.add(Calendar.MONTH, 2);
	        	dateParam.set(Calendar.DATE, dateParam.getActualMinimum(Calendar.DATE));
	        	String startDate = dateFormat.format(dateParam.getTime());
	        	dateParam.set(Calendar.DATE, dateParam.getActualMaximum(Calendar.DATE));
	        	String endDate = dateFormat.format(dateParam.getTime());
	        	
	        	autoRenewReq.setStartDate(startDate);
	        	autoRenewReq.setEndDate(endDate);
	        	autoRenewReq.setPolicyNo("");
	        	autoRenewReq.setEmail(true);
	        	autoRenewReq.setDuplicate(false);
	        	autoRenewalService.processBillAutoRenewal(autoRenewReq);
			} catch (ParseException e) {
				LOGGER.error("Exception:{}", e.getMessage());
			}
        }
        
		LOGGER.info("----------END Bill Auto Renewal Job----------");
	}

}
