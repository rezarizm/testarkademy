package id.co.astralife.app.report.report.service;

import id.co.astralife.app.report.local.entity.Report;

import java.util.List;
import java.util.UUID;

public interface ReportService {

	Report findByReportId (UUID reportId);
	
	Report findByRptName (String rptName);
	
	Report findByTemplate (String template);
	
	List<Report> findAll();

	List<Report> findBySchedule (String schedule);
}
