package id.co.astralife.app.report.sales.support.service.impl;

import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.DailyCommissionAppBuddiesService;

@Service
public class DailyCommissionAppBuddiesServiceImpl implements DailyCommissionAppBuddiesService {

	@Autowired
	private ReportGenerator reportGenerator;

	@Autowired
	private ReportService reportService;

	@Autowired
	private Environment env;

	@Override
	public void generateCommissionAppBuddiesDetail(UUID reportId, String user, String genDate, String dateParam) {
		Report report = reportService.findByReportId(reportId);
        Map<String, Object> params = new HashMap<>();
        params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);

        if (report != null){
        	params.put(SalesSupportConstant.DATE_PARAM, dateParam);
        	params.put(ReportConstant.FILENAME_PARAM, SalesSupportConstant.COMM_APPBUDDIES_DETAIL_FILENAME + genDate);
        	reportGenerator.generate(report.getReportId(), user, params);
        }
	}

	@Override
    public void generateCommissionAppBuddiesSummary(UUID reportId, String user, String genDate, String dateParam) {
        Report report = reportService.findByReportId(reportId);
        Map<String, Object> params = new HashMap<>();
        params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);

        String pathOutput = Paths.get(env.getProperty("dir.pathOutputShare"), ReportConstant.APPBUDDIES_FOLDER,
                ReportConstant.INCOMING_FOLDER).toAbsolutePath().toString();
        params.put(ReportConstant.PATH_OUTPUT, pathOutput);

        if (report != null) {
        	params.put(SalesSupportConstant.DATE_PARAM, dateParam);
            params.put(ReportConstant.FILENAME_PARAM, SalesSupportConstant.COMM_APPBUDDIES_SUMMARY_FILENAME + genDate);
            reportGenerator.generate(report.getReportId(), user, params);
        }
    }
}