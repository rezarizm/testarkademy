package id.co.astralife.app.report.sftp.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import id.co.astralife.app.report.sftp.service.SFTPService;

@Service
public class SFTPServiceImpl implements SFTPService {

private static final Logger LOGGER = LoggerFactory.getLogger(SFTPServiceImpl.class);
    
    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;
    ChannelExec channelExec = null;
    InputStream input = null;
    
    @Override
    public void sftpLogin(String hostname, String username, String password, Integer port) {
    	JSch jSch = new JSch();
    	try {
    		session = jSch.getSession(username, hostname, port);
    		session.setPassword(password);
		    Properties config = new Properties();
		    config.put("StrictHostKeyChecking", "no");
		    session.setConfig(config);
		    session.connect(60000);
        } catch (JSchException e) {
            LOGGER.error("JSchException: {}", e.getMessage(), e);
        }
    }
    
    @Override
    public void createFolder(String dirPath, String folderName) {
    	try {
		    channel = session.openChannel("sftp");
		    channel.connect();
    		channelSftp = (ChannelSftp) channel;
        	channelSftp.cd(dirPath);
        	try {
        		channelSftp.cd(folderName);
        	} catch (SftpException e) {
				channelSftp.mkdir(folderName);
				LOGGER.info("Folder created successfully");
			}
    	} catch (SftpException e) {
			LOGGER.error("SftpException: {}", e.getMessage(), e);
		} catch (JSchException e) {
			LOGGER.error("JSchException: {}", e.getMessage(), e);
		}
    }
    
    @Override
    public void uploadFile(String filePath, String fileName, String hostDir) {
    	try {
    		channel = session.openChannel("sftp");
		    channel.connect();
			channelSftp = (ChannelSftp) channel;
			channelSftp.put(filePath + fileName, hostDir);
			LOGGER.info("File uploaded succesfully");
		} catch (SftpException e) {
		    LOGGER.error("SftpException: {}", e.getMessage(), e);
        } catch (JSchException e) {
			LOGGER.error("JSchException: {}", e.getMessage(), e);
		}
    }
    
    public void execCommand(String command) {
		try {
			channel = session.openChannel("exec");
			channelExec = (ChannelExec) channel;
			channelExec.setCommand(command);
			channel.setInputStream(null);
			channelExec.setErrStream(System.err);
			input = channel.getInputStream();
			channel.connect();
			LOGGER.info("Command executed succesfully");
		} catch (IOException e) {
			LOGGER.error("IOException: {}", e.getMessage(), e);
		} catch (JSchException e) {
			LOGGER.error("JSchException: {}", e.getMessage(), e);
		}
	}
    
    @Override
    public void disconnect() {
    	if (channel != null && channel.isConnected()) {
    		channel.disconnect();
		}
	}
}
