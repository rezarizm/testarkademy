package id.co.astralife.app.report.exception;

public class CryptoServiceException extends Exception {

	private static final long serialVersionUID = -8238319357163693843L;

	public CryptoServiceException() {}

    public CryptoServiceException(String message) {
        super(message);
    }

    public CryptoServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public CryptoServiceException(Throwable cause) {
        super(cause);
    }

    public CryptoServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
