package id.co.astralife.app.report.schedule.job;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.FinanceProductionService;

public class FinanceProductionJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(FinanceProductionJob.class);

	@Autowired
	@Qualifier("financeProductionService")
	FinanceProductionService fpService;

	@Autowired
	ReportService reportService;

	@Override
	protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		LOGGER.info("----------START Finance Production Job----------");
		fpService.generateFinanceProdcution(
			reportService.findByRptName(SalesSupportConstant.FINANCE_PRODUCTION).getReportId(),
			"SYSTEM"
		);
		LOGGER.info("----------END Finance Production Job----------");
	}

}
