package id.co.astralife.app.report.web;



import javax.servlet.http.HttpServletResponse;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import id.co.astralife.app.report.common.GuaranteedCashPaymentConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.GuaranteedCashReportForm;
import id.co.astralife.app.report.report.service.ReportGuaranteedCashPaymentService;
import id.co.astralife.app.report.report.service.ReportService;

@RestController
@RequestMapping(value = "/report/service")
public class GuaranteedCashPaymentReportController {

	private static final Logger LOGGER = LoggerFactory.getLogger(GuaranteedCashPaymentReportController.class);
	private static final String IS_SUCCESS = "success";
	private static final String IS_FAILED = "failed";
	
	private final ReportService reportService;
	
	private final ReportGuaranteedCashPaymentService reportGuaranteedCashPaymentService;
	@Autowired
	public GuaranteedCashPaymentReportController(ReportService reportService, ReportGuaranteedCashPaymentService reportGuaranteedCashPaymentService) {
		this.reportService = reportService;
		this.reportGuaranteedCashPaymentService =  reportGuaranteedCashPaymentService;
	}
	
	
	/**
	 * @param user = SYSTEM / user *
	 * @param startDate = yyyyMMDD *
	 * @param endDate = yyyyMMdd *
	 * @param email = true / false
	 * @param duplicate = true / false
	 *
	 * @param user = SYSTEM / user *
	 * @param policyNo = 00000000 *
	 * @param email = true/false
	 * @param duplicate = true/false
	 * 
	 * @return success
	 */
	
	
	@PostMapping(value = "/gcpreport")
	public String generateReport(@RequestBody GuaranteedCashReportForm gcpForm, HttpServletResponse response) {
	if(gcpForm.getStartDate()!=null&&gcpForm.getEndDate()!=null&&
			!gcpForm.getStartDate().isEmpty()&&!gcpForm.getEndDate().isEmpty()) {
		Report report = reportService.findByTemplate(GuaranteedCashPaymentConstant.GUARANTEED_CASH_PAYMENT_RPT_TEMPLATE);
		if (gcpForm.getUser()==null) {
			gcpForm.setUser("SYSTEM");
		}
		
		if(null != report){	
			reportGuaranteedCashPaymentService.generateGuaranteedCashReport(report.getReportId(),gcpForm.getStartDate(), gcpForm.getEndDate() ,gcpForm.getUser(), gcpForm.getIsEmail());
		}
			
		return IS_SUCCESS;
		
	} else {
		LOGGER.info("----------Failed to generate Guaranteed Cash Payment @GCP report Api----------");
		return IS_FAILED;
	}
		
	}
}
