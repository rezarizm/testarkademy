package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface CertificateService {

	void generateCertificate (UUID reportId, String user, String issdate);
	
	void generateCertificate (UUID reportId, String user, String policyType, String policyNo, String memberNo, String dependentNo, String issdate, String reprint);

	void generatePrintReport(UUID reportId, String issdate);
	
	void generatePrintReport(UUID reportId, String policyType, String issdate);

	void generateIproKreditku (UUID reportId, String user, String trdate);
	
	void generateIproKreditku(UUID reportId, String user, String policyNo, String memberNo, String dependentNo, String effDate, String trdate, String reprint);
	
}
