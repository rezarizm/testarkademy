package id.co.astralife.app.report.schedule.job;

import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.ReportVoucherService;

public class ReportVoucherJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReportVoucherJob.class);
			
	@Autowired
    private ReportService reportService;
	
	@Autowired
	private ReportVoucherService reportVoucherService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		
		LOGGER.info("----------START Report Voucher Job----------");
		
		List<Report> reports = reportService.findBySchedule(ReportConstant.DAILY);
		
		for (Report rpt :reports){
			if (rpt.getTemplate().equals(SalesSupportConstant.REPORT_VOUCHER)){
				reportVoucherService.generateReportVoucher(rpt.getReportId(), "SYSTEM");
			}
		}
		LOGGER.info("----------END Report Voucher Job----------");
	}
}