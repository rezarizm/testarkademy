package id.co.astralife.app.report.sales.support.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.local.repository.ReportFileRepository;
import id.co.astralife.app.report.local.repository.ReportRepository;
import id.co.astralife.app.report.operation.service.impl.IplusNtuInternalServiceImpl;
import id.co.astralife.app.report.sales.support.service.AolUserLoginCountService;

@Service
public class AolUserLoginCountServiceImpl implements AolUserLoginCountService {

	private static final Logger LOGGER = LoggerFactory.getLogger(IplusNtuInternalServiceImpl.class);

	@Autowired
	private ReportGenerator reportGenerator;

	@Autowired
	private ReportRepository reportRepository;

	@Autowired
	private ReportFileRepository reportFileRepository;

	@Autowired
	private Environment env;

	@Autowired
	private ConfigRepository configRepository;

	@Override
	public void processAolUserLoginCopuntReport(UUID reportId, String user) {
		Report report = reportRepository.findByReportId(reportId);
		
		//String password = "bancasaal2015";
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMYYYYHHMMss");
		String fileName = "aol_permata_user_login_"+sdf.format(date);

		if (report != null) {
			Map<String, Object> params = new HashMap<>();
			
			params.put(ReportConstant.XLS_PASS, env.getProperty("aol.report_usr"));
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_VIT);
			
			String attachmentName = fileName+"."+(report.getFormat().equals(ReportConstant.XLS)?"xlsx":report.getFormat().toLowerCase());
			String filePath = env.getProperty("dir.pathOutput");

			List<Config> configs = configRepository.findData(OperationConstant.AOL_LOGIN_COUNT_EMAIL);
			StringBuilder sb =  new StringBuilder();
			if (configs.isEmpty()) {
				sb.append("");
			} else {
				for (Config config : configs) {
					sb.append(config.getConfigValue()+",");
				}
				sb.deleteCharAt(sb.length()-1);
			}
			String toIds = sb.toString();
			
			List<Config> ccConfigs = configRepository.findData(OperationConstant.AOL_LOGIN_COUNT_EMAIL_CC);
			StringBuilder sbuilder =  new StringBuilder();
			if (ccConfigs.isEmpty()) {
				sbuilder.append("");
			} else {
				for (Config config : ccConfigs) {
					sbuilder.append(config.getConfigValue()+",");
				}
				sbuilder.deleteCharAt(sbuilder.length()-1);
			}
			String ccIds = sbuilder.toString();

			// params for send email
			params.put(EmailConstant.EMAIL, true);
			params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
			params.put(EmailConstant.PARAM_EMAIL_FROM, EmailConstant.EMAIL_SENDER_NO_REPLY);
			params.put(EmailConstant.PARAM_TO_ID, toIds);
			params.put(EmailConstant.PARAM_CC_ID, ccIds);
			params.put(EmailConstant.PARAM_SUBJECT, EmailConstant.SUBJECT_AOL_LOGIN_COUNT);
			params.put(EmailConstant.PARAM_CONTENT, EmailConstant.CONTENT_AOL_LOGIN_COUNT);
			params.put(EmailConstant.PARAM_ATTACH_NAME, attachmentName);
			params.put(EmailConstant.PARAM_FILEPATH, filePath+attachmentName);

			params.put(EmailConstant.IS_VISIBLE, true);
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			reportGenerator.generate(report.getReportId(), user, params);

		}
	}

}
