package id.co.astralife.app.report.operation.service.impl;

import java.net.ConnectException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.dm.entity.BillingDetail;
import id.co.astralife.app.report.dm.repository.BillingDetailRepository;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.BillingDetailRequest;
import id.co.astralife.app.report.operation.service.BillingDetailService;
import id.co.astralife.app.report.report.service.ReportService;
import net.sf.jasperreports.engine.JRException;

@Service
public class BillingDetailServiceImpl implements BillingDetailService {

  private static final Logger LOGGER = LoggerFactory.getLogger(BillingDetailServiceImpl.class);

  private ReportGenerator reportGenerator;
  private ReportService reportService;
  private BillingDetailRepository billingDetailRepository;

  @Value("${dir.pathOutput}")
  private String pathOutput;

  @Autowired
  public BillingDetailServiceImpl(ReportGenerator reportGenerator, ReportService reportService, 
      BillingDetailRepository billingDetailRepository) {
    this.reportGenerator = reportGenerator;
    this.reportService = reportService;
    this.billingDetailRepository = billingDetailRepository; 
  }
  
  @Override
  public void generateBillingDetail(BillingDetailRequest request) throws ConnectException, SQLException, JRException {
    
    LOGGER.info("----------START Process Billing Detail Report, params: user {}, billNo {}, startDate {}, endDate {}----------",
        request.getUser(), request.getBillNo(), request.getStartDate(), request.getEndDate());

    List<BillingDetail> billingDetails = billingDetailRepository.getBillingDetail(request.getBillNo(), request.getStartDate(), request.getEndDate());
    LOGGER.info("----------Processing {} Billing Detail Report----------", billingDetails.size());

    Report report = reportService.findByRptName(OperationConstant.BILLING_DETAIL);
    for (BillingDetail billingDetail : billingDetails) {
      Map<String, Object> params = new HashMap<>();
      String fileName = FileUtil.generateFileName(report.getRptName(), billingDetail.getBillNo());
      String zipPassword = "AAL" + billingDetail.getPolicyNo().substring(4, 8);
      String attachmentName = pathOutput + fileName + ".zip";
      
      params.put(ReportConstant.CSV_FIELD_ENCLOSURE, ReportConstant.DOUBLE_QUOTE);
      params.put(OperationConstant.PARAM_START_DATE, request.getStartDate());
      params.put(OperationConstant.PARAM_END_DATE, request.getEndDate());
      params.put(OperationConstant.PARAM_BILLNO, billingDetail.getBillNo());
      params.put(OperationConstant.PARAM_POL_NO, billingDetail.getPolicyNo());
      params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
      params.put(ReportConstant.ZIP_COMP, true);
      params.put(ReportConstant.ZIP_PASS, zipPassword);
      params.put(OperationConstant.PARAM_CONTRACT_TYPE, billingDetail.getContractType());
      
      // send email
      params.put(EmailConstant.EMAIL, true);
      params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
      params.put(EmailConstant.PARAM_EMAIL_FROM, EmailConstant.GROUP_OPERATION);
      params.put(EmailConstant.PARAM_TO_ID, billingDetail.getEmailTo().trim());
      params.put(EmailConstant.PARAM_CC_ID, billingDetail.getEmailCc());
      params.put(EmailConstant.PARAM_SUBJECT, "Polis " + billingDetail.getPolicyNo() + " / Bill " + billingDetail.getBillNo() + " - " + billingDetail.getTrdt());
      params.put(EmailConstant.PARAM_CONTENT, EmailConstant.CONTENT_BILLING_DETAIL);
      params.put(EmailConstant.PARAM_ATTACH_NAME, fileName.concat(".zip"));
      params.put(EmailConstant.PARAM_FILEPATH, attachmentName);
      params.put(EmailConstant.IS_VISIBLE, true);
      
      params.put(ReportConstant.FILENAME_PARAM, fileName);
      reportGenerator.generate(report.getReportId(), request.getUser(), params);
    }
    LOGGER.info("----------END Process Billing Detail Report----------");
  }

}
