package id.co.astralife.app.report.sales.support.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.FtpConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.BankRewardService;

@Service
public class BankRewardServiceImpl implements BankRewardService {

	@Autowired
	private ReportGenerator reportGenerator;
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	Environment env;
	
	@Override
	public void generateBankReward(UUID rptId, String user, String fileName, String dateParam) {
		Report report = reportService.findByReportId(rptId);
		Map<String, Object> params = new HashMap<>();
		String outputDir = env.getProperty("dir.sftpBankReward");
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
		if (report != null) {
			params.put(SalesSupportConstant.DATE_PARAM, dateParam);
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			
			params.put(FtpConstant.SFTP, true);
			params.put(FtpConstant.FTP_OUTPUT_DIR, outputDir);
			params.put(FtpConstant.FTP_OUTPUT_NAME, fileName + "." + report.getFormat().toLowerCase());
			
			reportGenerator.generate(report.getReportId(), user, params);
		}
	}
}
