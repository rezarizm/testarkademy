package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface AsoService {

  void generateAsoReport(UUID reportId, String user, Boolean email);
  
  Boolean generateAsoLetter(UUID reportId, String policyNo, String user);
}
