package id.co.astralife.app.report.finance.service;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import id.co.astralife.app.report.local.entity.Ojk;
import id.co.astralife.app.report.model.OjkRequest;

public interface OjkService {
	
	void remindUploadData(UUID rptId, Date from, Date to, String user);
	
	void generateAndEmailOjkReport(UUID rptId, String user, String freq, Date from, Date to);
	
	void generateAndEmailAllUncompleteOjkData(List<Ojk> ojks, String user);
	
	void getAddressByGeoCode(Date from, Date to, String user);
	
	void processGetAddressByGeoCode(Date from, Date to, String sheetName, String user, Integer countHitInt);
	
	// save file service
	void saveFileData(XSSFWorkbook workbook, OjkRequest ojkReq);
	
	String geoCodeResetSetting();
	
	void deleteByOjkIdIn(Set<UUID> ojkIds);
	
	void delete(List<Ojk> ojks);
	
	List<Ojk> findByFrequencyAndCreateDateBetween(String rptFreq, Date from, Date to);
	
	
}
