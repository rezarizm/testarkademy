package id.co.astralife.app.report.web;

import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.exception.ParameterRequiredException;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.ReportRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.Map;
import java.util.UUID;

/**
 * @author fadil.wiranata
 */
@RestController
@RequestMapping(value = "/report")
public class ReportController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportController.class);

    @Autowired
    private ReportService reportService;

    @Autowired
    private ReportGenerator reportGenerator;

    @RequestMapping(value = "/generate", method = RequestMethod.POST)
    public String generate(@RequestBody ReportRequest reportRequest, HttpServletResponse response) {

        Map<String, Object> params = reportRequest.getParams();

        if (!params.isEmpty()) {
            UUID uuid = reportRequest.getId();
            if (uuid != null) {
                String user = String.valueOf(params.get("user"));
                if (StringUtils.isNotBlank(user)) {
                    Report report = reportService.findByReportId(uuid);
                    if (report != null) {
                        reportGenerator.generate(report.getReportId(), user, params);
                        LOGGER.info("GENERATE {} by {}, with params {}", report.getRptDesc(), user, params);
                    } else {
                        LOGGER.error("ERROR: Report UUID not found");
                    }
                } else {
                    throw new ParameterRequiredException("Parameter user is required");
                }
            } else {
                throw new ParameterRequiredException("Parameter uuid is required");
            }
        } else {
            throw new ParameterRequiredException("Request parameter is required");
        }

        return "success";
    }
}
