package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

public interface AgentCommissionService {

	void generateAgentCommission (UUID reportId, String user, String startDate, String endDate);
}
