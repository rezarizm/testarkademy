package id.co.astralife.app.report.pgp.service.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.security.SecureRandom;
import java.security.Security;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.PGPEncryptedDataGenerator;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPLiteralData;
import org.bouncycastle.openpgp.PGPLiteralDataGenerator;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPUtil;
import org.bouncycastle.openpgp.jcajce.JcaPGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.operator.jcajce.JcePGPDataEncryptorBuilder;
import org.bouncycastle.openpgp.operator.jcajce.JcePublicKeyKeyEncryptionMethodGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.exception.CryptoServiceException;
import id.co.astralife.app.report.pgp.service.PGPService;

@Service
public class PGPServiceImpl implements PGPService {

	private static final Logger LOGGER = LoggerFactory.getLogger(PGPServiceImpl.class);
	
	@Autowired
	Environment env;
	
	public PGPServiceImpl() {
		Security.addProvider(new BouncyCastleProvider());
	}
	
	static PGPPublicKey getPublicKey(String armoredString) 
		throws CryptoServiceException, IOException, PGPException {
		
		InputStream in = new ByteArrayInputStream(armoredString.getBytes());
		in = PGPUtil.getDecoderStream(in);
		
		JcaPGPPublicKeyRingCollection pgpPub = new JcaPGPPublicKeyRingCollection(in);
		in.close();
		
		PGPPublicKey key = null;
		Iterator<PGPPublicKeyRing> rIt = pgpPub.getKeyRings();
		while (key ==null && rIt.hasNext()) {
			PGPPublicKeyRing kRing = rIt.next();
			Iterator<PGPPublicKey> kIt = kRing.getPublicKeys();
			while (key == null && kIt.hasNext()){
				PGPPublicKey k = kIt.next();
				
				if (k.isEncryptionKey()) {
					key = k;
				}
			}
		}		
		return key;
	}
	
	@Override
	public byte[] encrypt(byte[] data, String publicKey) throws CryptoServiceException {
        ByteArrayOutputStream bOut = new ByteArrayOutputStream();
        PGPLiteralDataGenerator lData = new PGPLiteralDataGenerator();

        OutputStream pOut = null;
        try {
            pOut = lData.open(bOut,
                    PGPLiteralData.BINARY,
                    PGPLiteralData.CONSOLE,
                    data.length,
                    new Date());
            pOut.write(data);
            pOut.close();
        } catch (IOException e) {
            throw new CryptoServiceException(e);
        } finally {
            if (pOut != null)
                try {
                    pOut.close();
                } catch (IOException e) {
                    throw new CryptoServiceException(e);
                }
        }

        ByteArrayOutputStream encOut = new ByteArrayOutputStream();
        OutputStream cOut = null;
        try {
            byte[] plainText = bOut.toByteArray();


            PGPEncryptedDataGenerator encGen = new PGPEncryptedDataGenerator(
                    new JcePGPDataEncryptorBuilder(SymmetricKeyAlgorithmTags.AES_256)
                            .setWithIntegrityPacket(true)
                            .setSecureRandom(new SecureRandom())
                            .setProvider("BC"));

            PGPPublicKey pgpPublicKey = getPublicKey(publicKey);
            encGen.addMethod(new JcePublicKeyKeyEncryptionMethodGenerator(pgpPublicKey).setProvider("BC"));

            cOut = encGen.open(encOut, plainText.length);
            cOut.write(plainText);
        } catch (CryptoServiceException | IOException | PGPException e) {
            throw new SecurityException(e);
        } finally {
            if (cOut != null)
                try {
                    cOut.close();
                } catch (IOException e) {
                    throw new CryptoServiceException(e);
                }
        }
        LOGGER.info("File encrypted succesfully");
        return encOut.toByteArray();
    }
	
	@Override
	public List<String> encryptFiles(List<String> filePaths) {
		List<String> resultFileNames = new ArrayList<>();
		
		for (String filePath : filePaths) {
			try {
				File file = new File(filePath);
				
				byte[] filePlainData = Files.readAllBytes(file.toPath());
				File publicKeyFile = new File((String) env.getProperty("publicKey"));
				byte[] publicKeyByte = Files.readAllBytes(publicKeyFile.toPath());
				String publicKeyString = new String(publicKeyByte);
				
				byte[] chiperData = encrypt(filePlainData, publicKeyString);
				
				String chiperFilePath = filePath + ".gpg";
				File fileChiper = new File(chiperFilePath);
				Files.write(fileChiper.toPath(), chiperData);
				resultFileNames.add(chiperFilePath);	
			} catch (IOException e) {
				LOGGER.error("IOException: {}", e.getMessage(), e);
			} catch (CryptoServiceException e) {
				LOGGER.error("CryptoServiceException: {}", e.getMessage(), e);
			}
		}
		
		return resultFileNames;
	}
}
