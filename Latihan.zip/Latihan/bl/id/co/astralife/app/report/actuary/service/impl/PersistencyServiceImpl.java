package id.co.astralife.app.report.actuary.service.impl;

import id.co.astralife.app.report.actuary.service.PersistencyService;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.local.entity.Report;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersistencyServiceImpl implements PersistencyService {

	@Autowired
	ReportService reportService;
	
	@Autowired
    ReportGenerator reportGenerator;
	
	@Override
	public void generatePersistency(UUID reportId, String user) {
		Report report = reportService.findByReportId(reportId);
    	Map<String, Object> params =  new HashMap<>(); 	
    	if (report!=null){
    		reportGenerator.generate(report.getReportId(), user, params);
    	}
		
	}
}
