package id.co.astralife.app.report.web;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import id.co.astralife.app.report.common.util.WordUtil;
import id.co.astralife.app.report.email.service.EmailService;
import id.co.astralife.app.report.local.entity.Email;
import id.co.astralife.app.report.model.EmailRequest;

@RestController
@RequestMapping(value = "/report/service")
public class EmailController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailController.class);
	private static final String IS_SUCCESS = "success";
	private static final String IS_FAILED = "failed";
	private static final String ERROR_MESSAGE = "errorMessage";
	private static final String DELIMITER = ";"; 
	private static final String TIME_000000 = "000000";
	private static final String TIME_235959 = "235959";
	SimpleDateFormat sdfDateTime = new SimpleDateFormat("yyyyMMddHHmmss");
	
	private EmailService emailService;
	
	@Autowired
	EmailController(EmailService emailService) {
		this.emailService = emailService;
	}
	
	/**
	 * @param option = 1 *
	 * @param user = SYSTEM *
	 * @param emailId = <UUID> * (if more, insert delimiter ';'), ex : 444C84E6-2893-4EF3-9ACD-378DCB719C78
	 * @param status = C / P / F *
	 * 
	 * @param option = 2 *
	 * @param user = SYSTEM *
	 * @param startDate = yyyyMMdd * 
	 * @param endDate = yyyyMMdd *
	 * @param status = C / P / F *
	 * 
	 * @param option = 3 *
	 * @param user = SYSTEM *
	 * @param fromId = <EMAIL> (if more, insert delimiter ';')
	 * @param startDate = yyyyMMdd * 
	 * @param endDate = yyyyMMdd *
	 * @param status = C / P / F *
	 * 
	 * @param option = 4 *
	 * @param user = SYSTEM *
	 * @param reportId = <UUID> * (if more, insert delimiter ';'), ex : 444C84E6-2893-4EF3-9ACD-378DCB719C78
	 * @param startDate = yyyyMMdd * 
	 * @param endDate = yyyyMMdd *
	 * @param status = C / P / F *
	 * 
	 * @return
	 */
	
	@RequestMapping(value = "/email/status", method = RequestMethod.POST)
	public String resendEmail(@RequestBody EmailRequest emailReq, HttpServletResponse response) {
		try {
			List<Email> emails;
			Date from = null;
			Date to = null;
			
			Boolean option1 = emailReq.getOption() == 1
					&& StringUtils.trimToNull(emailReq.getUser()) != null
					&& StringUtils.trimToNull(emailReq.getEmailId()) != null
					&& StringUtils.trimToNull(emailReq.getStatus()) != null;
			
			Boolean option2 = emailReq.getOption() == 2
					&& StringUtils.trimToNull(emailReq.getUser()) != null
					&& StringUtils.trimToNull(emailReq.getStartDate()) != null
					&& StringUtils.trimToNull(emailReq.getEndDate()) != null
					&& StringUtils.trimToNull(emailReq.getStatus()) != null;
			
			Boolean option3 = emailReq.getOption() == 3
					&& StringUtils.trimToNull(emailReq.getUser()) != null
					&& StringUtils.trimToNull(emailReq.getFromId()) != null
					&& StringUtils.trimToNull(emailReq.getStartDate()) != null
					&& StringUtils.trimToNull(emailReq.getEndDate()) != null
					&& StringUtils.trimToNull(emailReq.getStatus()) != null;
			
			Boolean option4 = emailReq.getOption() == 4
					&& StringUtils.trimToNull(emailReq.getUser()) != null
					&& StringUtils.trimToNull(emailReq.getReportId()) != null
					&& StringUtils.trimToNull(emailReq.getStartDate()) != null
					&& StringUtils.trimToNull(emailReq.getEndDate()) != null
					&& StringUtils.trimToNull(emailReq.getStatus()) != null;
			
			if (option1) {
				List<String> emailIdsString = WordUtil.getSplitWordList(emailReq.getEmailId(), DELIMITER);
				Set<UUID> emailIds = new HashSet<>();
				for (String emailIdString : emailIdsString) {
					emailIds.add(UUID.fromString(emailIdString));
				}
				emails = emailService.findByEmailIdIn(emailIds);
				
			} else if (option2) {
				from = sdfDateTime.parse(emailReq.getStartDate() + TIME_000000);
				to = sdfDateTime.parse(emailReq.getEndDate() + TIME_235959);
				emails = emailService.findByCreateDateBetween(from, to); 
				
			} else if (option3) {
				List<String> fromIdsString = WordUtil.getSplitWordList(emailReq.getFromId(), DELIMITER);
				Set<String> fromIds = new HashSet<>();
				for (String fromIdString : fromIdsString) {
					fromIds.add(fromIdString);
				}
				from = sdfDateTime.parse(emailReq.getStartDate() + TIME_000000);
				to = sdfDateTime.parse(emailReq.getEndDate() + TIME_235959);
				emails = emailService.findByFromIdInAndCreateDateBetween(fromIds, from, to);
				
			} else if (option4) {
				List<String> rptIdsString = WordUtil.getSplitWordList(emailReq.getReportId(), DELIMITER);
				Set<UUID> rptIds = new HashSet<>();
				for (String rptIdString : rptIdsString) {
					rptIds.add(UUID.fromString(rptIdString));
				}
				from = sdfDateTime.parse(emailReq.getStartDate() + TIME_000000);
				to = sdfDateTime.parse(emailReq.getEndDate() + TIME_235959);
				emails = emailService.findByReportIdInAndCreateDateBetween(rptIds, from, to);
			} else {
				throw new Exception();
			}
			
			for (Email email : emails) {
				email.setStatus(emailReq.getStatus());
				email.setModifyBy(emailReq.getUser());
			}
			emailService.save(emails);
			
		} catch (Exception e) {
			LOGGER.error("Exception : " + e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ": " + e;
		}
		return IS_SUCCESS;
	}
	
}
