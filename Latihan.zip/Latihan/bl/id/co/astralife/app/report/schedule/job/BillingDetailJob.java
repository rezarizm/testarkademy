package id.co.astralife.app.report.schedule.job;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.BillingDetailRequest;
import id.co.astralife.app.report.operation.service.BillingDetailService;
import id.co.astralife.app.report.report.service.ReportService;
import net.sf.jasperreports.engine.JRException;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.net.ConnectException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class BillingDetailJob extends QuartzJobBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(BillingDetailJob.class);

    @Autowired
    private ReportService reportService;

    @Autowired
    private BillingDetailService billingDetailService;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        LOGGER.info("----------START Billing Detail Report Job----------");
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
        Calendar genCalendar = Calendar.getInstance();
        genCalendar.add(Calendar.DATE,-1);
        String startDate = sdf.format(genCalendar.getTime());
        
        try {
        	Report report = reportService.findByRptName(OperationConstant.BILLING_DETAIL);
        	if (null != report) {
        	    BillingDetailRequest request = new BillingDetailRequest();
        	    request.setUser("SYSTEM");
        	    request.setStartDate(startDate);
        	    request.setEndDate(startDate);
        	    billingDetailService.generateBillingDetail(request);
        	}
        } catch (ConnectException e) {
            LOGGER.info("Billing Detail Connection Exception : ",e);
        } catch (SQLException e) {
            LOGGER.info("Billing Detail SQL Exception : ",e);
        } catch (JRException e) {
            LOGGER.info("Billing Detail JRE Exception : ",e);
        } catch (Exception e) {
            LOGGER.info("Billing Detail Exception : ",e);
        }

        LOGGER.info("----------STOP Billing Detail Report Job----------");
    }
}
