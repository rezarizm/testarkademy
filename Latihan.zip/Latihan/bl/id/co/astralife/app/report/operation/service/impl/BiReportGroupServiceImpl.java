package id.co.astralife.app.report.operation.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.BiReportGroupService;
import id.co.astralife.app.report.report.service.ReportService;

@Service
public class BiReportGroupServiceImpl implements BiReportGroupService {

	@Autowired
	private ReportService reportService;
	
	@Autowired
	private ReportGenerator reportGenerator;
	
	@Override
	public void generateBiReportGroup(UUID reportId, String user, String month, String year) {
		Report report = reportService.findByReportId(reportId);
		if (null != report){
			Map<String, Object> params = new HashMap<>();
			params.put(OperationConstant.PARAM_MONTH, month);
			params.put(OperationConstant.PARAM_YEAR, year);
			params.put(ReportConstant.FILENAME_PARAM, FileUtil.generateFileName(report.getRptName(), user));
			reportGenerator.generate(reportId, user, params);
		}
	}	
}