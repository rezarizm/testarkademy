package id.co.astralife.app.report.sftp.service;

public interface SFTPService {

	void sftpLogin(String hostname, String username, String password, Integer port);

	void createFolder(String dirPath, String folderName);

	void uploadFile(String filePath, String fileName, String hostDir);
	
	void disconnect();
}
