package id.co.astralife.app.report.sales.support.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.ReportVoucherService;

@Service
public class ReportVoucherServiceImpl implements ReportVoucherService {

	@Autowired
	private ReportGenerator reportGenerator;
	
	@Autowired
	private ReportService reportService;
	    
	@Override
	public void generateReportVoucher(UUID rptId, String user) {
		Report report = reportService.findByReportId(rptId);
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_VMS);
		if (null != report) {
			params.put(ReportConstant.FILENAME_PARAM, FileUtil.generateFileName(report.getRptName(), user));
			reportGenerator.generate(report.getReportId(), user, params);
		}
	}
}