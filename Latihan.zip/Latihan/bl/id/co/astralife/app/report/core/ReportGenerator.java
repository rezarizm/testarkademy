package id.co.astralife.app.report.core;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import java.util.UUID;

import id.co.astralife.app.report.local.entity.Report;
import net.sf.jasperreports.engine.JRException;

public interface ReportGenerator {

	void generate(UUID uuid, String user, Map<String, Object> params);
    
    Connection getConnection(Map<String, Object> params) throws SQLException;
    
    String createFile(Report report, String url, Map<String, Object> params, Connection conn, String fileName) throws JRException, SQLException;
    
    String createPdfFile (String url, Map<String, Object> params, Connection conn, String fileName) throws JRException, SQLException;
    
    String createExcelFile (String url, Map<String, Object> params, Connection conn, String fileName) throws JRException, SQLException;
    
    String createCsvFile (String url, Map<String, Object> params, Connection conn, String fileName, String fileFormat) throws JRException, SQLException;

    String createPoiFile (String url, Map<String, Object> params, Connection conn, String fileName, String templateName);
    
}
