package id.co.astralife.app.report.operation.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.operation.service.BiLaporanService;

@Service
public class BiLaporanServiceImpl implements BiLaporanService{

	@Autowired
	private ReportGenerator reportGenerator;
	
	@Override
	public void generateBiLaporan(UUID reportId, String user, String month, String yearMonth) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		Date date = new Date();
		String dateReport = sdf.format(date);
		
		Map<String, Object> params = new HashMap<>();
		params.put("yearMonth", yearMonth);
		params.put("month", month);
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
		params.put(ReportConstant.FILENAME_PARAM, "B1" + dateReport);
		reportGenerator.generate(reportId, user, params);
	}
	
}
