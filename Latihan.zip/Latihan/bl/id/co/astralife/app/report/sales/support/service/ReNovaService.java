package id.co.astralife.app.report.sales.support.service;

import java.util.Map;
import java.util.UUID;

/**
 * 
 * @author Michael
 * 
 * @Since 26 Jul 2017
 */
public interface ReNovaService {
	
	Integer getReNovaRows();
	
	Integer getMaxRow();

	void generateReNova(UUID reportId, String user, String date);

	void generateReport(UUID reportId, String user, Map<String, Object> params);
}
