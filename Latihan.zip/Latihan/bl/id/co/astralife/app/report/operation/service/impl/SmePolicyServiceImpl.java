package id.co.astralife.app.report.operation.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SmePolicyConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.dm.entity.SmePolicy;
import id.co.astralife.app.report.dm.repository.SmePolicyRepository;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.SmePolicyService;
import id.co.astralife.app.report.report.service.ReportService;

@Service
public class SmePolicyServiceImpl implements SmePolicyService{
			
	@Autowired
	SmePolicyRepository smePolicyRepository;
	
	@Autowired
    ReportService reportService;
	
	@Autowired
    ReportGenerator reportGenerator;
	
	@Override
	public void generateSmePolicy(UUID reportId, String user, String startDate, String endDate) {
		List<SmePolicy> smePolicies = smePolicyRepository.findByDateBetween(startDate, endDate);
		if(!smePolicies.isEmpty()){
			for (SmePolicy smePolicy : smePolicies) {
				SmePolicy smeForNextRow = smePolicyRepository.findForNextRow(smePolicy.getPolicyNo(), smePolicy.getTranNo());
				SmePolicy smeCheckReversed = smePolicyRepository.findCheckReversed(smeForNextRow.getPolicyNo(), smeForNextRow.getId()+1);
				if (smeCheckReversed==null){
					Map<String, Object> params = new HashMap<>();
					params.put(SmePolicyConstant.PARAM_POL_NO, smePolicy.getPolicyNo());
					params.put(SmePolicyConstant.PARAM_TRAN_NO, smePolicy.getTranNo());
					params.put(SmePolicyConstant.PARAM_ISS_DATE, smePolicy.getIssDate());
					params.put(SmePolicyConstant.PARAM_CNT_TYPE, smePolicy.getCntType());
					params.put(SmePolicyConstant.PARAM_BATCTR_CODE, smePolicy.getBatcCode());
					params.put(SmePolicyConstant.PARAM_REPRINT, "N");
					params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
					this.generateSmePolicy(reportId, user, smePolicy.getPolicyNo(), params);
				}
			}
		}
	}

	@Override
	public void generateSmePolicy(UUID reportId, String user, String policyNo, Map<String, Object> params) {
		Report report = reportService.findByReportId(reportId);
		if (report !=null){
			params.put(ReportConstant.FILENAME_PARAM, FileUtil.generateFileName("Group_Health_"+policyNo, user));
			reportGenerator.generate(report.getReportId(), user, params);
		}
	}
}
