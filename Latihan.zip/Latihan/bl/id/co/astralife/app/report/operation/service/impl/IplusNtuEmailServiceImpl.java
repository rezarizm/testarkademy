package id.co.astralife.app.report.operation.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Email;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.local.repository.EmailRepository;
import id.co.astralife.app.report.local.repository.ReportFileRepository;
import id.co.astralife.app.report.local.repository.ReportRepository;
import id.co.astralife.app.report.operation.service.IplusNtuEmailService;

@Service
public class IplusNtuEmailServiceImpl implements IplusNtuEmailService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(IplusNtuEmailServiceImpl.class);
			
	@Autowired
	ReportRepository reportRepository;
	
	@Autowired
	private ReportFileRepository reportFileRepository;
	
	@Autowired
	private EmailRepository emailRepository;
	
	@Autowired
    private ConfigRepository configRepository;
	
	@Autowired
    private Environment env;
	
	@Override
	public void sendEmailIplusNtuPolis(String user, String endDate) {
		
		String filePath = env.getProperty("dir.pathOutput");
		
		Set<String> rptNames = new HashSet<>();
		rptNames.add(OperationConstant.PROPOSAL_POLIS);
		rptNames.add(OperationConstant.CANCEL_POLIS);
		
		List<Report> reports = reportRepository.findByRptNameIn(rptNames);
		
		List<Config> configs = configRepository.findData(OperationConstant.IPLUS_NTU_EMAIL);
		StringBuilder sb =  new StringBuilder();
		if (configs.isEmpty()) {
			sb.append("");
		} else {
			for (Config config : configs) {
				sb.append(config.getConfigValue()+",");
			}
			sb.deleteCharAt(sb.length()-1);
		}
		String toIds = sb.toString();
		
		Map<String, Object> params = new HashMap<>();
		params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
		params.put(EmailConstant.PARAM_EMAIL_FROM, EmailConstant.EMAIL_FROM_IPLUS_NTU);
		params.put(EmailConstant.PARAM_TO_ID, toIds);
		for (Report rpt : reports) {
			if(rpt.getTemplate().equals(OperationConstant.PROPOSAL_POLIS)){
				String attachName = OperationConstant.IPLUS_NTU_PROP_FILENAME + endDate + 
						"." + (rpt.getFormat().equals(ReportConstant.XLS)?"xlsx":rpt.getFormat().toLowerCase()); 
				params.put(EmailConstant.PARAM_SUBJECT, EmailConstant.SUBJECT_PROP);
				params.put(EmailConstant.PARAM_CONTENT, EmailConstant.CONTENT_PROP);
				params.put(EmailConstant.PARAM_ATTACH_NAME, attachName);
				params.put(EmailConstant.PARAM_FILEPATH, filePath + attachName);
				
			} else if (rpt.getTemplate().equals(OperationConstant.CANCEL_POLIS)){
				String attachName = OperationConstant.IPLUS_NTU_CANCEL_FILENAME + endDate + 
						"."+ (rpt.getFormat().equals(ReportConstant.XLS)?"xlsx":rpt.getFormat().toLowerCase()); 
				params.put(EmailConstant.PARAM_SUBJECT, EmailConstant.SUBJECT_CANCEL);
				params.put(EmailConstant.PARAM_CONTENT, EmailConstant.CONTENT_CANCEL);
				params.put(EmailConstant.PARAM_ATTACH_NAME, attachName);
				params.put(EmailConstant.PARAM_FILEPATH, filePath + attachName);
				
			}
			this.processSendEmail(rpt.getReportId(), user, endDate, params);						
		}
	}
	
	private void processSendEmail(UUID rptId, String user, String endDate, Map<String, Object> params){
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Date dateFrom = null;
		Date dateTo = null;
		try {
			dateFrom = sdf.parse(endDate+"000000");
			dateTo = sdf.parse(endDate+"235959");
		} catch (ParseException e) {
			LOGGER.error("ParseException"+e.getMessage());
		}
		
		Set<String> status = new HashSet<>();
		status.add(ReportConstant.COMPLETE);
		status.add(ReportConstant.FAILED);
		
		ReportFile fileNtu = reportFileRepository.findFirstByRptIdAndStatusInAndCreateByAndCreateDateBetween(rptId, status, user, dateFrom, dateTo);
		Email emailNtu = emailRepository.findFirstByAttachName(params.get(EmailConstant.PARAM_ATTACH_NAME).toString());
		if(fileNtu != null && emailNtu == null) {
			Email email = new Email();
			email.setStatus(ReportConstant.PROCESSING);
			email.setYgEmail(params.get(EmailConstant.PARAM_YGEMAIL).toString());
			email.setFromId(params.get(EmailConstant.PARAM_EMAIL_FROM).toString());
			email.setToId(params.get(EmailConstant.PARAM_TO_ID).toString());
			email.setSubject(params.get(EmailConstant.PARAM_SUBJECT).toString());
			email.setContent(params.get(EmailConstant.PARAM_CONTENT).toString());
			email.setAttachName(params.get(EmailConstant.PARAM_ATTACH_NAME).toString());
			email.setAttachPath(params.get(EmailConstant.PARAM_FILEPATH).toString());
			email.setCreateBy(user);
			email.setReportId(rptId);
			emailRepository.save(email);
			
			if(fileNtu.getStatus().equals(ReportConstant.FAILED)){
				Email newEmail = emailRepository.findByEmailId(email.getEmailId());
				newEmail.setStatus(ReportConstant.FAILED);
				newEmail.setModifyBy(user);
				emailRepository.save(newEmail);
			}
		}
	}
}