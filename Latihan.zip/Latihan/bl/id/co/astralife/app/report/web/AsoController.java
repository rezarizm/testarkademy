package id.co.astralife.app.report.web;

import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import id.co.astralife.app.report.common.AsoConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.AsoLetterRequest;
import id.co.astralife.app.report.operation.service.AsoService;
import id.co.astralife.app.report.report.service.ReportService;

@RestController
@RequestMapping(value = "/report/service")
public class AsoController {

  private static final String SUCCESS = "success";

  @Autowired
  private AsoService asoService;

  @Autowired
  private ReportService reportService;

  @RequestMapping(value = "/asoreport", method = RequestMethod.POST)
  public ResponseEntity<String> generateAsoReport(@RequestBody AsoLetterRequest asoReq, HttpServletResponse response) {
    Report report = reportService.findByRptName(AsoConstant.ASO_REPORT);
    if (report != null && StringUtils.isNotBlank(asoReq.getUser())) {
      asoService.generateAsoReport(report.getReportId(), asoReq.getUser(), asoReq.getEmail());
      return new ResponseEntity<>(SUCCESS, HttpStatus.OK);
    } else {
      return new ResponseEntity<>("ERROR", HttpStatus.BAD_REQUEST);
    }
  }
  
  @RequestMapping(value = "/asoletter", method = RequestMethod.POST)
  public ResponseEntity<String> generateAsoLetter(@RequestBody AsoLetterRequest asoReq, HttpServletResponse response) {
    Report report = reportService.findByRptName(AsoConstant.ASO_LETTER);
    if (report != null && StringUtils.isNotBlank(asoReq.getUser()) && StringUtils.isNotBlank(asoReq.getPolicyNo())) {
      Boolean valid = asoService.generateAsoLetter(report.getReportId(), asoReq.getPolicyNo(), asoReq.getUser());
      if (valid) {
        return new ResponseEntity<>(SUCCESS, HttpStatus.OK);
      } else {
        return new ResponseEntity<>("Invalid policy number or data not found", HttpStatus.BAD_REQUEST);
      }
    } else {
      return new ResponseEntity<>("Policy number cannot be empty", HttpStatus.BAD_REQUEST);
    }
  }

}
