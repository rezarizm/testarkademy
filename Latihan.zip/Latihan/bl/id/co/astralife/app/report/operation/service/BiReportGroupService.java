package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface BiReportGroupService {

	void generateBiReportGroup(UUID reportId, String user, String month, String year);
}
