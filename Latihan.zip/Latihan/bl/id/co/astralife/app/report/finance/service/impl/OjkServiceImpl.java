package id.co.astralife.app.report.finance.service.impl;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.FinanceConstant;
import id.co.astralife.app.report.common.OjkConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.EmailUtil;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.common.util.WordUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.dm.entity.AsliOjkClient;
import id.co.astralife.app.report.dm.entity.GroupLifeOjkClient;
import id.co.astralife.app.report.dm.entity.GroupOjkPolNo;
import id.co.astralife.app.report.dm.repository.AsliOjkClientRepository;
import id.co.astralife.app.report.dm.repository.GroupLifeOjkClientRepository;
import id.co.astralife.app.report.dm.repository.GroupOjkPolNoRepository;
import id.co.astralife.app.report.email.service.EmailService;
import id.co.astralife.app.report.finance.service.OjkService;
import id.co.astralife.app.report.geocode.GeoCodeService;
import id.co.astralife.app.report.local.entity.Area;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Email;
import id.co.astralife.app.report.local.entity.Ojk;
import id.co.astralife.app.report.local.entity.OjkMaster;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.local.entity.UploadFile;
import id.co.astralife.app.report.local.repository.AreaRepository;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.local.repository.OjkMasterRepository;
import id.co.astralife.app.report.local.repository.OjkRepository;
import id.co.astralife.app.report.local.repository.ReportFileRepository;
import id.co.astralife.app.report.local.repository.ReportRepository;
import id.co.astralife.app.report.local.repository.UploadFileRepository;
import id.co.astralife.app.report.model.GeoCode;
import id.co.astralife.app.report.model.OjkRequest;
import id.co.astralife.app.report.model.GeoCode.AddressComponent;
import id.co.astralife.app.report.model.GeoCode.Result;

@Service
public class OjkServiceImpl implements OjkService {

	private static final Logger LOGGER = LoggerFactory.getLogger(OjkServiceImpl.class);
	private static final String FROM_ID = "no-reply@astralife.co.id";
	private static final String DIR_PATH_OUTPUT = "dir.pathOutput";
	private static final String UNCOMP_DATA_HEADERS = "Journal Type;Policy Number;Area Code";
	SimpleDateFormat sdfTime = new SimpleDateFormat("HHmm");
	SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMdd");
	SimpleDateFormat sdfDateTime = new SimpleDateFormat("yyyyMMddHHmmss");
	private static final String SYSTEM = "SYSTEM";
	private static final String GEOCODE_COUNT_LOG = "policyNo {} Running GeoCode Converter Address, {} from {}";
	
	private OjkRepository ojkRepository;
	private ConfigRepository configRepository;
	private ReportFileRepository reportFileRepository;
	private EmailService emailService;
	private ReportGenerator reportGenerator;
	private ReportRepository reportRepository;
	private Environment env;
	private GroupLifeOjkClientRepository groupLifeOjkClientRepository;
	private AsliOjkClientRepository asliOjkClientRepository;
	private GeoCodeService geoCodeService;
	private AreaRepository areaRepository;
	private OjkMasterRepository ojkMasterRepository;
	private GroupOjkPolNoRepository groupOjkPolNoRepository;
	private UploadFileRepository uploadFileRepository;

	@Autowired
	public OjkServiceImpl (OjkRepository ojkRepository, ConfigRepository configRepository, 
			ReportFileRepository reportFileRepository, EmailService emailService, 
			ReportGenerator reportGenerator, ReportRepository reportRepository, 
			Environment env, GroupLifeOjkClientRepository groupLifeOjkClientRepository, 
			AsliOjkClientRepository asliOjkClientRepository, GeoCodeService geoCodeService, 
			AreaRepository areaRepository, OjkMasterRepository ojkMasterRepository,
			GroupOjkPolNoRepository groupOjkPolNoRepository, UploadFileRepository uploadFileRepository) {
		this.ojkRepository = ojkRepository;
		this.configRepository = configRepository;
		this.reportFileRepository = reportFileRepository;
		this.emailService = emailService;
		this.reportGenerator = reportGenerator;
		this.reportRepository = reportRepository;
		this.env = env;
		this.groupLifeOjkClientRepository = groupLifeOjkClientRepository;
		this.asliOjkClientRepository = asliOjkClientRepository;
		this.geoCodeService = geoCodeService;
		this.areaRepository = areaRepository;
		this.ojkMasterRepository = ojkMasterRepository;
		this.groupOjkPolNoRepository = groupOjkPolNoRepository;
		this.uploadFileRepository = uploadFileRepository;
	}
	
	@Value("${geocode.ojk.max.hit}")
	private Integer maxHit;

	@Value("${geocode.ojk.max.date}")
	private Integer geoCodeMaxDate;
	
	@Value("${max.update.data}")
	private Integer maxUpdateData;
	
	private Integer countHit;

	// scheduler service
	List<Ojk> newOjks = new ArrayList<>();
	List<OjkMaster> ojkMasters = new ArrayList<>();

	// save file service
	List<OjkMaster> ojksMaster = new ArrayList<>();
	List<String> polNoList = new ArrayList<>();
	List<String> upPolNoList = new ArrayList<>();
	
	@Async
	public void remindUploadData(UUID rptId, Date from, Date to, String user) {
		Email emailExist = emailService.findBySubjectAndCreateDateBetween(
				emailService.render(EmailConstant.SUBJECT_OJK_EMPTY, this.getSubjectDate()), from, to);
		if (emailExist == null) {
			Long ojks = ojkRepository.countByCreateDateBetween(from, to);
			if (ojks == 0) {
				List<Config> confToIds = configRepository.findData(OjkConstant.OJK_EMAIL_TO);
				Email email = new Email();
				email.setStatus(ReportConstant.PROCESSING);
				email.setYgEmail(EmailConstant.EMAIL);
				email.setFromId(FROM_ID);
				email.setToId(EmailUtil.buildIdsFromConfig(confToIds));
				email.setSubject(emailService.render(EmailConstant.SUBJECT_OJK_EMPTY, this.getSubjectDate()));
				email.setContent(EmailConstant.CONTENT_OJK_EMPTY);
				email.setCreateBy(user);
				email.setReportId(rptId);
				emailService.save(email);
			}
		}
	}

	@Async
	public void generateAndEmailOjkReport(UUID rptId, String user, String freq, Date from, Date to) {
		Report report = reportRepository.findByReportId(rptId);
		Long ojks = ojkRepository.countByFrequencyAndCreateDateBetween(freq, from, to);
		Long ojksProcessing = ojkRepository.countByFrequencyAndStatusAndCreateDateBetween(freq, ReportConstant.PROCESSING, from, to);

		SimpleDateFormat sdfGenerate = new SimpleDateFormat("yyyyMMdd");
		String startDate = sdfGenerate.format(from);
		String endDate = sdfGenerate.format(to);
		
		if (ojks > 0 && ojksProcessing == 0) {
			List<ReportFile> ojkFiles = reportFileRepository.findByRptIdAndCreateDateBetween(report.getReportId(), from, to);
			if (ojkFiles.isEmpty()) {
				String fileName = FileUtil.generateFileName(report.getRptName() + "_" + freq, user);
				String attachName = fileName + "."
						+ (("XLS").equals(report.getFormat()) ? "xlsx" : report.getFormat().toLowerCase());

				List<Config> confToIds = configRepository.findData(OjkConstant.OJK_EMAIL_TO);

				Map<String, Object> params = new HashMap<>();
				// params for generate file
				params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_LOCAL);
				params.put(FinanceConstant.PARAM_START_DATE, startDate);
				params.put(FinanceConstant.PARAM_END_DATE, endDate);
				params.put(OjkConstant.PARAM_CAT_PREMI, OjkConstant.PREMI);
				params.put(OjkConstant.PARAM_CAT_CLAIM, OjkConstant.CLAIM);
				params.put(OjkConstant.FREQUENCY, freq);
				
				// params for send email
				params.put(EmailConstant.EMAIL, true);
				params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
				params.put(EmailConstant.PARAM_EMAIL_FROM, FROM_ID);
				params.put(EmailConstant.PARAM_TO_ID, EmailUtil.buildIdsFromConfig(confToIds));
				if (freq.equalsIgnoreCase(OjkConstant.YEARLY)) {
					params.put(EmailConstant.PARAM_SUBJECT, emailService.render(EmailConstant.SUBJECT_OJK_YEAR, this.getSubjectYear()));
				} else {
					params.put(EmailConstant.PARAM_SUBJECT, emailService.render(EmailConstant.SUBJECT_OJK, this.getSubjectDate()));
				}
				params.put(EmailConstant.PARAM_CONTENT, EmailConstant.CONTENT_OJK);
				params.put(EmailConstant.PARAM_ATTACH_NAME, attachName);
				params.put(EmailConstant.PARAM_FILEPATH, env.getProperty(DIR_PATH_OUTPUT) + attachName);
				params.put(EmailConstant.IS_VISIBLE, true);

				params.put(ReportConstant.FILENAME_PARAM, fileName);
				reportGenerator.generate(report.getReportId(), user, params);
			}
		} 
		
		List<Ojk> allOjksProcessing = ojkRepository.findByStatusAndCreateDateBetween(ReportConstant.PROCESSING, from, to);
		if (!allOjksProcessing.isEmpty()) {
			this.generateAndEmailAllUncompleteOjkData(allOjksProcessing, user);
		}
		// reset geoCode sheet count
		Config resetSheetCount = configRepository.findFirstByConfigName(OjkConstant.OJK_GEOCODE_SHEET_DAY_COUNT);
		resetSheetCount.setConfigValue("1");
		configRepository.save(resetSheetCount);
	}

	@Async
	public void generateAndEmailAllUncompleteOjkData(List<Ojk> ojks, String user) {
		try {
			Date date = new Date();
			String dateString = sdfDate.format(date);
			Date from = sdfDateTime.parse(dateString + "000000");
			Date to = sdfDateTime.parse(dateString + "235959");

			Report report = reportRepository.findByTemplate(OjkConstant.OJK_UNCOMP_NO_TEMP);
			if (report != null) {
				ReportFile file = reportFileRepository.findFirstByRptIdAndCreateDateBetween(report.getReportId(), from,
						to);
				if (file == null) {
					List<String> newPolNoList = new ArrayList<>();
					List<Ojk> ojkList = new ArrayList<>();
					for (Ojk ojk : ojks) {
						if (!newPolNoList.contains(ojk.getPolicyNo())) {
							ojkList.add(ojk);
							newPolNoList.add(ojk.getPolicyNo());
						}
					}
					String fileName = FileUtil.generateFileName(OjkConstant.UNCOMP_ALL_FILE_NAME, user);
					String attachName = fileName + ".csv";
					String filePath = env.getProperty(DIR_PATH_OUTPUT) + attachName;

					String headers = UNCOMP_DATA_HEADERS;
					Boolean fileCreated = FileUtil.createTextFile(ojkList, filePath, headers);
					if (fileCreated) {
						List<Config> confToIds = configRepository.findData(OjkConstant.OJK_MASTER_EMAIL_TO);
						List<Config> confCcIds = configRepository.findData(OjkConstant.OJK_MASTER_EMAIL_CC);
						String toIds = EmailUtil.buildIdsFromConfig(confToIds);
						String ccIds = EmailUtil.buildIdsFromConfig(confCcIds);
						this.saveAndEmailFileUncompleteData(toIds, ccIds, attachName, filePath, user);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception:" + e.getMessage(), e);
		}
	}

	@Async
	public void getAddressByGeoCode(Date from, Date to, String user) {
		countHit = 0;
		Long uploadFiles = uploadFileRepository.countByRptTypeAndStatusAndCreateDateBetweenAndIsScheduler(OjkConstant.OJK_SOURCE, ReportConstant.COMPLETE, from, to, true);
		Long count = ojkRepository.countByCreateDateBetween(from, to);
		
		if (count > 0 && uploadFiles > 0) {
			
			Calendar cal = Calendar.getInstance();
			Integer realDate = cal.get(Calendar.DATE); 
			Integer realMonth = cal.get(Calendar.MONTH) + 1;
			
			List<Config> sheets = configRepository.findData(OjkConstant.OJK_SHEET_NAME);
			Config currentMonth = configRepository.findByConfigName(OjkConstant.OJK_GEOCODE_CURRENT_MONTH);
			Config runPerDay = configRepository.findByConfigName(OjkConstant.OJK_GEOCODE_SHEET_RUNNING_PER_DAY);
			Config sumSheetRunned = configRepository.findByConfigName(OjkConstant.OJK_GEOCODE_SHEET_SUM_RUNNED);
			Config geoCodeAvailableDays = configRepository.findByConfigName(OjkConstant.OJK_GEOCODE_AVAILABLE_DAY);
			
			Integer numOfSheets = sheets.size();
			Integer availableDays = 0;
			Integer sheetPerDay = 0;
			
			List<Config> newConfigs = new ArrayList<>();
			if(Integer.valueOf(currentMonth.getConfigValue()) != realMonth) {
				availableDays = (geoCodeMaxDate + 1) - (realDate) > numOfSheets ? numOfSheets : ((geoCodeMaxDate + 1) - (realDate));
				sheetPerDay = (availableDays == 0) ? 0 : ((int) Math.ceil((numOfSheets.doubleValue() / availableDays.doubleValue())));
				
				currentMonth.setConfigValue(String.valueOf(realMonth));
				newConfigs.add(currentMonth);
				runPerDay.setConfigValue(String.valueOf(sheetPerDay));
				newConfigs.add(runPerDay);
				sumSheetRunned.setConfigValue("0");
				newConfigs.add(sumSheetRunned);
				geoCodeAvailableDays.setConfigValue(String.valueOf(availableDays));
				newConfigs.add(geoCodeAvailableDays);
				configRepository.save(newConfigs);
			} 
			
			availableDays = Integer.valueOf(geoCodeAvailableDays.getConfigValue());
			sheetPerDay = Integer.valueOf(runPerDay.getConfigValue());
			
			Config configSheetDay = configRepository.findFirstByConfigName(OjkConstant.OJK_GEOCODE_SHEET_DAY_COUNT);
			List<Integer> sheetRow = new ArrayList<>();
			Set<Integer> setRow = new HashSet<>();
			List<Integer> sizeCount = new ArrayList<>();
			for (Integer x = 1; x <= availableDays; x++) {
				for (Integer y = 1; y <= numOfSheets; y++) {
					if (!setRow.contains(y)) {
						sheetRow.add(Integer.valueOf(x.toString() + y.toString()));
						setRow.add(y);
						sizeCount.add(y);
					}
					if (sizeCount.size() == sheetPerDay) {
						sizeCount.clear();
						break;
					}
				}
			}
			
			if (numOfSheets != Integer.valueOf(sumSheetRunned.getConfigValue())) {
				List<Long> newSheetRow = new ArrayList<>();
				for (Integer value : sheetRow) {
					if (value.toString().substring(0, 1).equals(configSheetDay.getConfigValue())) {
						newSheetRow.add(Long.valueOf(value.toString().substring(1)));
					}
				}
				Long valueNum = Long.valueOf(configSheetDay.getConfigValue());
				if (sheetPerDay != 0) {
					if (valueNum > 0 && valueNum < Long.valueOf(numOfSheets / sheetPerDay)) {
						configSheetDay.setConfigValue(String.valueOf(valueNum + 1));
					} else {
						configSheetDay.setConfigValue("1");
					}
					configRepository.save(configSheetDay);
				}
				if (!newSheetRow.isEmpty()) {
					List<Config> configs = configRepository.findByConfigNameAndRowBetween(OjkConstant.OJK_SHEET_NAME, 
							Collections.min(newSheetRow), Collections.max(newSheetRow));
					
					sumSheetRunned.setConfigValue(String.valueOf(Integer.valueOf(sumSheetRunned.getConfigValue()) + configs.size()));
					configRepository.save(sumSheetRunned);
					
					for (Config config : configs) {
						this.processGetAddressByGeoCode(from, to, config.getConfigValue(), user, countHit);
					}
					this.processNextSheetsGetAddressByGeoCode(from, to, user, Collections.max(newSheetRow));
				}
			}
		}
	}

	@Async
	public void processGetAddressByGeoCode(Date from, Date to, String sheetName, String user, Integer countHitInt) {
		countHit = countHitInt;
		List<Ojk> ojksProc = ojkRepository.findByCategoryAndSubCategoryAndStatusAndCreateDateBetween(
				sheetName.substring(0, sheetName.lastIndexOf(' ')).toUpperCase(), sheetName.toUpperCase(),
				ReportConstant.PROCESSING, from, to);
		if (!ojksProc.isEmpty()) {
			this.completeGetAddressByGeoCode(ojksProc, from, to, user);
			this.checkUncompleteDataPerSheet(from, to, sheetName, user);
		}
	}
	
	private void processNextSheetsGetAddressByGeoCode(Date from, Date to, String user, Long valueNum) {
		Integer breakTime = Integer.parseInt(configRepository.findFirstByConfigName(OjkConstant.OJK_GEOCODE_BREAK_TIME).getConfigValue());
		List<Config> configNextSheets = configRepository.findAllNextConfigValueByConfigName(OjkConstant.OJK_SHEET_NAME, valueNum);
		if (!configNextSheets.isEmpty()) {
			for (Config config : configNextSheets) {
				Date date = new Date();
				Integer currentTime = Integer.parseInt(sdfTime.format(date));
				if (countHit >= maxHit || currentTime >= breakTime) {
					LOGGER.info("Break: Total Hit Geo Code Converter Address : {}", countHit);
					LOGGER.info("Break: Max Break Time Hit Geo Code Converter Address : {}", breakTime);
					break;
				}
				List<Ojk> ojksNextProc = ojkRepository.findByCategoryAndSubCategoryAndStatusAndCreateDateBetween(
						config.getConfigValue().substring(0, config.getConfigValue().lastIndexOf(' ')).toUpperCase(),
						config.getConfigValue().toUpperCase(), ReportConstant.PROCESSING, from, to);
				if (!ojksNextProc.isEmpty()) {
					this.completeGetAddressByGeoCode(ojksNextProc, from, to, user);
				}
			}
		}
	}

	private void completeGetAddressByGeoCode(List<Ojk> ojksProc, Date from, Date to, String user) {
		List<String> newPolNoList = new ArrayList<>();
		Integer breakTime = 2359;
		for (Ojk ojk : ojksProc) {
			try {
				breakTime = Integer.parseInt(configRepository.findFirstByConfigName(OjkConstant.OJK_GEOCODE_BREAK_TIME).getConfigValue());
				if (!newPolNoList.contains(ojk.getPolicyNo())) {
					Map<String, String> polAddrMap = this.getPolicyAddress(ojk);
					if (!polAddrMap.isEmpty()) {
						Map<String, String> provCityMap = this.getProvAndCity(polAddrMap, ojk.getPolicyNo());
						Area area = this.getArea(provCityMap);
						if (area != null) {
							List<Ojk> ojks = ojkRepository.findByPolicyNoAndStatusAndCreateDateBetween(ojk.getPolicyNo(), ReportConstant.PROCESSING, from, to);
							for (Ojk ojkPol : ojks) {
								ojkPol.setAreaCode(area.getAreaCode());
								ojkPol.setCity(area.getCity());
								ojkPol.setProvince(area.getProvince());
								ojkPol.setStatus(ReportConstant.COMPLETE);
								ojkPol.setSourceOfAddress(OjkConstant.SOA_GEO_CODE);
								ojkPol.setModifyBy(user);
								newOjks.add(ojkPol);
								if (newOjks.size() == maxUpdateData) {
									ojkRepository.save(newOjks);
									newOjks.clear();
								}
							}
							ojkMasters.add(this.addOjkMasterCityAndProv(ojk.getPolicyNo(), area, user, ojk.getJournalType()));
							if (ojkMasters.size() == maxUpdateData) {
								ojkMasterRepository.save(ojkMasters);
								ojkMasters.clear();
							}
						}
					}
					newPolNoList.add(ojk.getPolicyNo());
				}
				
			} catch (Exception e) {
				LOGGER.error("Exception OjkServiceImpl: getAddressByGeoCode, Policy Number: {}.", ojk.getPolicyNo(), e);
			}
			

			Date date = new Date();
			Integer currentTime = Integer.parseInt(sdfTime.format(date));
			if (countHit >= maxHit || currentTime >= breakTime) {
				LOGGER.info("Break: Total Hit Geo Code Converter Address : {}", countHit);
				LOGGER.info("Break: Max Break Time Hit Geo Code Converter Address : {}", breakTime);
				break;
			}
		}
		
		ojkRepository.save(newOjks);
		newOjks.clear();
		ojkMasterRepository.save(ojkMasters);
		ojkMasters.clear();
	}

	private Map<String, String> getPolicyAddress(Ojk ojk) {
		Map<String, String> geoCodeAddr = new HashMap<>();
		String policyNo = ojk.getPolicyNo() == null ? "" : ojk.getPolicyNo().trim();

		List<Config> jtConfigs = configRepository.findData(OjkConstant.OJK_JT_NOT_DEFAULT);
		List<String> jtList = new ArrayList<>();
		for (Config config : jtConfigs) {
			jtList.add(config.getConfigValue());
		}
		if (StringUtils.trimToNull(ojk.getJournalType()) == null
				|| !jtList.contains(ojk.getJournalType().trim().toLowerCase()) || policyNo.isEmpty()) {
			this.setDefaultArea(ojk);
		} else {
			geoCodeAddr = this.setPolicyAddress(ojk, policyNo);
		}
		return geoCodeAddr;
	}
	
	private Map<String, String> setPolicyAddress(Ojk ojk, String policyNo) {
		Map<String, String> geoCodeAddr = new HashMap<>();
		Map<String, String> addrsMap = new HashMap<>();
		try {
			if (ojk.getJournalType().trim().equalsIgnoreCase(OjkConstant.JT_ASLI)) {
				AsliOjkClient asliInVal = asliOjkClientRepository.findAsliByPolicyNoAndIsValid(policyNo, false);
				AsliOjkClient asliVal = asliOjkClientRepository.findAsliByPolicyNoAndIsValid(policyNo, true);
				AsliOjkClient asli = asliInVal == null ? asliVal : asliInVal;
				addrsMap.put(OjkConstant.ADDR_01, asli.getAddress01());
				addrsMap.put(OjkConstant.ADDR_02, asli.getAddress02());
				addrsMap.put(OjkConstant.ADDR_03, asli.getAddress03());
			} else if (ojk.getJournalType().trim().equalsIgnoreCase(OjkConstant.JT_LIFE)) {
				GroupLifeOjkClient lifeInVal = groupLifeOjkClientRepository.findLifeByPolicyNoAndIsValid(policyNo, false);
				GroupLifeOjkClient lifeVal = groupLifeOjkClientRepository.findLifeByPolicyNoAndIsValid(policyNo, true);
				GroupLifeOjkClient life = lifeInVal == null ? lifeVal : lifeInVal;
				addrsMap.put(OjkConstant.ADDR_01, life.getAddress01());
				addrsMap.put(OjkConstant.ADDR_02, life.getAddress02());
				addrsMap.put(OjkConstant.ADDR_03, life.getAddress03());
			} else if (ojk.getJournalType().trim().equalsIgnoreCase(OjkConstant.JT_GASIA)) {
				GroupLifeOjkClient groupInVal = groupLifeOjkClientRepository.findGroupByPolicyNoAndIsValid(policyNo, false);
				GroupLifeOjkClient groupVal = groupLifeOjkClientRepository.findGroupByPolicyNoAndIsValid(policyNo, true);
				GroupLifeOjkClient group = groupInVal == null ? groupVal : groupInVal;
				addrsMap.put(OjkConstant.ADDR_01, group.getAddress01());
				addrsMap.put(OjkConstant.ADDR_02, group.getAddress02());
				addrsMap.put(OjkConstant.ADDR_03, group.getAddress03());
			}
			geoCodeAddr.put(OjkConstant.ADDR_01, addrsMap.get(OjkConstant.ADDR_01) + " "
					+ addrsMap.get(OjkConstant.ADDR_02) + " " + addrsMap.get(OjkConstant.ADDR_03));
			geoCodeAddr.put(OjkConstant.ADDR_02,
					addrsMap.get(OjkConstant.ADDR_02) + " " + addrsMap.get(OjkConstant.ADDR_03));
			geoCodeAddr.put(OjkConstant.ADDR_03, addrsMap.get(OjkConstant.ADDR_03));
		} catch (Exception e) {
			LOGGER.error("Exception: OjkServiceImpl.getPolicyAddress, direct setDefaultArea " + e.getMessage(), e);
			this.setDefaultArea(ojk); // condition when getAddress == null
		}
		return geoCodeAddr;
	}

	private Map<String, String> getProvAndCity(Map<String, String> polAddrMap, String policyNo) {
		Map<String, String> addrMap = new HashMap<>();
		GeoCode geoCode = null;
		try {
			countHit++;
			Map<String, String> uriVar = new HashMap<>();
			uriVar.put(OjkConstant.ADDRESS_URIVAR, polAddrMap.get(OjkConstant.ADDR_01));
			uriVar.put(OjkConstant.ID, String.valueOf(countHit));
			LOGGER.info(GEOCODE_COUNT_LOG, policyNo, countHit, maxHit);
			geoCode = geoCodeService.runGeoCodeConvAddr(uriVar);
			addrMap = this.getGeoCodeResults(geoCode);
			if (!addrMap.containsKey(OjkConstant.MASTER_PROV) && !addrMap.containsKey(OjkConstant.MASTER_CITY)) {
				uriVar.clear();
				countHit++;
				uriVar.put(OjkConstant.ADDRESS_URIVAR, polAddrMap.get(OjkConstant.ADDR_02));
				uriVar.put(OjkConstant.ID, String.valueOf(countHit));
				LOGGER.info(GEOCODE_COUNT_LOG, policyNo, countHit, maxHit);
				geoCode = geoCodeService.runGeoCodeConvAddr(uriVar);
				addrMap = this.getGeoCodeResults(geoCode);
				if (!addrMap.containsKey(OjkConstant.MASTER_PROV) && !addrMap.containsKey(OjkConstant.MASTER_CITY)) {
					uriVar.clear();
					countHit++;
					uriVar.put(OjkConstant.ADDRESS_URIVAR, polAddrMap.get(OjkConstant.ADDR_03));
					uriVar.put(OjkConstant.ID, String.valueOf(countHit));
					LOGGER.info(GEOCODE_COUNT_LOG, policyNo, countHit, maxHit);
					geoCode = geoCodeService.runGeoCodeConvAddr(uriVar);
					addrMap = this.getGeoCodeResults(geoCode);
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception", e);
		}
		return addrMap;
	}

	private Map<String, String> getGeoCodeResults(GeoCode geoCode) {
		Map<String, String> addrMap = new HashMap<>();
		if (geoCode != null && ("OK").equals(geoCode.getStatus())) {
			List<Result> results = geoCode.getResults();
			for (Result result : results) {
				List<AddressComponent> addrComps = result.getAddress_components();
				for (AddressComponent addrComp : addrComps) {
					if (addrComp.getTypes().contains("administrative_area_level_2")) {
						addrMap.put(OjkConstant.MASTER_CITY,
								(addrComp.getLong_name().replace("Kabupaten", "KAB.")).toUpperCase());
					} else if (addrComp.getTypes().contains("administrative_area_level_1")) {
						addrMap.put(OjkConstant.MASTER_PROV,
								addrComp.getLong_name().replace("Daerah Khusus Ibukota", "DKI").toUpperCase());
					}
				}
			}
		}
		return addrMap;
	}

	private Area getArea(Map<String, String> addrMap) {
		Area area = null;
		if (addrMap.containsKey(OjkConstant.MASTER_PROV) && addrMap.containsKey(OjkConstant.MASTER_CITY)) {
			String prov = addrMap.get(OjkConstant.MASTER_PROV);
			String city = addrMap.get(OjkConstant.MASTER_CITY);
			area = areaRepository.findFirstByProvinceAndCity(prov, city);
			if (area == null) {
				List<Area> newAreas = new ArrayList<>();
				List<Area> provAreas = areaRepository.findByProvince(prov);
				if (!provAreas.isEmpty()) {
					List<String> words = WordUtil.getSplitWordList(city, " ");
					for (Area newArea : provAreas) {
						Boolean cityChecked = false;
						for (String word : words) {
							cityChecked = newArea.getCity().contains(word);
							if (!cityChecked) {
								break;
							}
						}
						if (cityChecked) {
							newAreas.add(newArea);
						}
					}
				}
				if (!newAreas.isEmpty()) {
					area = newAreas.get(0);
				}
			}
		}
		return area;
	}

	private void checkUncompleteDataPerSheet(Date from, Date to, String sheetName, String user) {
		List<String> newPolNoList = new ArrayList<>();
		List<Ojk> newOjksProc = new ArrayList<>();
		List<Ojk> ojksProc = ojkRepository.findByCategoryAndSubCategoryAndStatusAndCreateDateBetween(
				sheetName.substring(0, sheetName.lastIndexOf(' ')).toUpperCase(), sheetName.toUpperCase(),
				ReportConstant.PROCESSING, from, to);
		if (!ojksProc.isEmpty()) {
			for (Ojk ojk : ojksProc) {
				if (!newPolNoList.contains(ojk.getPolicyNo())) {
					newOjksProc.add(ojk);
					newPolNoList.add(ojk.getPolicyNo());
				}
			}
			String fileName = FileUtil.generateFileName(
					OjkConstant.UNCOMP_FILE_NAME + "_" + (sheetName.replace(" ", "_")).toUpperCase(), user);
			String attachName = fileName + ".csv";
			String filePath = env.getProperty(DIR_PATH_OUTPUT) + attachName;
			String headers = UNCOMP_DATA_HEADERS;
			Boolean fileCreated = FileUtil.createTextFile(newOjksProc, filePath, headers);
			if (fileCreated) {
				List<Config> confToIds = configRepository.findData(OjkConstant.OJK_MASTER_EMAIL_TO);
				String toIds = EmailUtil.buildIdsFromConfig(confToIds);
				String ccIds = "";
				this.saveAndEmailFileUncompleteData(toIds, ccIds, attachName, filePath, user);
			}
		}
	}

	private void saveAndEmailFileUncompleteData(String toIds, String ccIds, String attachName, String filePath,
			String user) {
		Report report = reportRepository.findByTemplate(OjkConstant.OJK_UNCOMP_NO_TEMP);
		
		if (report != null) {
			Email email = new Email();
			email.setStatus(ReportConstant.PROCESSING);
			email.setYgEmail(EmailConstant.EMAIL);
			email.setFromId(FROM_ID);
			email.setToId(toIds);
			email.setCcId(ccIds);
			email.setSubject(emailService.render(EmailConstant.SUBJECT_OJK_MASTER, this.getSubjectDate()));
			email.setContent(EmailConstant.CONTENT_OJK_MASTER);
			email.setAttachName(attachName);
			email.setAttachPath(filePath);
			email.setCreateBy(user);
			email.setReportId(report.getReportId());
			emailService.save(email);

			ReportFile file = new ReportFile();
			file.setRptId(report.getReportId());
			file.setFileName(attachName.substring(0, attachName.lastIndexOf('.')));
			file.setFolderPath(env.getProperty(DIR_PATH_OUTPUT));
			file.setCreateBy(user);
			file.setStatus(ReportConstant.COMPLETE);
			file.setVisible(true);
			reportFileRepository.save(file);
		}
	}

	private OjkMaster addOjkMasterCityAndProv(String policyNo, Area area, String user, String journalType) {
		OjkMaster ojkMaster = new OjkMaster();
		OjkMaster existOjkMaster = ojkMasterRepository.findFirstByPolicyNo(policyNo);
		String address = "";
		String idNo = "";
		if (journalType.equalsIgnoreCase(OjkConstant.JT_ASLI)) {
			AsliOjkClient ojkClient = asliOjkClientRepository.findAsliByPolicyNo(policyNo);
			address = (ojkClient == null) ? "" : (ojkClient.getAddress01() + " " + ojkClient.getAddress02() + " " + ojkClient.getAddress03());
			idNo = (ojkClient == null) ? "" : ojkClient.getIdNumber();
		} else if (journalType.equalsIgnoreCase(OjkConstant.JT_LIFE)) {
			GroupLifeOjkClient ojkClient = groupLifeOjkClientRepository.findLifeByPolicyNo(policyNo);
			address = (ojkClient == null) ? "" : (ojkClient.getAddress01() + " " + ojkClient.getAddress02() + " " + ojkClient.getAddress03());
			idNo = (ojkClient == null) ? "" : ojkClient.getIdNumber();
		} else if (journalType.equalsIgnoreCase(OjkConstant.JT_GASIA)) {
			GroupLifeOjkClient ojkClient = groupLifeOjkClientRepository.findGroupByPolicyNo(policyNo);
			address = (ojkClient == null) ? "" : (ojkClient.getAddress01() + " " + ojkClient.getAddress02() + " " + ojkClient.getAddress03());
			idNo = (ojkClient == null) ? "" : ojkClient.getIdNumber();
		}
		if (existOjkMaster == null) {
			ojkMaster.setPolicyNo(policyNo);
			ojkMaster.setAreaCode(area.getAreaCode());
			ojkMaster.setCity(area.getCity());
			ojkMaster.setProvince(area.getProvince());
			ojkMaster.setAddress(address.trim());
			ojkMaster.setIdNo(idNo);
			ojkMaster.setCreateBy(user);
			return ojkMaster;
		} else {
			existOjkMaster.setAreaCode(area.getAreaCode());
			existOjkMaster.setCity(area.getCity());
			existOjkMaster.setProvince(area.getProvince());
			existOjkMaster.setAddress(address.trim());
			existOjkMaster.setIdNo(idNo);
			existOjkMaster.setModifyBy(user);
			return existOjkMaster;
		}
	}

	private void setDefaultArea(Ojk ojk) {
		Area area = areaRepository.findFirstByAreaCode(OjkConstant.JAKSEL_AREA_CODE);
		if (area != null) {
			ojk.setAreaCode(area.getAreaCode());
			ojk.setCity(area.getCity());
			ojk.setProvince(area.getProvince());
			ojk.setStatus(ReportConstant.COMPLETE);
			ojk.setSourceOfAddress(OjkConstant.SOA_AREA_JASKEL);
			newOjks.add(ojk);
		}
	}

	private Map<String, String> getSubjectDate() {
		SimpleDateFormat sdfSubject = new SimpleDateFormat("MMMMM yyyy");
		Date date = new Date();
		String monthYear = sdfSubject.format(date);
		Map<String, String> params = new HashMap<>();
		params.put(EmailConstant.OJK_MONTH_YEAR, monthYear);
		return params;
	}
	
	private Map<String, String> getSubjectYear() {
		SimpleDateFormat sdfSubject = new SimpleDateFormat("yyyy");
		Date date = new Date();
		String year = sdfSubject.format(date);
		Map<String, String> params = new HashMap<>();
		params.put(EmailConstant.OJK_YEAR, year);
		return params;
	}
	
	// save file service
	@Async
	@Transactional
	public void saveFileData(XSSFWorkbook workbook, OjkRequest ojkReq) {
		for (String sheetName : ojkReq.getSheetNames()) {
			LOGGER.info("---START OJK INSERT DATA {} SHEET---", sheetName);
			
			List<Ojk> ojks = new ArrayList<>();
			XSSFSheet sheet = workbook.getSheet(sheetName);
			XSSFRow header = sheet.getRow(0);
			for (int index = 1; index <= sheet.getLastRowNum(); index++) {
				XSSFRow row = sheet.getRow(index);
				Ojk ojk = this.getCellValue(row, header);
				if (StringUtils.trimToNull(ojk.getAccountCode()) != null
						&& StringUtils.trimToNull(ojk.getTransRef()) != null) {
					LOGGER.info("{}, rowNo {}, transRef {}", sheetName, index, ojk.getTransRef());
					ojk.setPolicyNo(this.getPolicyNo(sheetName, ojk.getTransRef()));
					ojk.setStatus(ReportConstant.PROCESSING);
					ojk.setCategory(sheetName.trim().substring(0, sheetName.trim().lastIndexOf(' ')).toUpperCase());
					ojk.setSubCategory(sheetName.trim().toUpperCase());
					ojk.setCreateBy(ojkReq.getUser());
					ojk.setFrequency(ojkReq.getRptFreq());
					if (ojk.getSubCategory().equalsIgnoreCase(OjkConstant.CLAIM_HEALTH)) {
						ojk.setPolicyNo(this.setClaimHealthPolicyNo(ojk.getTransRef()));
					}
					this.completingData(ojk);
					ojks.add(ojk);
				}
			}
			ojkRepository.save(ojks);
			LOGGER.info("---OJK INSERT DATA {} SHEET, {} RECORDS, SUCCEED---", sheetName, ojks.size());
			ojkMasterRepository.save(ojksMaster);
			ojksMaster.clear();
			polNoList.clear();
			upPolNoList.clear();
			
			LOGGER.info("---END OJK INSERT DATA {} SHEET---", sheetName);
		}
		
		Date from = this.getFirstDateOfMonth();
		Date to = this.getEndDateOfMonth();
		UploadFile uploadFile = uploadFileRepository.findFirstByRptTypeAndDescAndStatusAndCreateDateBetweenAndIsScheduler(OjkConstant.OJK_SOURCE, ojkReq.getRptFreq(), ReportConstant.PROCESSING, from, to, true);
		if (null != uploadFile) {
			uploadFile.setStatus(ReportConstant.COMPLETE);
			uploadFile.setModifyBy(SYSTEM);
			uploadFileRepository.save(uploadFile);
		}
	}
	
	private Ojk getCellValue(XSSFRow row, XSSFRow header) {
		Ojk ojk = new Ojk();
		try {
			for (int index = 0; index <= header.getLastCellNum(); index++) {
				if (row.getCell(index) != null) {
					if ((header.getCell(index).getStringCellValue().trim()).equalsIgnoreCase(OjkConstant.ACC_CODE)) {
						ojk.setAccountCode(this.getStringCellValue(row.getCell(index)));
					} else if ((header.getCell(index).getStringCellValue().trim())
							.equalsIgnoreCase(OjkConstant.BASE_AMT)) {
						ojk.setBaseAmount(BigDecimal.valueOf(row.getCell(index).getNumericCellValue()));
					} else if ((header.getCell(index).getStringCellValue().trim())
							.equalsIgnoreCase(OjkConstant.JOURNAL_TYPE)) {
						ojk.setJournalType(this.getStringCellValue(row.getCell(index)));
					} else if ((header.getCell(index).getStringCellValue().trim())
							.equalsIgnoreCase(OjkConstant.TRANS_REF)) {
						ojk.setTransRef(this.getStringCellValue(row.getCell(index)));
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception getCellValue:" + e.getMessage(), e);
		}
		return ojk;
	}

	private String getStringCellValue(XSSFCell cell) {
		String cellVal = "";
		CellType cellType = cell.getCellTypeEnum();
		if (cellType == CellType.NUMERIC) {
			Long cellValD = (long) cell.getNumericCellValue();
			cellVal = cellValD.toString();
		} else {
			cellVal = cell.getStringCellValue().trim();
		}
		return cellVal;
	}

	private String getPolicyNo(String sheetName, String transRef) {
		String policyNo = "";
		if (sheetName.trim().equalsIgnoreCase(OjkConstant.CLAIM_HEALTH)) {
			// Nothing TO DO (keep empty)
		} else if (StringUtils.trimToNull(transRef) != null && transRef.contains("-")) {
			policyNo = transRef.substring(0, transRef.lastIndexOf('-'));
		} else {
			policyNo = transRef;
		}
		return policyNo;
	}

	private String setClaimHealthPolicyNo(String transRef){
		String newPolicyNo = "";
		try {
			GroupOjkPolNo groupPolNo = groupOjkPolNoRepository.findPolicyNoByTransRef(transRef);
			if (groupPolNo == null) {
				newPolicyNo = transRef;
			} else {
				if (StringUtils.trimToNull(groupPolNo.getPolicyNo()) == null) {
					newPolicyNo = transRef;
				} else {
					newPolicyNo = groupPolNo.getPolicyNo();
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception: OjkServiceImpl setClaimHealthPolicyNo:" + e.getMessage(), e);
		}
		return newPolicyNo;
	}
	
	private Ojk completingData(Ojk ojk) {
		List<Config> jtConfigs = configRepository.findData(OjkConstant.OJK_JT_NOT_DEFAULT);
		List<String> jtList = new ArrayList<>();
		for (Config config : jtConfigs) {
			jtList.add(config.getConfigValue());
		}
		try {
			ojk.setTotMember(this.setTotalMember(ojk));
			if (StringUtils.trimToNull(ojk.getJournalType()) == null
					|| StringUtils.trimToNull(ojk.getPolicyNo()) == null
					|| !jtList.contains(ojk.getJournalType().trim().toLowerCase())) {
				this.setDefaultCityAndProv(ojk);
				ojk.setUp(new BigDecimal(0)); // set default UP = 0
			} else if (jtList.contains(ojk.getJournalType().trim().toLowerCase())) {
				this.setCustomCityAndProv(ojk);
				ojk.setUp(this.setUpPerPolicyNo(ojk));
			}
		} catch (Exception e) {
			LOGGER.error("Exception: OjkServiceImpl completingData:" + e.getMessage(), e);
		}
		return ojk;
	}
	
	private Ojk setDefaultCityAndProv(Ojk ojk) {
		Area area = areaRepository.findFirstByAreaCode(OjkConstant.JAKSEL_AREA_CODE);
		if (area != null) {
			ojk.setAreaCode(area.getAreaCode());
			ojk.setCity(area.getCity());
			ojk.setProvince(area.getProvince());
			ojk.setStatus(ReportConstant.COMPLETE);
			ojk.setSourceOfAddress(OjkConstant.SOA_AREA_JASKEL);
		}
		return ojk;
	}

	private Ojk setCustomCityAndProv(Ojk ojk) {
		String policyNo = ojk.getPolicyNo() == null ? "" : ojk.getPolicyNo();
		try {
			OjkMaster ojkMaster = ojkMasterRepository.findFirstByPolicyNo(policyNo);
			if (ojk.getJournalType().trim().equalsIgnoreCase(OjkConstant.JT_ASLI)) {
				AsliOjkClient ojkClient = asliOjkClientRepository.findAsliByPolicyNo(policyNo);
				if (ojkClient == null) {
					this.setDefaultCityAndProv(ojk);
				} else if (ojkMaster != null) {
					String address = ojkClient.getAddress01() + " " + ojkClient.getAddress02() + " " + ojkClient.getAddress03();
					if (!ojkClient.isValid() && StringUtils.trimToNull(ojkMaster.getAddress()) != null && (ojkMaster.getAddress()).equalsIgnoreCase(address.trim())) {
						ojk.setAreaCode(ojkMaster.getAreaCode());
						ojk.setCity(ojkMaster.getCity());
						ojk.setProvince(ojkMaster.getProvince());
						ojk.setStatus(ReportConstant.COMPLETE);
						ojk.setSourceOfAddress(OjkConstant.SOA_OJK_MASTER);
					} else if (ojkClient.isValid()) {
						this.completingSetCustomCityAndProvByIdNo(ojk, ojkClient.getIdNumber(), address);
					}
				}
			} else if (ojk.getJournalType().trim().equalsIgnoreCase(OjkConstant.JT_LIFE)) {
				GroupLifeOjkClient ojkClient = groupLifeOjkClientRepository.findLifeByPolicyNo(policyNo);
				if (ojkClient == null) {
					this.setDefaultCityAndProv(ojk);
				} else if (ojkMaster != null) {
					String address = ojkClient.getAddress01() + " " + ojkClient.getAddress02() + " " + ojkClient.getAddress03();
					if (!ojkClient.isValid() && StringUtils.trimToNull(ojkMaster.getAddress()) != null && (ojkMaster.getAddress()).equalsIgnoreCase(address.trim())) {
						ojk.setAreaCode(ojkMaster.getAreaCode());
						ojk.setCity(ojkMaster.getCity());
						ojk.setProvince(ojkMaster.getProvince());
						ojk.setStatus(ReportConstant.COMPLETE);
						ojk.setSourceOfAddress(OjkConstant.SOA_OJK_MASTER);
					} else if (ojkClient.isValid()) {
						this.completingSetCustomCityAndProvByIdNo(ojk, ojkClient.getIdNumber(), address);
					}
				}
			} else if (ojk.getJournalType().trim().equalsIgnoreCase(OjkConstant.JT_GASIA)) {
				GroupLifeOjkClient ojkClient = groupLifeOjkClientRepository.findGroupByPolicyNo(policyNo);
				if (ojkClient == null) {
					this.setDefaultCityAndProv(ojk);
				} else if (ojkMaster != null) {
					String address = ojkClient.getAddress01() + " " + ojkClient.getAddress02() + " " + ojkClient.getAddress03();
					if (!ojkClient.isValid() && StringUtils.trimToNull(ojkMaster.getAddress()) != null && (ojkMaster.getAddress()).equalsIgnoreCase(address.trim())) {
						ojk.setAreaCode(ojkMaster.getAreaCode());
						ojk.setCity(ojkMaster.getCity());
						ojk.setProvince(ojkMaster.getProvince());
						ojk.setStatus(ReportConstant.COMPLETE);
						ojk.setSourceOfAddress(OjkConstant.SOA_OJK_MASTER);
					} else if (ojkClient.isValid()) {
						this.completingSetCustomCityAndProvByIdNo(ojk, ojkClient.getIdNumber(), address);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception, setCustomCityAndProv: " + e.getMessage(), e);
		}
		return ojk;
	}

	private Long setTotalMember(Ojk ojk) {
		Long totMbr = 1L;
		String policyNo = ojk.getPolicyNo() == null ? "" : ojk.getPolicyNo();
		if (ojk.getSubCategory().equalsIgnoreCase(OjkConstant.PREMI_HEALTH)) {
			try {
				if(polNoList.contains(policyNo)) {
					totMbr = 0L;
				} else {
					Long phTotMbr = groupLifeOjkClientRepository.countGroupPremiHealthTotalMember(policyNo);
					totMbr = (phTotMbr == 0) ? totMbr : phTotMbr;
					polNoList.add(policyNo);
				}
			} catch (Exception e) {
				LOGGER.error("Exception : OjkServiceImpl setTotalMember " + e.getMessage(), e);
			}
		} else if (ojk.getSubCategory().equalsIgnoreCase(OjkConstant.CLAIM_HEALTH)) {
			// Nothing TO DO (keep 1L)
		} else {
			if(polNoList.contains(policyNo)) {
				totMbr = 0L;
			} else {
				polNoList.add(policyNo);
			}
		}
		return totMbr;
	}
	
	private BigDecimal setUpPerPolicyNo(Ojk ojk) {
		BigDecimal up = new BigDecimal(0);
		String policyNo = ojk.getPolicyNo() == null ? "" : ojk.getPolicyNo();
		
		if (!upPolNoList.contains(policyNo) && ojk.getCategory().equalsIgnoreCase(OjkConstant.PREMI)) {
			if (ojk.getJournalType().equalsIgnoreCase(OjkConstant.JT_ASLI)) {
				BigDecimal value = asliOjkClientRepository.getUpAsliByPolicyNo(policyNo);
				up = (value != null) ? value : up;
			} else if (ojk.getJournalType().equalsIgnoreCase(OjkConstant.JT_LIFE)) {
				BigDecimal value = groupLifeOjkClientRepository.getUpLifeByPolicyNo(policyNo);
				up = (value != null) ? value : up;
			} else if (ojk.getJournalType().equalsIgnoreCase(OjkConstant.JT_GASIA)) {
				String contractType = groupLifeOjkClientRepository.getGroupContractTypeByPolicyNo(policyNo);
				if (contractType != null && contractType.equalsIgnoreCase(OjkConstant.GNL)) {
					BigDecimal value = groupLifeOjkClientRepository.getUpGroupByPolicyNo(policyNo);
					up = (value != null) ? value : up;
				}
			}
			upPolNoList.add(policyNo);
		}
		return up;
	}

	private Ojk completingSetCustomCityAndProvByIdNo(Ojk ojk, String idNumber, String address) {
		Area area = areaRepository.findFirstByAreaCode(idNumber.substring(0, 4));
		if (area != null) {
			ojk.setAreaCode(area.getAreaCode());
			ojk.setCity(area.getCity());
			ojk.setProvince(area.getProvince());
			ojk.setStatus(ReportConstant.COMPLETE);
			ojk.setSourceOfAddress(OjkConstant.SOA_ID_NO + idNumber);
			this.addOjkMasterCityAndProv(area, ojk.getPolicyNo(), idNumber, address);
		}
		return ojk;
	}

	private void addOjkMasterCityAndProv(Area area, String policyNo, String idNo, String address) {
		OjkMaster existOjkMaster = ojkMasterRepository.findFirstByPolicyNo(policyNo);
		if (null == existOjkMaster) {
			OjkMaster ojkMaster = new OjkMaster();
			ojkMaster.setPolicyNo(policyNo);
			ojkMaster.setAreaCode(area.getAreaCode());
			ojkMaster.setCity(area.getCity());
			ojkMaster.setProvince(area.getProvince());
			ojkMaster.setIdNo(idNo);
			ojkMaster.setAddress(address.trim());
			ojkMaster.setCreateBy(SYSTEM);
			ojksMaster.add(ojkMaster);
		} else {
			existOjkMaster.setAreaCode(area.getAreaCode());
			existOjkMaster.setCity(area.getCity());
			existOjkMaster.setProvince(area.getProvince());
			existOjkMaster.setIdNo(idNo);
			existOjkMaster.setAddress(address.trim());
			existOjkMaster.setModifyBy(SYSTEM);
			ojksMaster.add(existOjkMaster);
		}
		if (ojksMaster.size() == maxUpdateData) {
			ojkMasterRepository.save(ojksMaster);
			ojksMaster.clear();
		}
	}
	
	private Date getFirstDateOfMonth() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DATE, 1);
		String startDate = sdfDate.format(cal.getTime());
		Date from = null;
		try {
			from = sdfDateTime.parse(startDate + "000000");
		} catch (ParseException e) {
			LOGGER.error("ParseException:" + e.getMessage(), e);
		}
		return from;
	}

	private Date getEndDateOfMonth() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
		String endDate = sdfDate.format(cal.getTime());
		Date to = null;
		try {
			to = sdfDateTime.parse(endDate + "235959");
		} catch (ParseException e) {
			LOGGER.error("ParseException:" + e.getMessage(), e);
		}
		return to;
	}

	@Override
	public String geoCodeResetSetting() {
		Set<String> configNames = new HashSet<>();
		configNames.add(OjkConstant.OJK_GEOCODE_CURRENT_MONTH);
		configNames.add(OjkConstant.OJK_GEOCODE_SHEET_RUNNING_PER_DAY);
		configNames.add(OjkConstant.OJK_GEOCODE_SHEET_SUM_RUNNED);
		configNames.add(OjkConstant.OJK_GEOCODE_AVAILABLE_DAY);
		configNames.add(OjkConstant.OJK_GEOCODE_SHEET_DAY_COUNT);
		List<Config> configs = configRepository.findByConfigNameIn(configNames);
		for (Config config : configs) {
			if (config.getConfigName().equalsIgnoreCase(OjkConstant.OJK_GEOCODE_SHEET_DAY_COUNT)) {
				config.setConfigValue(String.valueOf(1));
			} else {
				config.setConfigValue(String.valueOf(0));
			}
		}
		configRepository.save(configs);
		LOGGER.info("-----GEOCODE OJK RESET SETTING SUCCESS, id {}-----", Thread.currentThread().getId());
		return "RESET SUCCESS";
	}

	@Override
	public void deleteByOjkIdIn(Set<UUID> ojkIds) {
		ojkRepository.deleteByOjkIdIn(ojkIds);
	}
	
	@Override
	public void delete(List<Ojk> ojks) {
		ojkRepository.delete(ojks);
	}

	@Override
	public List<Ojk> findByFrequencyAndCreateDateBetween(String rptFreq, Date from, Date to) {
		return ojkRepository.findByFrequencyAndCreateDateBetween(rptFreq, from, to);
	}

}
