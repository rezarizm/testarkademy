package id.co.astralife.app.report.security.filter;

import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class SimpleCORSFilter implements Filter {

    public static final String REQUEST_HEADER_ORIGIN = "Origin";

    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String origin = request.getHeader(SimpleCORSFilter.REQUEST_HEADER_ORIGIN);

        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Allow-Origin", origin);
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE, PUT");
        response.setHeader("Access-Control-Max-Age", "3600");
        //firefox send lower case content-type for OPTIONS
        response.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, content-type, Accept, User");
        chain.doFilter(req, res);
    }

    public void init(FilterConfig filterConfig) {
    	//
    }

    public void destroy() {
    	//
    }

}