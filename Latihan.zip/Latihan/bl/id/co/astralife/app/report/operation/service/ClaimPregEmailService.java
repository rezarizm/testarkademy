package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface ClaimPregEmailService {

	void processEmail(UUID reportId, String startDate, String endDate, String user);
	
}
