package id.co.astralife.app.report.finance.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.finance.service.AgentETaxService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;

@Service
public class AgentETaxServiceImpl implements AgentETaxService{

	@Autowired
    ReportGenerator reportGenerator;

    @Autowired
    ReportService reportService;

	@Override
	public void generateAgentETax(UUID reportId, String user) {
		Report report =  reportService.findByReportId(reportId);
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
		if(report!=null){
				params.put(ReportConstant.FILENAME_PARAM, FileUtil.generateFileName(report.getRptName(), user));
				reportGenerator.generate(report.getReportId(), user, params);
		}
	}
}
