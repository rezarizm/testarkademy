package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.GroupPolicyConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.GroupPolicyService;
import id.co.astralife.app.report.report.service.ReportService;

public class GroupPolicyJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(GroupPolicyJob.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private GroupPolicyService groupPolicyService;
	
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START GROUP LIFE POLICY Job----------");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    	
        Calendar date = Calendar.getInstance();
        date.add(Calendar.DATE, -1);
        String startDate  = sdf.format(date.getTime());
        
        Report report = reportService.findByTemplate(GroupPolicyConstant.GROUP_LIFE_POLICY);
        if (report != null){
        	groupPolicyService.generateGroupPolicy(report.getReportId(), "SYSTEM", startDate, startDate);
        }
		LOGGER.info("----------END GROUP LIFE POLICY Job----------");
	}	
}
