package id.co.astralife.app.report.web;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import id.co.astralife.app.report.common.AutoRenewalConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.AutoRenewalRequest;
import id.co.astralife.app.report.operation.service.AutoRenewalService;
import id.co.astralife.app.report.report.service.ReportService;

@RestController
@RequestMapping(value = "/report/service")
public class AutoRenewalController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AutoRenewalController.class);
	private static final String IS_SUCCESS = "success";
	private static final String IS_FAILED = "failed";
	private static final String ERROR_MESSAGE = "errorMessage";
	
	private final AutoRenewalService autoRenewalService;
	private final ReportService reportService;
	
	@Autowired
	public AutoRenewalController(AutoRenewalService autoRenewalService, ReportService reportService) {
		this.autoRenewalService = autoRenewalService;
		this.reportService = reportService;
	}
	
	/**
	 * @param user = SYSTEM / user *
	 * @param startDate = yyyyMMDD *
	 * @param endDate = yyyyMMdd *
	 * @param email = true / false
	 * @param duplicate = true / false
	 *
	 * @param user = SYSTEM / user *
	 * @param policyNo = 00000000 *
	 * @param email = true/false
	 * @param duplicate = true/false
	 * 
	 * @return success
	 */
	
	@RequestMapping(value = "/renewal", method = RequestMethod.POST)
	public String generatePropRenewal(@RequestBody AutoRenewalRequest renewReq, HttpServletResponse response) {
		try {
			Boolean dateSelection = StringUtils.trimToNull(renewReq.getUser()) != null
					&& StringUtils.trimToNull(renewReq.getStartDate()) != null
					&& StringUtils.trimToNull(renewReq.getEndDate()) != null;
			Boolean policySelection = StringUtils.trimToNull(renewReq.getUser()) != null
					&& StringUtils.trimToNull(renewReq.getPolicyNo()) != null;
			Boolean billSelection = StringUtils.trimToNull(renewReq.getUser()) != null
					&& StringUtils.trimToNull(renewReq.getMonthYear()) != null;
			Report reportProp = reportService.findByTemplate(AutoRenewalConstant.PROP_AUTO_RENEWAL);
			Report reportBill = reportService.findByTemplate(AutoRenewalConstant.BILL_AUTO_RENEWAL);
			
			ObjectMapper mapper = new ObjectMapper();
			String params = mapper.writeValueAsString(renewReq);
			
			if (billSelection) {
				autoRenewalService.generateBillAutoRenewal(renewReq);
				LOGGER.info("Generate Report {} with params: {}", reportBill.getRptDesc(), params);
			}
			else if (dateSelection || policySelection) {
				autoRenewalService.generatePropAutoRenewal(renewReq);
				LOGGER.info("Generate Report {} with params {}", reportProp.getRptDesc(), params);
			} else {
				throw new IllegalAccessError();
			}
		} catch (IllegalAccessError e) {
			LOGGER.error("IllegalAccessError:{}", e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ":" + e.getMessage();
		} catch (JsonProcessingException e) {
			LOGGER.error("JsonProcessingException:{}", e.getMessage(), e);
		}
		return IS_SUCCESS;
	}
}
