package id.co.astralife.app.report.sales.support.service.impl;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.common.util.EmailUtil;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ZipGenerator;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.report.service.ReportFileService;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.ReNovaService;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.export.SimpleCsvExporterConfiguration;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleWriterExporterOutput;


/**
 * 
 * @author Michael
 * 
 * @Since 26 Jul 2017
 */
@Service
public class ReNovaServiceImpl implements ReNovaService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ReNovaServiceImpl.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private ReportFileService reportFileService;

	@Autowired
	@Qualifier("iplusDataSource")
	private DataSource dataSourceiPlus;
    
    @Autowired
    private ConfigRepository configRepository;

	@Autowired
	private ZipGenerator zipGenerator;

	@Autowired
	Environment env;
	
	@Override
	public Integer getReNovaRows() {
		String sql = "SELECT COUNT(*) AS TOTAL_ROWS FROM " + 
					 "TABLE(pkg_rpt_renova.get_agt_renova)";
		Connection conn = null;
		Integer rows = null;
		
		try {
			conn = dataSourceiPlus.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			rs.next();
			rows = rs.getInt("TOTAL_ROWS");
			rs.close();
			ps.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					LOGGER.error("SQLException : "+ e);
				}
			}
		}			
		return rows;
	}
	
	@Override
	public Integer getMaxRow() {
		List<Config> configs = configRepository.findData(SalesSupportConstant.RENOVA_MAX_ROW);
		String rowValue = EmailUtil.buildIdsFromConfig(configs);
		
		return Integer.parseInt(rowValue);
	}
	
	@Override
	public void generateReNova(UUID reportId, String user, String date) {
		String pathOutput = env.getProperty("dir.pathOutput");
		
		Report report = reportService.findByReportId(reportId);
		
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
		params.put(ReportConstant.FIELD_DELIMITER, ReportConstant.DELIMITER_PIPE);
		
		int totalRows = getReNovaRows();
		int maxRow = getMaxRow();
		int rowContinue = maxRow - 1;
		String zipFileName = FileUtil.generateFileName("iPlus" + date, user);
		
		if(report != null) {
			int fileNumber = (int) Math.ceil((double)totalRows / maxRow);
			List<File> files = new ArrayList<>(fileNumber);
			int rows = 0;
			for (int x = 1; x <= fileNumber; x++) {
				String fileName = FileUtil.generateFileName("iPlus" + date, user);
				rows += 1;
				params.put("ROWSTART", rows);
				rows += rowContinue;
				params.put("ROWEND", rows);
				params.put(ReportConstant.FILENAME_PARAM, fileName);
				generateReport(report.getReportId(), user, params);
				files.add(new File(pathOutput + fileName + ".txt"));
			}
			
			//Zip all texts file into 1 zip file.
			Map<String, Object> zipParams = new HashMap<>();
			zipParams.put(ReportConstant.FILEPATH_PARAM, pathOutput + zipFileName + ".zip");
			
			zipGenerator.generateZip(files, zipParams);		
			
			ReportFile reportFile = new ReportFile();
	        reportFile.setRptId(reportId);
	        reportFile.setFileName(zipFileName);
	        reportFile.setFolderPath(pathOutput);
	        reportFile.setCreateBy(user);
	        reportFile.setStatus(ReportConstant.COMPLETE);
	        reportFile.setVisible(true);
	        reportFileService.save(reportFile);
	        
			//Delete files.
	        for(File file : files) {
				file.delete();
			}
		}
	}
	
	//Duplicate method from ReportGenerator since in ReportGenerator the method is @Async.
	//Add zipFileName parameter.
	@Override
	public void generateReport(UUID reportId, String user, Map<String, Object> params) {
		String pathInput = env.getProperty("dir.pathInput");
		String pathOutput = env.getProperty("dir.pathOutput");

        Report report = reportService.findByReportId(reportId);
        
        String url = pathInput + report.getTemplate() + ".jasper";

        String fileName;
        if (params.get(ReportConstant.FILENAME_PARAM) != null) {
            fileName = params.get(ReportConstant.FILENAME_PARAM).toString();
            params.remove(ReportConstant.FILENAME_PARAM);
        } else {
            fileName = FileUtil.generateDefaultFileName(report.getRptName(), user);
        }
        
        Connection conn = null;
        String filePath = "";
        try {
        	conn = dataSourceiPlus.getConnection();
        	JasperPrint jasperPrint = JasperFillManager.fillReport(url, params, conn);
        	JRCsvExporter exporter = new JRCsvExporter();
			exporter.setExporterInput(new SimpleExporterInput (jasperPrint));
        	filePath = pathOutput + fileName + ".txt";
        	exporter.setExporterOutput(new SimpleWriterExporterOutput(filePath));
        	SimpleCsvExporterConfiguration config = new SimpleCsvExporterConfiguration();
        	config.setFieldDelimiter(params.get(ReportConstant.FIELD_DELIMITER).toString());
        	config.setRecordDelimiter("\r\n");
        	exporter.setConfiguration(config);
        	exporter.exportReport();
        } catch (SQLException e) {
            LOGGER.error("ReNovaService: SQL Exception", e);
        } catch (JRException e) {
            LOGGER.error("ReNovaService: JRException", e);
    	} catch (Exception e) {
            LOGGER.error("ReNovaService: Exception", e);
        } finally {
            if (null != conn) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    LOGGER.error("Unable to close connection", ex);
                }
            }
        } 
	}
}