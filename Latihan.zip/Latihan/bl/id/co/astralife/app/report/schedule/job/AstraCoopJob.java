package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.AstraCooperationService;

public class AstraCoopJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(AstraCoopJob.class);
	
	@Autowired
    private ReportService reportService;
	
	@Autowired
	private AstraCooperationService astraCooperationService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START Koperasi Astra Job----------");
		
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
        Calendar calendar = Calendar.getInstance();
		String dateString = sdf.format(calendar.getTime());
		
        Report report = reportService.findByTemplate(SalesSupportConstant.ASTRA_COOP_CERT);
        if (null != report) {
        	astraCooperationService.generateAstraCooperation(report.getReportId(), "SYSTEM", dateString);
        }
        
        LOGGER.info("----------END Koperasi Astra Job----------");
	}
}
