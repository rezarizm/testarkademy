package id.co.astralife.app.report.operation.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import id.co.astralife.app.report.common.AsoConstant;
import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.EmailUtil;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.model.AsoLetterEntity;
import id.co.astralife.app.report.model.AsoReportEntity;
import id.co.astralife.app.report.model.AsoSetupDTO;
import id.co.astralife.app.report.operation.service.AsoService;
import id.co.astralife.app.report.report.service.ReportService;

@Service
public class AsoServiceImpl implements AsoService {

  private static final Logger LOGGER = LoggerFactory.getLogger(AsoServiceImpl.class);
  private static final String ASO_URL = "aso.service.url";
  private static final String PARAM_POLNO = "policyNumber";
  private static final String RESPONSE_LOG = "{} {}";
  
  private final ReportService reportService;
  private final ReportGenerator reportGenerator;
  private final Environment env;
  private final ConfigRepository configRepository;

  private RestTemplate restTemplate = new RestTemplate();

  @Autowired
  public AsoServiceImpl(ReportService reportService, ReportGenerator reportGenerator,
      Environment env, ConfigRepository configRepository) {
    this.reportService = reportService;
    this.reportGenerator = reportGenerator;
    this.env = env;
    this.configRepository = configRepository;
  }

  @Override
  public void generateAsoReport(UUID reportId, String user, Boolean email) {
    Report report = reportService.findByReportId(reportId);
    List<AsoReportEntity> asoReports = new ArrayList<>();
    Map<String, Object> params = new HashMap<>();
    ObjectMapper mapper = new ObjectMapper();
    
    try {
      String listUrl = env.getProperty(ASO_URL) + env.getProperty("aso.all.policy");
      ResponseEntity<String> response = restTemplate.getForEntity(listUrl, String.class);
      LOGGER.info(RESPONSE_LOG, listUrl, response);
      List<AsoSetupDTO> asoSetups = mapper.readValue(response.getBody(), new TypeReference<List<AsoSetupDTO>>() {});
      
      for (AsoSetupDTO asoSetup : asoSetups) {
        String validUrl = env.getProperty(ASO_URL) + env.getProperty("aso.valid.policy");
        UriComponentsBuilder uri = UriComponentsBuilder.fromHttpUrl(validUrl).queryParam(PARAM_POLNO, asoSetup.getPolicyNo());
        String uriString = uri.toUriString();
        ResponseEntity<String> responseValid = restTemplate.getForEntity(uriString, String.class);
        LOGGER.info(RESPONSE_LOG, uriString, responseValid);
        
        JSONObject jsonObject = new JSONObject(responseValid.getBody());
        Boolean valid = jsonObject.getBoolean("validFlag");
        
        if (valid) {
          String claimUrl = env.getProperty(ASO_URL) + env.getProperty("aso.claim.policy");
          UriComponentsBuilder claimUri = UriComponentsBuilder.fromHttpUrl(claimUrl)
              .queryParam(PARAM_POLNO, asoSetup.getPolicyNo())
              .queryParam("threshold", asoSetup.getThreshold())
              .queryParam("deposit", asoSetup.getDeposit());
          String claimUriString = claimUri.toUriString();
          ResponseEntity<String> responseClaim = restTemplate.getForEntity(claimUriString, String.class);
          LOGGER.info(RESPONSE_LOG, claimUriString, responseClaim);
          List<AsoReportEntity> asoReport = mapper.readValue(responseClaim.getBody(), new TypeReference<List<AsoReportEntity>>() {});
          asoReports.addAll(asoReport);
        }
      }
      String fileName = FileUtil.generateFileName(report.getRptName(), user);
      String dataJson = mapper.writeValueAsString(asoReports);
      params.put(ReportConstant.FILENAME_PARAM, fileName);
      params.put(AsoConstant.JSON_SOURCE, dataJson);
      if (email) {
        List<Config> configs = configRepository.findData(AsoConstant.ASO_EMAIL_TO);
        String emailTo = EmailUtil.buildIdsFromConfig(configs);
        String attachmentName = fileName + "." + (report.getFormat().equals("XLS") ? "xlsx" : report.getFormat().toLowerCase());
        String filePath = env.getProperty("dir.pathOutput");
        params.put(EmailConstant.EMAIL, true);
        params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
        params.put(EmailConstant.PARAM_EMAIL_FROM, EmailConstant.EMAIL_SENDER_NO_REPLY);
        params.put(EmailConstant.PARAM_TO_ID, emailTo);
        params.put(EmailConstant.PARAM_SUBJECT, "GROUP ASO Report" + fileName);
        params.put(EmailConstant.PARAM_CONTENT, AsoConstant.EMAIL_CONTENT);
        params.put(EmailConstant.PARAM_ATTACH_NAME, attachmentName);
        params.put(EmailConstant.PARAM_FILEPATH, filePath + attachmentName);
      }
      reportGenerator.generate(report.getReportId(), user, params);
    } catch (IOException e) {
      LOGGER.error("IOException:{}", e.getMessage());
    } catch (Exception e) {
      LOGGER.error("Exception:{}", e.getMessage());
    } 

  }

  @Override
  public Boolean generateAsoLetter(UUID reportId, String policyNo, String user) {
    LOGGER.info("-----START Processing ASO Letter Policy No {} by {}-----", policyNo, user);
    Report report = reportService.findByReportId(reportId);
    Map<String, Object> params = new HashMap<>();
    ObjectMapper mapper = new ObjectMapper();
    Boolean valid = false;
    try {
      String url = env.getProperty(ASO_URL) + env.getProperty("aso.setting.policy");
      UriComponentsBuilder uri = UriComponentsBuilder.fromHttpUrl(url).queryParam(PARAM_POLNO, policyNo);
      String uriString = uri.toUriString();
      ResponseEntity<String> response = restTemplate.getForEntity(uriString, String.class);
      LOGGER.info(RESPONSE_LOG, uriString, response);
      AsoSetupDTO asoSetup = mapper.readValue(response.getBody(), AsoSetupDTO.class);
      
      String validUrl = env.getProperty(ASO_URL) + env.getProperty("aso.valid.policy");
      UriComponentsBuilder validUri = UriComponentsBuilder.fromHttpUrl(validUrl).queryParam(PARAM_POLNO, asoSetup.getPolicyNo());
      String validUriString = validUri.toUriString();
      ResponseEntity<String> responseValid = restTemplate.getForEntity(validUriString, String.class);
      LOGGER.info(RESPONSE_LOG, validUriString, responseValid);
      JSONObject jsonObject = new JSONObject(responseValid.getBody());
      
      String letterUrl = env.getProperty(ASO_URL) + env.getProperty("aso.letter.policy");
      UriComponentsBuilder letterUri = UriComponentsBuilder.fromHttpUrl(letterUrl)
          .queryParam(PARAM_POLNO, asoSetup.getPolicyNo())
          .queryParam("threshold", asoSetup.getThreshold())
          .queryParam("deposit", asoSetup.getDeposit());
      String letterUriString = letterUri.toUriString();
      ResponseEntity<String> responseClaim = restTemplate.getForEntity(letterUriString, String.class);
      AsoLetterEntity asoLetter = mapper.readValue(responseClaim.getBody(), AsoLetterEntity.class);
      LOGGER.info(RESPONSE_LOG, letterUriString, responseClaim);
      
      valid = jsonObject.getBoolean("validFlag");
      if (valid) {
        String fileName = FileUtil.generateFileName(report.getRptName() + "_" + policyNo, user);
        String dataJson = mapper.writeValueAsString(asoLetter);
        params.put("aso_assign_name", configRepository.findByConfigName("ASO_ASSIGN_NAME").getConfigValue());
        params.put("aso_design_title", configRepository.findByConfigName("ASO_DESIGN_TITLE").getConfigValue());
        params.put("aso_design_email", configRepository.findByConfigName("ASO_DESIGN_EMAIL").getConfigValue());
        params.put(ReportConstant.FILENAME_PARAM, fileName);
        params.put(AsoConstant.JSON_SOURCE, dataJson);
        reportGenerator.generate(report.getReportId(), user, params);
        LOGGER.info("-----ASO Letter Policy No {} by {} has been processed-----", policyNo, user);
      }
    } catch (IOException e) {
      LOGGER.error("-----Processing ASO Letter Policy No {} by {} is failed-----", policyNo, user);
      LOGGER.error("IOException:{}", e.getMessage());
    } catch (Exception e) {
      LOGGER.error("-----Processing ASO Letter Policy No {} by {} is failed-----", policyNo, user);
      LOGGER.error("Exception:{}", e.getMessage());
    }
    LOGGER.info("-----END Processing ASO Letter Policy No {} by {}-----", policyNo, user);
    return valid;
  }

}
