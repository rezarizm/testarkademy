package id.co.astralife.app.report.schedule.job;

import java.util.List;

import id.co.astralife.app.report.common.FinanceConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.actuary.service.PersistencyService;
import id.co.astralife.app.report.local.entity.Report;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

public class PersistencyJob extends QuartzJobBean{

	private static final Logger LOGGER = LoggerFactory.getLogger(PersistencyJob.class);
	
	@Autowired
	PersistencyService persistencyService;
	
	@Autowired
	ReportService reportService;
	
	@Autowired
    ReportGenerator reportGenerator;
	
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {	
		LOGGER.info("----------START Persistency Job----------");
		
		List<Report> report = reportService.findBySchedule(ReportConstant.MONTHLY);
		
		for (Report rpt : report) {
			if (rpt.getTemplate().equals(FinanceConstant.PERSISTENCY)) {
				persistencyService.generatePersistency(rpt.getReportId(), "SYSTEM");
			} 
		}
		LOGGER.info("----------END Persistency Job----------");
	}

}
