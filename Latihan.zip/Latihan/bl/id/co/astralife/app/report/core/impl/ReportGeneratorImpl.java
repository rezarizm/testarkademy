package id.co.astralife.app.report.core.impl;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.sql.DataSource;

import id.co.astralife.app.report.common.*;
import id.co.astralife.app.report.poi.ExcelTool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ProtectFileService;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.core.ZipGenerator;
import id.co.astralife.app.report.email.service.EmailService;
import id.co.astralife.app.report.local.entity.Email;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.pgp.service.PGPService;
import id.co.astralife.app.report.report.service.ReportFileService;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sftp.service.SFTPService;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JsonDataSource;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleCsvExporterConfiguration;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;
import net.sf.jasperreports.export.SimpleWriterExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;
import net.sf.jasperreports.export.type.PdfaConformanceEnum;

@Service
public class ReportGeneratorImpl implements ReportGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(ReportGeneratorImpl.class);
    private static final String XLSX_FORMAT = ".xlsx";
    
    @Autowired
    private Environment env;
    
    @Autowired
    @Qualifier("mirrorDataSource")
    private DataSource dataSource;

    @Autowired
    @Qualifier("iplusDataSource")
    private DataSource dataSourceiPlus;

    @Autowired
    @Qualifier("aolDataSource")
    private DataSource dataSourceAol;

    @Autowired
    @Qualifier("vmsDataSource")
    private DataSource dataSourceVms;

    @Autowired
    @Qualifier("localDataSource")
    private DataSource dataSourceLocal;
    
    @Autowired
    @Qualifier("vitDataSource")
    private DataSource dataSourcevit;
    
    @Autowired
    @Qualifier("odsrptDataSource")
    private DataSource odsrptDataSource;
    
    @Autowired
    @Qualifier("dmDataSource")
    private DataSource dmDataSource;
    
    @Autowired
    private ReportFileService reportFileService;

    @Autowired
    private ReportService reportService;

    @Autowired
    private ZipGenerator zipGenerator;

    @Autowired
	private EmailService emailService;

    @Autowired
    private ProtectFileService protectFileService;
    
    @Autowired
    private PGPService pgpService;
    
    @Autowired
    private SFTPService sftpService;
    
    @Value("${dir.pathInput}")
	private String pathInput;
    
    @Value("${dir.pathOutput}")
	private String pathOutput;
    
    @Async
    @Override
    public void generate(UUID reportId, String user, Map<String, Object> params) {
        Report report = reportService.findByReportId(reportId);
        
        String url = pathInput + report.getTemplate() + ".jasper";
        LOGGER.debug("Report input URL: {}", url);

        String fileName;
        if (params.get(ReportConstant.FILENAME_PARAM) != null) {
            fileName = params.get(ReportConstant.FILENAME_PARAM).toString();
            params.remove(ReportConstant.FILENAME_PARAM);
        } else {
            fileName = FileUtil.generateDefaultFileName(report.getRptName(), user);
        }
        LOGGER.debug("Report filename: {}", fileName);

        LOGGER.info("------ START GENERATE FILE {} from Report {} ------", fileName, report.getRptDesc());
        
        ReportFile reportFile = new ReportFile();
        reportFile.setRptId(reportId);
        reportFile.setFileName(fileName);
        reportFile.setFolderPath(pathOutput);
        reportFile.setCreateBy(user);
        reportFile.setStatus(ReportConstant.PROCESSING);
        if (params.containsKey(EmailConstant.EMAIL)){
    		if (params.containsKey(EmailConstant.IS_VISIBLE)) {
				reportFile.setVisible(true);
    		} else {
    			reportFile.setVisible(false);
    		}
        } else {
        	reportFile.setVisible(true);
        }
        reportFileService.save(reportFile);

        ReportFile newFile = reportFileService.findById(reportFile.getId());

        Connection conn = null;
        String filePath = "";
        try {
            if (!params.containsKey(AsoConstant.JSON_SOURCE)) {
                conn = this.getConnection(params);
            }
        	filePath = this.createFile(report, url, params, conn, fileName);
            newFile.setModifyBy(user);
            newFile.setStatus(ReportConstant.COMPLETE);
            this.copyFile(params, fileName, filePath);
        } catch (SQLException e) {
            newFile.setStatus(ReportConstant.FAILED);
            LOGGER.error("ReportGenerator: SQL Exception", e);
        } catch (JRException e) {
            newFile.setStatus(ReportConstant.FAILED);
            LOGGER.error("ReportGenerator: JRException", e);
    	} catch (Exception e) {
        	newFile.setStatus(ReportConstant.FAILED);
            LOGGER.error("ReportGenerator: Exception", e);
        } finally {
            reportFileService.save(newFile);
            if (null != conn) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    LOGGER.error("Unable to close connection", ex);
                }
            }
        }
        
        // mandatory params = zip_comp, filePath
        this.zipFile(params, newFile, filePath);
        
        // mandatory params = xls_pass
        this.protectXls(params, newFile, report, pathOutput, fileName);
        
        // mandatory params = E, ygemail
        this.emailFile(params, newFile, report, user);
        
        // mandatory params = pgpEncrypt
        this.pgpEncrypt(params, newFile, filePath);
        
        // mandatory params = sftp
        this.copySFTP(params, pathOutput);
        
        LOGGER.info("------ END GENERATE FILE {} from Report {} ------", fileName, report.getRptDesc());
    }

    @Override
	public Connection getConnection(Map<String, Object> params) throws SQLException {
		Connection conn = null;
		if (params.containsKey(ReportConstant.DATASOURCE)){
    		if (params.containsKey(ReportConstant.DATASOURCE) ==
    				params.containsValue(ReportConstant.DATASOURCE_IPLUS)){
    			conn = dataSourceiPlus.getConnection();
    		} else if (params.containsKey(ReportConstant.DATASOURCE) ==
    				params.containsValue(ReportConstant.DATASOURCE_AOL)) {
    			conn = dataSourceAol.getConnection();
    		} else if (params.containsKey(ReportConstant.DATASOURCE) == 
    				params.containsValue(ReportConstant.DATASOURCE_LOCAL)){
    			conn = dataSourceLocal.getConnection();
    		} else if (params.containsKey(ReportConstant.DATASOURCE) ==
    				params.containsValue(ReportConstant.DATASOURCE_VMS)) {
    			conn = dataSourceVms.getConnection();
    		} else if (params.containsKey(ReportConstant.DATASOURCE) ==
    				params.containsValue(ReportConstant.DATASOURCE_VIT)) {
    			conn = dataSourcevit.getConnection();
    		} else if (params.containsKey(ReportConstant.DATASOURCE) ==
    				params.containsValue(ReportConstant.DATASOURCE_ODSRPT)) {
    			conn = odsrptDataSource.getConnection();
    		} else if (params.containsKey(ReportConstant.DATASOURCE) ==
    				params.containsValue(ReportConstant.DATASOURCE_DM)) {
    			conn = dmDataSource.getConnection();
    		}
    	} else {
    		conn = dataSource.getConnection();
    	}
		return conn;
	}
    
    @Override
	public String createFile(Report report, String url, Map<String, Object> params, Connection conn, String fileName)
			throws JRException, SQLException {
    	String filePath = "";
    	if (report.getFormat().equals(ReportConstant.PDF)) {
    		filePath = this.createPdfFile(url, params, conn, fileName);
    	} else if (report.getFormat().equals(ReportConstant.XLS)) {
            filePath = this.createExcelFile(url, params, conn, fileName);
        } else if (report.getFormat().equals(ReportConstant.CSV) || report.getFormat().equals(ReportConstant.TXT)){
        	filePath = this.createCsvFile(url, params, conn, fileName, report.getFormat().toLowerCase());
        } else if (report.getFormat().equals(ReportConstant.POI)) {
			filePath = this.createPoiFile(url, params, conn, fileName,report.getTemplate());
		}
		return filePath;
	}
    
  	@Override
	public String createPdfFile(String url, Map<String, Object> params, Connection conn, String fileName) 
			throws JRException, SQLException {
  	    
  	    JasperPrint jasperPrint;
  	    if (params.containsKey(AsoConstant.JSON_SOURCE)) {
  	        jasperPrint = this.getJasperPrintByDataJson(url, params);
  	    } else {
  	        jasperPrint = JasperFillManager.fillReport(url, params, conn);
  	    }
		JRPdfExporter exporter = new JRPdfExporter();
    	exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
    	String filePath = pathOutput + fileName + ".pdf";
    	
    	exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(filePath));
    	SimplePdfExporterConfiguration config = new SimplePdfExporterConfiguration();
    	if (params.containsKey(ReportConstant.PDFA_1A)
    			&& params.containsKey(ReportConstant.PDFA_1A) == params.containsValue(true)) {
			config.setPdfaConformance(PdfaConformanceEnum.PDFA_1A);
			config.setTagged(true);
			config.setTagLanguage("en-us");
			config.setIccProfilePath(pathInput + ReportConstant.ICC_FILE_NAME);
    	}
    	exporter.setConfiguration(config);
    	exporter.exportReport();
    	LOGGER.debug("Generate PDF");
    	
    	if (null != conn) {
    		conn.close();
    	}
		return filePath;
	}

	@Override
	public String createExcelFile(String url, Map<String, Object> params, Connection conn, String fileName)
			throws JRException, SQLException {
	  
  	    JasperPrint jasperPrint;
        if (params.containsKey(AsoConstant.JSON_SOURCE)) {
            jasperPrint = this.getJasperPrintByDataJson(url, params);
        } else {
            jasperPrint = JasperFillManager.fillReport(url, params, conn);
        }
		JRXlsxExporter exporter = new JRXlsxExporter();
        exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
        String filePath = pathOutput + fileName + XLSX_FORMAT;
        
        exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(filePath));
        SimpleXlsxReportConfiguration config = new SimpleXlsxReportConfiguration();
        config.setDetectCellType(true);
        config.setWhitePageBackground(false);
        config.setRemoveEmptySpaceBetweenColumns(true);
        config.setRemoveEmptySpaceBetweenRows(true);
        config.setFontSizeFixEnabled(false);
        config.setCollapseRowSpan(false);
        config.setWrapText(true);
        config.setShowGridLines(true);
        config.setIgnorePageMargins(false);
        exporter.setConfiguration(config);
        exporter.exportReport();
        LOGGER.debug("Generate XLS");
        
		if (null != conn) {
    		conn.close();
    	}
		return filePath;
	}

	@Override
	public String createCsvFile(String url, Map<String, Object> params, Connection conn, String fileName, String fileFormat)
			throws JRException, SQLException {
	  
  	    JasperPrint jasperPrint;
        if (params.containsKey(AsoConstant.JSON_SOURCE)) {
            jasperPrint = this.getJasperPrintByDataJson(url, params);
        } else {
            jasperPrint = JasperFillManager.fillReport(url, params, conn);
        }
        JRCsvExporter exporter = new JRCsvExporter();
		exporter.setExporterInput(new SimpleExporterInput (jasperPrint));
    	String filePath = pathOutput + fileName + "." + fileFormat.toLowerCase();
    	
    	exporter.setExporterOutput(new SimpleWriterExporterOutput(filePath));
    	SimpleCsvExporterConfiguration config = new SimpleCsvExporterConfiguration();
    	if(params.containsKey(ReportConstant.FIELD_DELIMITER)){
    		config.setFieldDelimiter(params.get(ReportConstant.FIELD_DELIMITER).toString());
    	} else {
    		config.setFieldDelimiter(",");
    	}
    	if (params.containsKey(ReportConstant.CSV_FIELD_ENCLOSURE)) {
    		config.setFieldEnclosure(params.get(ReportConstant.CSV_FIELD_ENCLOSURE).toString());
    		config.setForceFieldEnclosure(true);
    	}
    	config.setRecordDelimiter("\r\n");
    	exporter.setConfiguration(config);
    	exporter.exportReport();
    	LOGGER.debug("Generate CSV");

		if (null != conn) {
    		conn.close();
    	}
		return filePath;
	}

	@Override
	public String createPoiFile(String url, Map<String, Object> params, Connection conn, String fileName, String templateName) {

		String filePath = pathOutput + fileName + XLSX_FORMAT;
		ExcelTool excelTool = new ExcelTool();
		String sql = params.get(ReportConstant.FILEQUERY_PARAM).toString();

		try(PreparedStatement ps = conn.prepareStatement(sql)) {

			ps.setString(1, params.get(OperationConstant.PARAM_START_DATE).toString());
			ps.setString(2, params.get(OperationConstant.PARAM_END_DATE).toString());
			try(ResultSet rs = ps.executeQuery()){
				excelTool.excelGenerator(rs, filePath, templateName);
				LOGGER.info("{} has been created", templateName);
			}

		} catch (SQLException e) {
			LOGGER.error("\r\nError when creating {}: {}\r\n{}", templateName, e.getMessage(), e);
		}


		return filePath;
	}


	private void copyFile(Map<String, Object> params, String fileName, String filePath){
    	if (params.containsKey(ReportConstant.PATH_OUTPUT)){
    		Path folderPath = Paths.get(params.get(ReportConstant.PATH_OUTPUT).toString());
    		Path srcPath = Paths.get(filePath);
    		Path destPath = Paths.get(params.get(ReportConstant.PATH_OUTPUT).toString(),
    				fileName + filePath.substring(filePath.lastIndexOf('.'))).toAbsolutePath();
    		try {
    			if (Files.notExists(folderPath)) {
    				Files.createDirectories(folderPath);
    			}
				Files.copy(srcPath, destPath);
			} catch (IOException e) {
				LOGGER.error("IOException: ", e);
			}
    	}
    }
	
	private void zipFile(Map<String, Object> params, ReportFile newFile, String filePath) {
    	if (params.containsKey(ReportConstant.ZIP_COMP) && newFile.getStatus().equals(ReportConstant.COMPLETE)) {
			List<File> filesToAdd = new ArrayList<>();
    		filesToAdd.add(new File(filePath));
    		params.put(ReportConstant.FILEPATH_PARAM, filePath);
        	zipGenerator.generateZip(filesToAdd, params);
        }
    }
	
	private void protectXls(Map<String, Object> params, ReportFile newFile, Report report, String pathOutput, String fileName) {
    	if (params.containsKey(ReportConstant.XLS_PASS) && newFile.getStatus().equals(ReportConstant.COMPLETE)) {
        	String fileNameWithExt = fileName + "." 
        			+ (report.getFormat().equals(ReportConstant.XLS) ? "xlsx" : report.getFormat().toLowerCase());
        	protectFileService.protectOoxmlFile(fileNameWithExt, pathOutput, pathOutput, params.get(ReportConstant.XLS_PASS).toString());
        }
    }
	
	private void emailFile(Map<String, Object> params, ReportFile newFile, Report report, String user) {
    	if (params.containsKey(EmailConstant.EMAIL)
        		&& params.get(EmailConstant.PARAM_YGEMAIL).toString().equals(EmailConstant.EMAIL)
        		&& newFile.getStatus().equals(ReportConstant.COMPLETE)){
    		Email email = new Email();
			email.setStatus(ReportConstant.PROCESSING);
			email.setYgEmail(params.get(EmailConstant.PARAM_YGEMAIL).toString());
			email.setFromId(params.get(EmailConstant.PARAM_EMAIL_FROM).toString());
			email.setToId(params.get(EmailConstant.PARAM_TO_ID).toString());
			if(params.containsKey(EmailConstant.PARAM_CC_ID)){
				email.setCcId(params.get(EmailConstant.PARAM_CC_ID).toString());
			}
			if(params.containsKey(EmailConstant.PARAM_BCC_ID)){
				email.setBccId(params.get(EmailConstant.PARAM_BCC_ID).toString());
			}
			if(params.containsKey(EmailConstant.PARAM_CONTENT_ID)){
				email.setContentId(params.get(EmailConstant.PARAM_CONTENT_ID).toString());
			}
			if(params.containsKey(EmailConstant.PARAM_CONTENT_PATH)){
				email.setContentPath(params.get(EmailConstant.PARAM_CONTENT_PATH).toString());
			}
			if(params.containsKey(EmailConstant.PARAM_CONTENT_TYPE)){
				email.setContentType(params.get(EmailConstant.PARAM_CONTENT_TYPE).toString());
			}
			email.setSubject(params.get(EmailConstant.PARAM_SUBJECT).toString());
			email.setContent(params.get(EmailConstant.PARAM_CONTENT).toString());
			email.setAttachName(params.get(EmailConstant.PARAM_ATTACH_NAME).toString());
			email.setAttachPath(params.get(EmailConstant.PARAM_FILEPATH).toString());
			email.setCreateBy(user);
			email.setReportId(report.getReportId());
			emailService.save(email);
        }
    }
	
	private void pgpEncrypt(Map<String, Object> params, ReportFile newFile, String filePath) {
    	if (params.containsKey(CryptoConstant.PGP_ENCRYPT) && newFile.getStatus().equals(ReportConstant.COMPLETE)) {
        	List<String> filePaths = new ArrayList<>();
        	filePaths.add(filePath);
        	pgpService.encryptFiles(filePaths);
        }
    }
    
    private void copySFTP(Map<String, Object> params, String pathOutput) {
    	if (params.containsKey(FtpConstant.SFTP)) {
    		if(params.containsKey(FtpConstant.SFTP_MANUAL_CONNECT)) {
        		sftpService.sftpLogin(params.get(FtpConstant.FTP_HOST_NAME).toString(), 
						  params.get(FtpConstant.FTP_USER_NAME).toString(),
						  params.get(FtpConstant.FTP_PASSWORD).toString(), 
						  Integer.valueOf(params.get(FtpConstant.FTP_PORT).toString()));
    			
        	} else {
        		sftpService.sftpLogin(env.getProperty("sftp.hostname"), env.getProperty("sftp.username"), env.getProperty("sftp.password"), 
        				Integer.valueOf(env.getProperty("sftp.port")));    			        		
        	}
    		
    		if (params.containsKey(FtpConstant.FTP_CREATE_FOLDER)) {
    			sftpService.createFolder(params.get(FtpConstant.FTP_OUTPUT_DIR).toString(), 
    					params.get(FtpConstant.FTP_FOLDER_NAME).toString());
    			sftpService.uploadFile(pathOutput, params.get(FtpConstant.FTP_OUTPUT_NAME).toString(),
    					params.get(FtpConstant.FTP_OUTPUT_DIR).toString() + params.get(FtpConstant.FTP_FOLDER_NAME));
    		} else {
    			sftpService.uploadFile(pathOutput, params.get(FtpConstant.FTP_OUTPUT_NAME).toString(),
    					params.get(FtpConstant.FTP_OUTPUT_DIR).toString());			
    		}
    		
    		if (params.containsKey(FtpConstant.SFTP_ENCRYPTED)) {
    			sftpService.uploadFile(pathOutput, params.get(FtpConstant.FTP_ENCRYPTED_NAME).toString(),
    					params.get(FtpConstant.FTP_ENCRYPTED_DIR).toString());
    		}
    		sftpService.disconnect();
    	} 
    }

    private JasperPrint getJasperPrintByDataJson(String url, Map<String, Object> params) throws JRException {
      String dataJson = params.get(AsoConstant.JSON_SOURCE).toString();
      ByteArrayInputStream jsonDataStream = new ByteArrayInputStream(dataJson.getBytes());
      JsonDataSource datasource = new JsonDataSource(jsonDataStream);
      return JasperFillManager.fillReport(url, params, datasource);
    }
    
}
