package id.co.astralife.app.report.ib.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.MajorAlterationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.dm.repository.UnusedPremiumRepository;
import id.co.astralife.app.report.ib.service.MajorAlterationService;

@Service
public class MajorAlterationServiceImpl implements MajorAlterationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MajorAlterationServiceImpl.class);

	private UnusedPremiumRepository unusedPremiumRepository;
	private ReportGenerator reportGenerator;

	@Autowired
	public MajorAlterationServiceImpl(UnusedPremiumRepository unusedPremiumRepository, ReportGenerator reportGenerator) {
		this.unusedPremiumRepository = unusedPremiumRepository;
		this.reportGenerator = reportGenerator;
	}

	@Override
	public void generateUnusedPremium(UUID reportId, String user, String policyNo, String startDate, String endDate) {
		Long count = unusedPremiumRepository.countByPolicyNoAndTransactionDateBetween("", startDate, endDate);

		String generateStatus = (count > 0 ? "GENERATED" : "NOT GENERATE");
		LOGGER.info("RUN JOB Unused Premium Data Count: {}, Data is {} ", count, generateStatus);
		if (count > 0) {
			String stringDateName = startDate.replaceAll("(\\d{4})(\\d{2})(\\d{2})", "$3$2$1");
			Map<String, Object> params = new HashMap<>();
			params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
			params.put(MajorAlterationConstant.PARAM_POL_NO, policyNo);
			params.put(MajorAlterationConstant.PARAM_START_DATE, startDate);
			params.put(MajorAlterationConstant.PARAM_END_DATE, endDate);
			params.put(ReportConstant.FILENAME_PARAM, "Daily Unused Premium Report_" + stringDateName);
			reportGenerator.generate(reportId, user, params);
		}
	}

	@Override
	public void generateMajorAlterationHistory(UUID reportId, String user, String policyNo, String startDate, String endDate) {
		LOGGER.info("RUN JOB Major Alteration History");
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
		params.put(MajorAlterationConstant.PARAM_POL_NO, policyNo);
		params.put(MajorAlterationConstant.PARAM_START_DATE, startDate);
		params.put(MajorAlterationConstant.PARAM_END_DATE, endDate);
		String fileName = FileUtil.generateFileName("Major_Alteration_History", user);
		params.put(ReportConstant.FILENAME_PARAM, fileName);
		reportGenerator.generate(reportId, user, params);
	}
	
}
