package id.co.astralife.app.report.schedule.job;

import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.FinanceConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.finance.service.AgentETaxService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;

public class AgentETaxJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(AgentETaxJob.class);
	
	@Autowired
	ReportService reportService;
	
	@Autowired
	AgentETaxService eTaxService;
	
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START E-Tax Job----------");
		
		List<Report> reports = reportService.findBySchedule(ReportConstant.DAILY);
		
		for (Report rpt : reports) {
			if (rpt.getTemplate().equals(FinanceConstant.MASTER_AGENT_AFC)){
				eTaxService.generateAgentETax(rpt.getReportId(), "SYSTEM");
			}
		}
		
		LOGGER.info("----------END E-Tax Job----------");
	}
}
