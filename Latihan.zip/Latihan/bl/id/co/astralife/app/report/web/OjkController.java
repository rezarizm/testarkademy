package id.co.astralife.app.report.web;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import id.co.astralife.app.report.common.OjkConstant;
import id.co.astralife.app.report.finance.service.OjkService;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Ojk;
import id.co.astralife.app.report.model.OjkRequest;
import id.co.astralife.app.report.report.service.ConfigService;

@RestController
@RequestMapping("/report/service/ojk")
public class OjkController {

	private static final Logger LOGGER = LoggerFactory.getLogger(OjkController.class);
	private static final String IS_SUCCESS = "success";
	private static final String IS_FAILED = "failed";
	private static final String ERROR_MESSAGE = "errorMessage";

	private OjkService ojkService;
	private ConfigService configService;

	@Autowired
	public OjkController (OjkService ojkService, ConfigService configService) {
		this.ojkService = ojkService;
		this.configService = configService;
	}

	/**
	 * 
	 * @param user = SYSTEM
	 * @param startDate = yyyyMMdd 
	 * @param endDate = yyyyMMdd 
	 * @param sheetName = (one of <premi ul, premi life, premi health, claim ul, claim life, claim health>)
	 * @param countHit = (between 0 ad 1250) 
	 * @return
	 */
	@RequestMapping(value = "/geocode/run", method = RequestMethod.POST)
	public String runGeoCodeJob(@RequestBody OjkRequest ojkReq, HttpServletResponse response) {
		try {
			Boolean dateChecked = StringUtils.trimToNull(ojkReq.getStartDate()) != null
					&& StringUtils.trimToNull(ojkReq.getEndDate()) != null;
			Boolean sheetChecked = StringUtils.trimToNull(ojkReq.getSheetName()) != null;
			Boolean userChecked = StringUtils.trimToNull(ojkReq.getUser()) != null;
			Integer countHitExt = ojkReq.getCountHit() == null ? 0 : ojkReq.getCountHit();
			
			if (dateChecked && sheetChecked && userChecked) {
				LOGGER.info("OjkController run geocode manual with: {},{},{},{},{}", ojkReq.getStartDate(), ojkReq.getEndDate(), 
						ojkReq.getSheetName(), ojkReq.getUser(), countHitExt);
				
				SimpleDateFormat sdfTime = new SimpleDateFormat("yyyyMMddHHmmss");
				Date from = sdfTime.parse(ojkReq.getStartDate() + "000000");
				Date to = sdfTime.parse(ojkReq.getEndDate() + "235959");
				ojkService.processGetAddressByGeoCode(from, to, ojkReq.getSheetName(), ojkReq.getUser(), countHitExt);
			} else {
				throw new IllegalArgumentException("Parameters Not Match");
			}
		} catch (Exception e) {
			LOGGER.error("Exception : OjkController.runGeoCodeJob " + e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ": " + e;
		}
		return IS_SUCCESS;
	}

	/**
	 * 
	 * @param breakTime = HHmm
	 * @return
	 */
	@RequestMapping(value = "/geocode/breaktime", method = RequestMethod.POST)
	public String setBreakTime(@RequestBody OjkRequest ojkReq, HttpServletResponse response) {
		try {
			if (!ojkReq.getBreakTime().isEmpty()) {
				Integer valid = Integer.parseInt(ojkReq.getBreakTime());
				if (valid > 0 && valid <= 2359) {
					LOGGER.info("OjkController geocode breaktime: {}", valid);
					
					Config configBreakTime = configService.findFirstByConfigName(OjkConstant.OJK_GEOCODE_BREAK_TIME);
					configBreakTime.setConfigValue(ojkReq.getBreakTime());
					configService.save(configBreakTime);
				} else {
					throw new IllegalArgumentException("Parameters Not Match");
				}
			}
		} catch (Exception e) {
			LOGGER.error("Exception : OjkController.setBreakTime " + e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ": " + e;
		}
		return IS_SUCCESS;
	}
	
	/**
	 * 
	 * @param startDate = yyyyMMdd,
	 * @param endDate = yyyyMMdd
	 * @param rptFreq = QRTRLY / YEARLY
	 * @return
	 */
	@RequestMapping(value = "/data/delete", method = RequestMethod.POST)
	public String deleteData(@RequestBody OjkRequest ojkReq, HttpServletResponse response) {
		try {
			if (!ojkReq.getStartDate().isEmpty() && !ojkReq.getEndDate().isEmpty() && !ojkReq.getRptFreq().isEmpty()) {
				SimpleDateFormat sdfTime = new SimpleDateFormat("yyyyMMddHHmmss");
				Date from = sdfTime.parse(ojkReq.getStartDate() + "000000");
				Date to = sdfTime.parse(ojkReq.getEndDate() + "235959");
				
				LOGGER.info("OjkController delete data {} between: {} and {}", ojkReq.getRptFreq(), ojkReq.getStartDate(), ojkReq.getEndDate());
				List<Ojk> ojks = ojkService.findByFrequencyAndCreateDateBetween(ojkReq.getRptFreq(), from, to);
				ojkService.delete(ojks);
			}
		} catch (Exception e) {
			LOGGER.error("Exception : OjkController.deleteData " + e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ": " + e;
		}
		return IS_SUCCESS;
	}
	
	/**
	 * 
	 * @param Set<UUID> ids
	 * @return
	 */
	@RequestMapping(value = "/data/delete/ids", method = RequestMethod.POST)
	public String deleteByIdIn(@RequestBody OjkRequest ojkReq, HttpServletResponse response) {
		try {
			if (!ojkReq.getOjkIds().isEmpty()) {
				Set<UUID> ojkIds = new HashSet<>();
				for(String ojkId : ojkReq.getOjkIds()) {
					ojkIds.add(UUID.fromString(ojkId.replaceAll("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5")));
				}
				
				LOGGER.info("OjkController delete data by id in : {}", ojkIds);
				ojkService.deleteByOjkIdIn(ojkIds);
			}
		} catch (Exception e) {
			LOGGER.error("Exception : OjkController.deleteData By Id In" + e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ": " + e;
		}
		return IS_SUCCESS;
	}
	
	@RequestMapping(value = "/file/process", method = RequestMethod.POST)
	public String processFile(@RequestBody OjkRequest ojkReq, HttpServletResponse response) {

		LOGGER.info("-----PROCESS OJK FILE, id {}-----", Thread.currentThread().getId());
		try (InputStream inputStream = new FileInputStream(ojkReq.getFilePath())) {
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			ojkService.saveFileData(workbook, ojkReq);
		} catch (FileNotFoundException e) {
			LOGGER.error("FileNotFoundException {}, id {}", e.getMessage(), Thread.currentThread().getId());
			return IS_FAILED;
		} catch (IOException e) {
			LOGGER.error("IOException {}, id {}", e.getMessage(), Thread.currentThread().getId());
			return IS_FAILED;
		}
		return IS_SUCCESS;
	}
	
	@RequestMapping(value = "/geocode/setting/reset", method = RequestMethod.POST)
	public String geoCodeResetSetting() {

		LOGGER.info("-----GEOCODE OJK RESET SETTING, id {}-----", Thread.currentThread().getId());
		String status = "";
		try {
			status = ojkService.geoCodeResetSetting();
		} catch (Exception e) {
			LOGGER.error("Exception {}, id {}", e.getMessage(), Thread.currentThread().getId());
			return IS_FAILED;
		}
		return status;
	}
	
}
