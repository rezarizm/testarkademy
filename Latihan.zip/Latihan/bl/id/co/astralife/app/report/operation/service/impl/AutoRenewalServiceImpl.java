package id.co.astralife.app.report.operation.service.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.AutoRenewalConstant;
import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.EmailUtil;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.dm.entity.AutoRenewal;
import id.co.astralife.app.report.dm.entity.EmailCc;
import id.co.astralife.app.report.dm.repository.AutoRenewalRepository;
import id.co.astralife.app.report.dm.repository.EmailCcRepository;
import id.co.astralife.app.report.email.service.EmailService;
import id.co.astralife.app.report.local.entity.AttachDetail;
import id.co.astralife.app.report.local.entity.Email;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.local.repository.AttachDetailRepository;
import id.co.astralife.app.report.local.repository.ReportFileRepository;
import id.co.astralife.app.report.model.AutoRenewalRequest;
import id.co.astralife.app.report.model.EmailEntity.AttachmentDetail;
import id.co.astralife.app.report.operation.service.AutoRenewalService;
import id.co.astralife.app.report.report.service.ReportService;
import net.sf.jasperreports.engine.JRException;

@Service
public class AutoRenewalServiceImpl implements AutoRenewalService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AutoRenewalServiceImpl.class);
	
	private final AutoRenewalRepository autoRenewalRepository;
	private final ReportGenerator reportGenerator;
	private final ReportService reportService;
	private final AttachDetailRepository attachDetailRepository;
	private final EmailService emailService;
	private final ReportFileRepository reportFileRepository;
	private final EmailCcRepository emailCcRepository;
	
	@Value("${dir.email.template}")
	private String dirEmailTemp;

    @Value("${email.auto.renewal.broker}")
  	private String emailTempBroker;

    @Value("${email.auto.renewal.client}")
    private String emailTempClient;

	@Value("${dir.pathInput}")
	private String pathInput;
	 
	@Value("${dir.pathOutput}")
	private String pathOutput;
	
	@Autowired
	public AutoRenewalServiceImpl(AutoRenewalRepository autoRenewalRepository, ReportGenerator reportGenerator,
			ReportService reportService, AttachDetailRepository attachDetailRepository,
			EmailService emailService, ReportFileRepository reportFileRepository,
		  	EmailCcRepository emailCcRepository) {
		this.autoRenewalRepository = autoRenewalRepository;
		this.reportGenerator = reportGenerator;
		this.reportService = reportService;
		this.attachDetailRepository = attachDetailRepository;
		this.emailService = emailService;
		this.reportFileRepository = reportFileRepository;
		this.emailCcRepository = emailCcRepository;
	}

	@Override
	public void processBillAutoRenewal(AutoRenewalRequest renewReq) {
		this.generateBillAutoRenewal(renewReq);
		this.generatePropAutoRenewal(renewReq);
	}
	
	@Override
	public void generateBillAutoRenewal(AutoRenewalRequest renewReq) {
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
		params.put(OperationConstant.PARAM_START_DATE, renewReq.getStartDate());
		params.put(OperationConstant.PARAM_END_DATE, renewReq.getEndDate());
		
		Report report = reportService.findByTemplate(AutoRenewalConstant.BILL_AUTO_RENEWAL);
		if (null != report) {
			String fileName = FileUtil.generateFileName(report.getRptName(), renewReq.getUser());
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			reportGenerator.generate(report.getReportId(), renewReq.getUser(), params);
		}
	}
	
	@Override
	public List<AutoRenewal> generateListRenewals(AutoRenewalRequest renewReq) {
		AutoRenewal autoRenewal = new AutoRenewal();
		List<AutoRenewal> autoRenewals = new ArrayList<>();
		if (renewReq.getPolicyNo().isEmpty()) {
			autoRenewals = autoRenewalRepository.getBillAutoRenewalByPolicyNoAndStartDateAndEndDate(renewReq.getStartDate(), renewReq.getEndDate());
		} else {
			autoRenewal.setPolicyNo(renewReq.getPolicyNo());
			autoRenewal.setExclude("N");
			autoRenewals.add(autoRenewal);
		}
		return autoRenewals;
	}
	
	@Async
	@Override
	public void generatePropAutoRenewal(AutoRenewalRequest renewReq) {
		LOGGER.info("----------START Processing Proposal Auto Renewal Report----------");
		List<AutoRenewal> autoRenewals = this.generateListRenewals(renewReq);
		List<AutoRenewal> propAutoRenewals = new ArrayList<>();
		List<String> contractTypes = autoRenewalRepository.getContractType();
		for (AutoRenewal autoRenewal : autoRenewals) {
			AutoRenewal propAutoRenewal = autoRenewalRepository.getProposalRenewalByPolicyNo(autoRenewal.getPolicyNo());
			if (null != propAutoRenewal) {
				boolean condition1 = !contractTypes.isEmpty() && contractTypes.contains(propAutoRenewal.getContractType());
				boolean condition2 = ReportConstant.CUR_IDR.equalsIgnoreCase(propAutoRenewal.getCurrCode());
				boolean condition3 = propAutoRenewal.getExcludePolicy().equalsIgnoreCase("N");
				boolean condition4 = propAutoRenewal.getExclude().equalsIgnoreCase("N");
				if (condition1 && condition2 && condition3 && condition4) {
					propAutoRenewals.add(propAutoRenewal);
				}
			}
		}
		for (AutoRenewal propAutoRenewal : propAutoRenewals) {
			AttachmentDetail propReportAD = this.generateProposalReport(propAutoRenewal, 
					renewReq.getUser(), propAutoRenewal.getPolicyNo(), (renewReq.getDuplicate() ? "Y" : "N"));
			AttachmentDetail listMbrAD = this.generateMemberListReport(propAutoRenewal, 
					renewReq.getUser(), propAutoRenewal.getPolicyNo());
			
			List<AttachmentDetail> attachmentDetails = new ArrayList<>();
			if (null != propReportAD && null != listMbrAD && renewReq.getEmail()) {
				attachmentDetails.add(propReportAD);
				attachmentDetails.add(listMbrAD);
				this.emailPropAutoRenewal(propAutoRenewal, attachmentDetails, renewReq.getUser());
			}
		}
		LOGGER.info("----------END Processing Proposal Auto Renewal Report----------");
	}
	
	@Override
	public AttachmentDetail generateProposalReport(AutoRenewal propAutoRenewal, String user, String policyNo, String reprint) {
		Report report = reportService.findByTemplate(AutoRenewalConstant.PROP_AUTO_RENEWAL);
		AttachmentDetail attachmentDetail = null;
		
		if (null != report) {
			String fileName = FileUtil.generateFileName(report.getRptName() + "_" + propAutoRenewal.getPolicyNo(), user);
			ReportFile newFile = this.saveReportFile(report, fileName, user);
			
			Map<String, Object> params = new HashMap<>();
			params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			params.put(OperationConstant.PARAM_REPRINT, reprint);
			params.put(OperationConstant.PARAM_POL_NO, policyNo);
			
			String filePath = this.generateFile(report, params, newFile, user);
			if (!filePath.isEmpty()) {
				attachmentDetail = EmailUtil.setAttachmentDetail(filePath, fileName + "." + report.getFormat().toLowerCase());
			}
		}
		return attachmentDetail;
	}
	
	@Override
	public AttachmentDetail generateMemberListReport(AutoRenewal propAutoRenewal, String user, String policyNo) {
		Report report = reportService.findByTemplate(AutoRenewalConstant.LIST_MBR_AUTO_RENEWAL);
		AttachmentDetail attachmentDetail = null;
		
		if (null != report) {
			String fileName = FileUtil.generateFileName(report.getRptName() + "_" + propAutoRenewal.getPolicyNo(), user);
			ReportFile newFile = this.saveReportFile(report, fileName, user);
			
			Map<String, Object> params = new HashMap<>();
			params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			params.put(OperationConstant.PARAM_POL_NO, policyNo);
			
			String filePath = this.generateFile(report, params, newFile, user);
			if (!filePath.isEmpty()) {
				attachmentDetail = EmailUtil.setAttachmentDetail(filePath, fileName + "." + report.getFormat().toLowerCase());
			}
		}
		return attachmentDetail;
	}
	
	@Override
	public void emailPropAutoRenewal(AutoRenewal propAutoRenewal, List<AttachmentDetail> attachmentDetails, String user) {
		Report report = reportService.findByTemplate(AutoRenewalConstant.PROP_AUTO_RENEWAL);
        if (null != report) {
        	Email email = new Email();
    		email.setStatus(ReportConstant.PROCESSING);
    		email.setYgEmail(EmailConstant.EMAIL);
    		email.setFromId(EmailConstant.EMAIL_SENDER_NO_REPLY);
    		email.setToId(propAutoRenewal.getEmailTo()); 
    		email.setCcId(this.buildCcId(propAutoRenewal.getSob()));
    		email.setSubject(AutoRenewalConstant.SUBJECT_RENEWAL + propAutoRenewal.getPolicyHolder());
    		email.setContent(this.getContent(propAutoRenewal)); 
    		email.setAttachName(""); // keep empty
    		email.setAttachPath(""); // keep empty
    		email.setCreateBy(user);
    		email.setReportId(report.getReportId());
    		emailService.save(email);
    		
    		List<AttachDetail> attachDetails = new ArrayList<>();
     		for (AttachmentDetail attachmentDetail : attachmentDetails) {
    			AttachDetail attachDetail = new AttachDetail();
    			attachDetail.setAttachName(attachmentDetail.getAttachmentName());
    			attachDetail.setAttachPath(attachmentDetail.getAttachmentPath());
    			attachDetail.setEmailId(email.getEmailId());
    			attachDetail.setCreateBy(user);
    			attachDetails.add(attachDetail);
    		}
     		attachDetailRepository.save(attachDetails);
     		LOGGER.info("----------Send Email Proposal Auto Renewal Report, Policy No {}, Email to {} [DONE]----------", 
            		propAutoRenewal.getPolicyNo(), propAutoRenewal.getEmailTo());
        }
	}
	
	private ReportFile saveReportFile(Report report, String fileName, String user) {
		ReportFile reportFile = new ReportFile();
        reportFile.setRptId(report.getReportId());
        reportFile.setFileName(fileName);
        reportFile.setFolderPath(pathOutput);
        reportFile.setCreateBy(user);
        reportFile.setStatus(ReportConstant.PROCESSING);
        reportFile.setVisible(true);
        reportFileRepository.save(reportFile);
		return reportFileRepository.findById(reportFile.getId());
	}
	
	private String generateFile(Report report, Map<String, Object> params, ReportFile newFile, String user) {
		String filePath = "";
		Connection conn = null;
		try {
			conn = reportGenerator.getConnection(params);
			String url = pathInput + report.getTemplate() + ".jasper";
			filePath = reportGenerator.createFile(report, url, params, conn, params.get(ReportConstant.FILENAME_PARAM).toString());
			newFile.setModifyBy(user);
			newFile.setStatus(ReportConstant.COMPLETE);
		} catch (SQLException e) {
			newFile.setStatus(ReportConstant.FAILED);
			LOGGER.error("SQLException:", e);
		} catch (JRException e) {
			newFile.setStatus(ReportConstant.FAILED);
			LOGGER.error("JRException:", e);
		} catch (Exception e) {
        	newFile.setStatus(ReportConstant.FAILED);
            LOGGER.error("Exception:", e);
        } finally {
        	reportFileRepository.save(newFile);
            if (null != conn) {
                try {
                    conn.close();
                } catch (SQLException ex) {
                    LOGGER.error("Unable to close connection", ex);
                }
            }
        }
		LOGGER.info("Generate Proposal Auto Renewal Report, File Name {}, Status {}", params.get(ReportConstant.FILENAME_PARAM), newFile.getStatus());
		return filePath;
	}
	
	private String getContent(AutoRenewal propAutoRenewal) {
	    Map<String, String> contentParams = new HashMap<>();
		contentParams.put(AutoRenewalConstant.START_POLICY_PERIOD, propAutoRenewal.getStartDate());
		contentParams.put(AutoRenewalConstant.END_POLICY_PERIOD, propAutoRenewal.getExpiryDate());
		
		String template;
		if (propAutoRenewal.getChannel().equalsIgnoreCase("BROKER")) {
		    template = dirEmailTemp + emailTempBroker;
        } else {
		    template = dirEmailTemp + emailTempClient;
        }
		
		return emailService.renderByTemplate(template, "UTF-8", contentParams);
	}

	private String buildCcId(String sob) {
		List<EmailCc> emailCcs = emailCcRepository.getEmailCcBySob(sob);

		StringBuilder sb = new StringBuilder();
		if (emailCcs.isEmpty()) {
			sb.append("");
		} else {
			for (EmailCc emailCc : emailCcs) {
				sb.append(emailCc.getEmailCc()).append(",");
			}
			sb.deleteCharAt(sb.length() - 1);
		}
		return  sb.toString();
	}
}
