package id.co.astralife.app.report.report.service;


import java.util.UUID;

public interface ReportGuaranteedCashPaymentService {
	void generateGuaranteedCashReport(UUID rptId, String startDate, String endDate, String user, boolean isEmail);

}
