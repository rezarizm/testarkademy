package id.co.astralife.app.report.operation.service;

import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.ClaimReportGasiaRequest;

public interface ClaimReportGasiaService {

	void processClaimGasia(ClaimReportGasiaRequest claimReq);

	void generateClaimReport(ClaimReportGasiaRequest claimReq, Report report);
}
