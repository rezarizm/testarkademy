package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.operation.service.IplusNtuEmailService;

public class IplusNtuEmailJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(IplusNtuEmailJob.class);
	
	@Autowired
	private IplusNtuEmailService iplusNtuEmailService;
	
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START IPLUS NTU POLIS EMAIL Job----------");
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		
		Calendar calendar = Calendar.getInstance();
		String endDate = dateFormat.format(calendar.getTime());
		
		iplusNtuEmailService.sendEmailIplusNtuPolis("SYSTEM", endDate);
		
		LOGGER.info("----------END IPLUS NTU POLIS EMAIL Job----------");
	}
}