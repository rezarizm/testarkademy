package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface ProposalPolisService {

	void generateProposalPolis(UUID reportId, String user, String endDate);
}
