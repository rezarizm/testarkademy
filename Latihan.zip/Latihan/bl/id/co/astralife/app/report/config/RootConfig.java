package id.co.astralife.app.report.config;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.stereotype.Controller;

/**
 * @author fadil.wiranata
 */
@Configuration
/*@ComponentScan(basePackages = "id.co.astralife.app.report", excludeFilters = {*/
@ComponentScan(basePackages = "id.co.astralife.app", excludeFilters = {
		@ComponentScan.Filter(type = FilterType.ANNOTATION, value = { Controller.class }) })
@PropertySources({
		// @PropertySource("classpath:application.properties"),
		// @PropertySource("classpath:report.properties")
		@PropertySource("file:/opt/Vitamin/config/reportbl/application.properties"),
		@PropertySource("file:/opt/Vitamin/config/reportbl/report.properties"),
		@PropertySource("file:/opt/Vitamin/config/reportbl/connections.properties")})
public class RootConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(RootConfig.class);

	@PostConstruct
	public void initApp() {
		LOGGER.debug("Starting application..");
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
