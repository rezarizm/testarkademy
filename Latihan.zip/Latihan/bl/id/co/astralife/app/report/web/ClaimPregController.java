package id.co.astralife.app.report.web;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.ClaimPregRequest;
import id.co.astralife.app.report.operation.service.ClaimPregEmailService;
import id.co.astralife.app.report.report.service.ReportService;

@RestController
@RequestMapping(value = "/report/service")
public class ClaimPregController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ClaimPregController.class);
	private static final String SUCCESS = "success";
	private static final String ERROR = "ERROR: report or data is not found";
	
	@Autowired
	private ClaimPregEmailService claimPregEmailService;

	@Autowired 
	private ReportService reportService;
	
	@RequestMapping(value = "/claimpreg", method = RequestMethod.POST)
	public String emailClaimPreg(@RequestBody ClaimPregRequest claimReq, HttpServletResponse response) {
		
		Report report = reportService.findByRptName(OperationConstant.CLAIM_PRE_REG);
		// user = "SYSTEM, startDate = (yyyyMMdd) &  endDate = (yyyyMMdd)
		if (report != null && StringUtils.isNotBlank(claimReq.getUser()) && StringUtils.isNotBlank(claimReq.getStartDate())
				&& StringUtils.isNotBlank(claimReq.getEndDate())) {
			claimPregEmailService.processEmail(report.getReportId(), claimReq.getStartDate(), claimReq.getEndDate(), claimReq.getUser());
			return SUCCESS;
		} else {
			LOGGER.error(ERROR);
			return ERROR;
		}
	}
}