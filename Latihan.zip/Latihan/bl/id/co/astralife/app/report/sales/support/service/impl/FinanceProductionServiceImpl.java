package id.co.astralife.app.report.sales.support.service.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.FinanceProductionService;

/**
 * Implementation class of {@link FinanceProductionService}.
 *
 * @since 30 Mei 2017
 * @version 1.0
 * @author sayid.sidqi
 */
@Service("financeProductionService")
public class FinanceProductionServiceImpl implements FinanceProductionService {
	
	@Autowired
    private ReportGenerator reportGenerator;

    @Autowired
    private ReportService reportService;
    
	@Override
	public void generateFinanceProdcution(UUID reportId, String user) {
		Report report = reportService.findByReportId(reportId);
        Map<String, Object> params = new HashMap<>();
        params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
		if (report != null) {
			params.put(ReportConstant.FILENAME_PARAM, this.generateFileName());
			reportGenerator.generate(reportId, user, params);
		}
	}
	
	private String generateFileName() {
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmmss");
		return SalesSupportConstant.FP_FILENAME + sdf.format(Calendar.getInstance().getTime());
	}

}
