package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SmePolicyConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.SmePolicyService;
import id.co.astralife.app.report.report.service.ReportService;

public class SmePolicyJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(SmePolicyJob.class);
	
	@Autowired
	ReportService reportService; 
	
	@Autowired
	SmePolicyService smePolicyService;
	
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START SME POLICY Job----------");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
    	
        Calendar date = Calendar.getInstance();
        date.add(Calendar.DATE, -1);
        String startDate  = sdf.format(date.getTime());
        
        List<Report> reports = reportService.findBySchedule(ReportConstant.DAILY);
        
        for (Report rpt : reports) {
			if (rpt.getTemplate().equals(SmePolicyConstant.SME_POLICY)){
				smePolicyService.generateSmePolicy(rpt.getReportId(), "SYSTEM", startDate, startDate);
			}
		}
        
        LOGGER.info("----------END SME POLICY Job----------");
	}

}
