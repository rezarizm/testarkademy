package id.co.astralife.app.report.operation.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.iplus.entity.NtuJobMonitor;
import id.co.astralife.app.report.iplus.repository.NtuJobMonitorRepository;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.local.repository.ReportFileRepository;
import id.co.astralife.app.report.operation.service.ProposalPolisService;
import id.co.astralife.app.report.report.service.ReportService;

@Service
public class ProposalPolisServiceImpl implements ProposalPolisService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProposalPolisServiceImpl.class); 
			
	@Autowired
    private ReportGenerator reportGenerator;

    @Autowired
    private ReportService reportService;
    
    @Autowired
    private NtuJobMonitorRepository ntuJobMonitorRepository;
    
    @Autowired
	private ReportFileRepository reportFileRepository;
    
	@Override
	public void generateProposalPolis(UUID reportId, String user, String endDate) {
		
		Report report = reportService.findByReportId(reportId);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Date dateFrom = null;
		Date dateTo = null;
		try {
			dateFrom = sdf.parse(endDate+"000000");
			dateTo = sdf.parse(endDate+"235959");
		} catch (ParseException e) {
			LOGGER.error("ParseException"+e.getMessage());
		}
		
		ReportFile fileNtuProp = reportFileRepository.findFirstByRptIdAndCreateByAndCreateDateBetween(reportId, user, dateFrom, dateTo);
		NtuJobMonitor jobMonitor = ntuJobMonitorRepository.findFirstByEndTimeBetweenAndStatus(dateFrom, dateTo, "OK");
		if (report != null && fileNtuProp == null && jobMonitor != null) {
			Map<String, Object> params = new HashMap<>();
			params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
			params.put(ReportConstant.FIELD_DELIMITER, "|");
			params.put(ReportConstant.FILENAME_PARAM, OperationConstant.IPLUS_NTU_PROP_FILENAME + endDate);
			reportGenerator.generate(report.getReportId(), user, params);
			
		}
	}
}