package id.co.astralife.app.report.operation.service.impl;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.iplus.entity.Contract;
import id.co.astralife.app.report.iplus.repository.ContractRepository;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.SehatProteksiKuService;
import id.co.astralife.app.report.report.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class SehatProteksiKuServiceImpl implements SehatProteksiKuService {

    @Autowired
    private ReportGenerator reportGenerator;

    @Autowired
    private ReportService reportService;

    @Autowired
    private ContractRepository contractRepository;

    @Override
    public void generateSehatProteksiKu(UUID reportId, String user, String actionDate) {
        Report report = reportService.findByReportId(reportId);
        Map<String, Object> params = new HashMap<>();
        params.put("action_dt", actionDate);
        params.put(ReportConstant.PDFA_1A, true);
        params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
        if (report != null) {
            Contract contract = contractRepository.findCountData(actionDate);
            if (contract.getCountData() > 0) {
                params.put(ReportConstant.FILENAME_PARAM, FileUtil.generateFileName(report.getRptName(), user));
                reportGenerator.generate(report.getReportId(), user, params);
            }
        }
    }
}
