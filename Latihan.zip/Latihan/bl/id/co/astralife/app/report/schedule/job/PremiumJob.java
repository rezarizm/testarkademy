package id.co.astralife.app.report.schedule.job;

import id.co.astralife.app.report.common.FinanceConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.finance.service.StatementOfAccountService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;

import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

public class PremiumJob extends QuartzJobBean{

	private static final Logger LOGGER = LoggerFactory.getLogger(PremiumJob.class);
	private static final String SYSTEM = "SYSTEM";
	
	@Autowired
    StatementOfAccountService statementOfAccountService;

    @Autowired
    ReportService reportService;
    
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START Premium Job----------");
		
		List<Report> report = reportService.findBySchedule(ReportConstant.MONTHLY);
		
		for (Report rpt : report) {
			if (rpt.getTemplate().equals(FinanceConstant.PREMIUM_SUMMARY)) {
                statementOfAccountService.generateSummary(rpt.getReportId(), SYSTEM);
            } else if (rpt.getTemplate().equals(FinanceConstant.PREMIUM_DETAIL)) {
                statementOfAccountService.generateDetail(rpt.getReportId(), SYSTEM, ReportConstant.CUR_IDR, ReportConstant.SRC_BR);
                statementOfAccountService.generateDetail(rpt.getReportId(), SYSTEM, ReportConstant.CUR_USD, ReportConstant.SRC_BR);
            } else if (rpt.getTemplate().equals(FinanceConstant.PREMIUM_DETAIL_IA_DI)) {
                statementOfAccountService.generateDetail(rpt.getReportId(), SYSTEM, ReportConstant.CUR_IDR, ReportConstant.SRC_IA);
                statementOfAccountService.generateDetail(rpt.getReportId(), SYSTEM, ReportConstant.CUR_USD, ReportConstant.SRC_IA);
                statementOfAccountService.generateDetail(rpt.getReportId(), SYSTEM, ReportConstant.CUR_IDR, ReportConstant.SRC_DI);
                statementOfAccountService.generateDetail(rpt.getReportId(), SYSTEM, ReportConstant.CUR_USD, ReportConstant.SRC_DI);
            }
		}
		
		LOGGER.info("-----------END Premium Job-----------");
	}
}
