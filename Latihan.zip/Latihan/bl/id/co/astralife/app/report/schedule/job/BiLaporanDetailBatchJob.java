package id.co.astralife.app.report.schedule.job;

import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.BiLaporanDetailBatchService;
import id.co.astralife.app.report.report.service.ReportService;

/**
 * 
 * @author Michael
 *
 * @Since 7 Des 2017
 * 
 */
public class BiLaporanDetailBatchJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(BiLaporanDetailBatchJob.class);
	private static final String SYSTEM = "SYSTEM";

	@Autowired
	BiLaporanDetailBatchService biLaporanDetailBatchService;

	@Autowired
	ReportService reportService;

	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START BI Laporan Detail Job----------");
        
		List<Report> reports = reportService.findBySchedule(ReportConstant.MONTHLY);
        for (Report report : reports){
        	if(report.getTemplate().equals(OperationConstant.BI_NEW_POLICY)) {
        		biLaporanDetailBatchService.generateBiLaporanDetail(report.getReportId(), SYSTEM, "B2");
        	} else if(report.getTemplate().equals(OperationConstant.BI_PIF)) {
    			biLaporanDetailBatchService.generateBiLaporanDetail(report.getReportId(), SYSTEM, "B3");
        	} else if(report.getTemplate().equals(OperationConstant.BI_CLAIM)) {
				biLaporanDetailBatchService.generateBiLaporanDetail(report.getReportId(), SYSTEM, "B5");
        	} else if(report.getTemplate().equals(OperationConstant.BI_DELIVERY_OF_POLICY)) {
				biLaporanDetailBatchService.generateBiLaporanDetail(report.getReportId(), SYSTEM, "B6");
        	} else if(report.getTemplate().equals(OperationConstant.BI_CANCELATION_OF_POLICY)) {
				biLaporanDetailBatchService.generateBiLaporanDetail(report.getReportId(), SYSTEM, "B7");
        	} else if(report.getTemplate().equals(OperationConstant.BI_REFUND)) {
				biLaporanDetailBatchService.generateBiLaporanDetail(report.getReportId(), SYSTEM, "B8");
        	}
		}
		
		LOGGER.info("----------END BI Laporan Detail Job----------");
	}

}
