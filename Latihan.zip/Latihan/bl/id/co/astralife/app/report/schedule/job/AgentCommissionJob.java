package id.co.astralife.app.report.schedule.job;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.AgentCommissionService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class AgentCommissionJob extends QuartzJobBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(AgentCommissionJob.class);
    private static final String SYSTEM = "SYSTEM";
    
    @Autowired
    private ReportService reportService;

    @Autowired
    private AgentCommissionService agentCommissionService;

    @Override
    protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {

        LOGGER.info("----------START Agent Commission Job----------");
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");

        Calendar startCalendar = Calendar.getInstance();
        int date = startCalendar.get(Calendar.DATE);
        if (date >= 1 && date < 16) {
            //last month report
            startCalendar.add(Calendar.MONTH, -1);
            startCalendar.set(Calendar.DATE, 16);
        } else {
            //current month report
            startCalendar.set(Calendar.DATE, 1);
        }
        String startDate = dateFormat.format(startCalendar.getTime());

        Calendar endCalendar = Calendar.getInstance();
        if (date >= 1 && date < 16) {
            endCalendar.add(Calendar.MONTH, -1);
            int lastDate = startCalendar.getActualMaximum(Calendar.DATE);
            endCalendar.set(Calendar.DATE, lastDate);
        } else {
            endCalendar.set(Calendar.DATE, 15);
        }
        String endDate = dateFormat.format(endCalendar.getTime());
        
        Calendar startECom = Calendar.getInstance();
        startECom.add(Calendar.MONTH, -1);
        startECom.set(Calendar.DATE, 1);
        String startDateECom = dateFormat.format(startECom.getTime());
        
        Calendar endECom = Calendar.getInstance();
        endECom.add(Calendar.MONTH, -1);
        endECom.set(Calendar.DATE, endECom.getActualMaximum(Calendar.DATE));
        String endDateECom = dateFormat.format(endECom.getTime());
                
        LOGGER.info("startDate: {}, endDate: {}, startDateECom: {}, endDateECom: {}", 
        		startDate, endDate, startDateECom, endDateECom);
        
        List<Report> report = reportService.findBySchedule(ReportConstant.MONTHLY);
        
        for (Report rpt : report) {
            if (rpt.getTemplate().equals(SalesSupportConstant.AGENT_COMMISSION)) {
                agentCommissionService.generateAgentCommission(rpt.getReportId(), SYSTEM, startDate, endDate);
             // Digital Monthly
            } else if (date == 1 && rpt.getTemplate().equals(SalesSupportConstant.AGENT_COMMISSION_ECOM)){
        		agentCommissionService.generateAgentCommission(rpt.getReportId(), SYSTEM, startDateECom, endDateECom);
            } 
        }
        
        LOGGER.info("----------END Agent Commission Job----------");
    }
}