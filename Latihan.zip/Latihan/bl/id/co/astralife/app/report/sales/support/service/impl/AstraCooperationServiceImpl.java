package id.co.astralife.app.report.sales.support.service.impl;

import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.iplus.entity.AstraCoop;
import id.co.astralife.app.report.iplus.repository.AstraCoopRepository;
import id.co.astralife.app.report.sales.support.service.AstraCooperationService;

@Service
public class AstraCooperationServiceImpl implements AstraCooperationService {
	private static final Logger LOGGER = LoggerFactory.getLogger(AstraCooperationServiceImpl.class);
	private final ReportGenerator reportGenerator;
	private final Environment env;
	private final AstraCoopRepository astraCoopRepository;
	
	@Autowired
	public AstraCooperationServiceImpl(ReportGenerator reportGenerator, Environment env,
			AstraCoopRepository astraCoopRepository) {
		this.reportGenerator = reportGenerator;
		this.env = env;
		this.astraCoopRepository = astraCoopRepository;
	}

	@Override
	public void generateAstraCooperation(UUID rptId, String user, String dateString) {
		AstraCoop astraCoop = astraCoopRepository.countDataByDate(dateString);
		String copyPath = env.getProperty("address.astraCoop.doc");
		if(astraCoop.getCountData() > 0) {
			Map<String, Object> params = new HashMap<>();
			params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
			params.put(SalesSupportConstant.DATE_PARAM, dateString);
			params.put(ReportConstant.FILENAME_PARAM, FileUtil.generateFileName(SalesSupportConstant.ASTRA_COOP_CERT_FILENAME, user));
			params.put(ReportConstant.PATH_OUTPUT, Paths.get(copyPath, dateString).toAbsolutePath().toString());
			reportGenerator.generate(rptId, user, params);
		}
		LOGGER.info("Policy Certificate Koperasi Astra: {} data, {} to {}", 
				astraCoop.getCountData(), (astraCoop.getCountData() > 0 ? "GENERATED":"NOT GENERATED"), copyPath);
	}
}
