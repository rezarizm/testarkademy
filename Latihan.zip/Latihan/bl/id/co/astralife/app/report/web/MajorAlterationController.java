package id.co.astralife.app.report.web;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import id.co.astralife.app.report.common.MajorAlterationConstant;
import id.co.astralife.app.report.ib.service.MajorAlterationService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.MajorAltRequest;
import id.co.astralife.app.report.report.service.ReportService;

@RestController
@RequestMapping(value = "/report/service")
public class MajorAlterationController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MajorAlterationController.class);

	private MajorAlterationService majorAlterationService;
	private ReportService reportService;
	
	@Autowired
	public MajorAlterationController(MajorAlterationService majorAlterationService, ReportService reportService) {
		this.majorAlterationService = majorAlterationService;
		this.reportService =reportService;
	}
	
	@PostMapping(value = "/major_alteration/history")
	public ResponseEntity<String> emailClaimPreg(@RequestBody MajorAltRequest majorReq, HttpServletResponse response) {
		Report report = reportService.findByTemplate(MajorAlterationConstant.MAJOR_ALT_HISTORY_TEMPLATE);
		if (report != null && StringUtils.isNotBlank(majorReq.getUser()) && ((StringUtils.isNotBlank(majorReq.getStartDate())
				&& StringUtils.isNotBlank(majorReq.getEndDate())) || StringUtils.isNotBlank(majorReq.getPolicyNo()))) {
			LOGGER.info("GENERATE MAJOR ALTERATION HISTORY {}", majorReq);
			majorAlterationService.generateMajorAlterationHistory(report.getReportId(), majorReq.getUser(), majorReq.getPolicyNo(),
					majorReq.getStartDate(), majorReq.getEndDate());
			return new ResponseEntity<>("SUCCESS", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Parameter Required", HttpStatus.BAD_REQUEST);
		}
	}

}
