package id.co.astralife.app.report.finance.service;

import java.util.UUID;

/**
 * @author fadil.wiranata
 */
public interface StatementOfAccountService {
	
    void generateSummary(UUID reportId, String user);

    void generateSummary(UUID reportId, String user, String currency);

    void generateDetail(UUID reportId, String user);

    void generateDetail(UUID reportId, String user, String currency);

    void generateDetail(UUID reportId, String user, String currency, String srcCode);
    
    void generateProduction (UUID reportId, String user, String startDate, String endDate);
    
    void generateProduction (UUID reportId, String user, String startDate, String endDate, String currency);
    
    void generateProduction (UUID reportId, String user, String startDate, String endDate, String currency, String stcb);

    void generateProductionPdf (UUID reportId, String user, String month, String years);
}
