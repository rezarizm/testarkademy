package id.co.astralife.app.report.geocode;

import java.util.Map;

import id.co.astralife.app.report.model.GeoCode;

public interface GeoCodeService {
	
	GeoCode runGeoCodeConvAddr(Map<String, String> uriVariables);
}
