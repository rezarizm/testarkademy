package id.co.astralife.app.report.operation.service.impl;

import id.co.astralife.app.report.aol.entity.EmailTracker;
import id.co.astralife.app.report.aol.repository.EmailTrackerRepository;
import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.EmailTrackerService;
import id.co.astralife.app.report.report.service.ReportService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class EmailTrackerServiceImpl implements EmailTrackerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailTrackerServiceImpl.class);

    @Autowired
    ReportGenerator reportGenerator;

    @Autowired
    ReportService reportService;

    @Autowired
    EmailTrackerRepository emailTrackerRepository;

    @Override
    public void generateEmailTracker(UUID reportId, String user, String startDate, String endDate) {

        SimpleDateFormat formatDate = new SimpleDateFormat("yyyyMMdd");
        Date dateStart = null;
        Date dateEnd = null;
        try {
            dateStart = formatDate.parse(startDate);
            dateEnd = formatDate.parse(endDate);
            //Need to add 1 day to dateEnd because Date default hour is 00:00
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(dateEnd);
            calendar.add(Calendar.DATE, 1);
            dateEnd = calendar.getTime();
        } catch (ParseException e) {
            LOGGER.error("Incorrect date format: " + startDate + " " + endDate);
            LOGGER.error(e.getMessage());
        }

        Report report = reportService.findByReportId(reportId);

        Map<String, Object> params = new HashMap<>();
        params.put(OperationConstant.PARAM_START_DATE, startDate);
        params.put(OperationConstant.PARAM_END_DATE, endDate);
        params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_AOL);

        if (report != null) {
            List<EmailTracker> emailTrackers = emailTrackerRepository.findByCreateDateBetween(dateStart, dateEnd);
            if (!emailTrackers.isEmpty()) {
                params.put(ReportConstant.FILENAME_PARAM, FileUtil.generateFileName(report.getRptName(), user));
                reportGenerator.generate(reportId, user, params);
            }
        }
    }
}
