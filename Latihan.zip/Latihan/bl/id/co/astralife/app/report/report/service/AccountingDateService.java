package id.co.astralife.app.report.report.service;

import java.util.Date;

public interface AccountingDateService {

	Boolean checkEndDate(Date date);
}
