package id.co.astralife.app.report.schedule.service;

import org.quartz.SchedulerException;

import java.text.ParseException;

/**
 * Created by fadil.wiranata.
 */
public interface SchedulerCronService {

    void updateTriggerCronExpression(String triggerGroup, String triggerName, String cronExpression)
            throws ParseException, SchedulerException;
}
