package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.CertificateService;
import id.co.astralife.app.report.report.service.ReportService;

public class CertificateJob extends QuartzJobBean{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CertificateJob.class);

	@Autowired
	CertificateService certificateService;
	
	@Autowired
	ReportService reportService;
	
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START Certificate Job----------");

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    	
        Calendar date = Calendar.getInstance();
        date.add(Calendar.DATE, -1);
        String issdate = sdf.format(date.getTime());
        String trdate = issdate;
        
		List<Report> report = reportService.findBySchedule(ReportConstant.DAILY);
		
		for (Report rpt : report) {
			if(rpt.getTemplate().equals(OperationConstant.CERTIFICATE)){
				certificateService.generateCertificate(rpt.getReportId(), "SYSTEM", issdate);
			} else if (rpt.getTemplate().equals(OperationConstant.PRINT_REPORT)){
				certificateService.generatePrintReport(rpt.getReportId(), issdate);
			} else if (rpt.getTemplate().equals(OperationConstant.AVA_IPRO_KREDITKU)){
				certificateService.generateIproKreditku(rpt.getReportId(), "SYSTEM", trdate);
			} 
		}
		
		LOGGER.info("----------END Certificate Job----------");
	}
}
