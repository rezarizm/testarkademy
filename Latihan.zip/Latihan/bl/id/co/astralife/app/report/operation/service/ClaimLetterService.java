package id.co.astralife.app.report.operation.service;

import java.util.List;
import java.util.UUID;

import id.co.astralife.app.report.dm.entity.Claim;

public interface ClaimLetterService {

	void generateClaimLetter (UUID reportId, String user, String startDate, String endDate);
	
	void generateClaimLetter (UUID reportId, String user, String startDate, String endDate, String letterType, String reprint, List<Claim> claims);
	
	void generateEmailClaimLetter (UUID reportId, String user, String startDate, String endDate, String reprint, List<Claim> claims);
	
}
