package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

public interface DailyCommissionAppBuddiesService {

	void generateCommissionAppBuddiesDetail(UUID reportId, String user, String date, String dateParam);
	void generateCommissionAppBuddiesSummary(UUID reportId, String user, String date, String dateParam);
	
}
