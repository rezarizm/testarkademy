package id.co.astralife.app.report.sales.support.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.local.repository.ReportFileRepository;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.FeeBasedService;

@Service
public class FeeBasedServiceImpl implements FeeBasedService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FeeBasedServiceImpl.class);

	@Autowired
	private ReportService reportService;

	@Autowired
	private ReportGenerator reportGenerator;

	@Autowired
	private ReportFileRepository reportFileRepository;

	@Override
	public void generateFeeBased(UUID rptId, String user, String genDate) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		
		SimpleDateFormat sdfName = new SimpleDateFormat("yyyyMMdd");
		Calendar calendarName = Calendar.getInstance();
		calendarName.add(Calendar.MONTH, -1);
		int lastDate = calendarName.getActualMaximum(Calendar.DATE);
		calendarName.set(Calendar.DATE, lastDate);
		String dateName = sdfName.format(calendarName.getTime());
		
		Date from = null;
		Date to = null;
		try {
			from = sdf.parse(genDate + "000000");
			to = sdf.parse(genDate + "235959");
		} catch (ParseException e) {
			LOGGER.error("ParseException" + e.getMessage());
		}
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);

		Report report = reportService.findByReportId(rptId);
		ReportFile file = reportFileRepository.findFirstByRptIdAndCreateDateBetween(rptId, from, to);
		if (null != report && null == file) {
			params.put(ReportConstant.FILENAME_PARAM, "FR" + dateName.substring(2));
			params.put(SalesSupportConstant.DATE_PARAM, genDate);
			reportGenerator.generate(report.getReportId(), user, params);
		}
	}
}