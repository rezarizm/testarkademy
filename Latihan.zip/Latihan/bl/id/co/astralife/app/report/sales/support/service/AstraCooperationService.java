package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

public interface AstraCooperationService {

	void generateAstraCooperation(UUID rptId, String user, String dateString);
}
