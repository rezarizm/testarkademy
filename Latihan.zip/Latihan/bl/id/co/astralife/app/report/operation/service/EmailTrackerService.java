package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface EmailTrackerService {

	void generateEmailTracker(UUID reportId, String user, String startDate, String endDate);
}
