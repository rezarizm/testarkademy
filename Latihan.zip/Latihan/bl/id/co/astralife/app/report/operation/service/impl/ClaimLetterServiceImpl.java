
package id.co.astralife.app.report.operation.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.dm.entity.Claim;
import id.co.astralife.app.report.dm.repository.ClaimLetterRepository;
import id.co.astralife.app.report.email.service.EmailService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.ClaimLetterService;
import id.co.astralife.app.report.report.service.ReportService;

@Service
public class ClaimLetterServiceImpl implements ClaimLetterService {

	@Autowired
	ReportGenerator reportGenerator;

	@Autowired
	ReportService reportService;

	@Autowired
	ClaimLetterRepository claimLetterRepository;

	@Autowired
	EmailService emailService;

	@Autowired
	Environment env;

	@Override
	public void generateClaimLetter(UUID reportId, String user, String startDate, String endDate) {

		List<Claim> claims = claimLetterRepository.findClaimData("", "", "", startDate, endDate);

		List<Claim> claimsToProcess = new ArrayList<>();
		for (Claim claimProcess : claims) {
			if (claimProcess.getLetterType().equals(ReportConstant.FULL_REJECT)) {
				if (claimProcess.getCountZz5() == 0
						|| (claimProcess.getCountZz5() > 0 && claimProcess.getCountCorrDate() > 0)) {
					claimsToProcess.add(claimProcess);
				}
			} else {
				claimsToProcess.add(claimProcess);
			}
		}

		if (!claimsToProcess.isEmpty()) {
			ArrayList<String> list = new ArrayList<>();
			for (Claim claim : claimsToProcess) {
				list.add(claim.getLetterType());
			}
			ArrayList<String> result = new ArrayList<>();
			HashSet<String> set = new HashSet<>();

			for (String letterType : list) {
				if (!set.contains(letterType)) {
					result.add(letterType);
					set.add(letterType);
				}
			}

			for (String letterType : result) {
				this.generateClaimLetter(reportId, user, startDate, endDate, letterType, "N", claimsToProcess);
			}
			this.generateEmailClaimLetter(reportId, user, startDate, endDate, "N", claimsToProcess);
		}
	}

	@Override
	public void generateClaimLetter(UUID reportId, String user, String startDate, String endDate, String letterType,
			String reprint, List<Claim> claims) {

		Report report = reportService.findByReportId(reportId);

		List<Claim> newClaims = new ArrayList<>();
		for (Claim claim : claims) {
			if (claim.getLetterType().equals(letterType)) {
				newClaims.add(claim);
			}
		}

		List<String> claimsPrint = new ArrayList<>();
		for (Claim claim : newClaims) {
			Claim claimDetail = claimLetterRepository.findClaimDetail(claim.getChdrnum(), claim.getLetterType(),
					claim.getClamnum(), claim.getOccNo());

			if (claimDetail != null) {
				boolean print = claimDetail.getPrint().equals(ReportConstant.PRINT);
				boolean printEmpty = claimDetail.getPrint().trim().isEmpty();
				boolean printWithCondition = claimDetail.getPrint().equals(ReportConstant.NO_PRINT)
						&& claimDetail.getYgEmail().equals(EmailConstant.EMAIL)
						&& claimDetail.getEmailTo().trim().isEmpty() && claim.getCountPrint() > 0;

				if (print || printEmpty || printWithCondition) {
					claimsPrint.add(claim.getClamnumOcc());
				}
			}
		}

		Map<String, Object> params = new HashMap<>();
		params.put("startdate", startDate);
		params.put("enddate", endDate);
		params.put("lettype", letterType);
		params.put("reprint", reprint);
		params.put("claim_print", claimsPrint);

		if (report != null) {
			params.put(ReportConstant.FILENAME_PARAM,
					FileUtil.generateFileName(report.getRptName() + "_" + letterType, user));
			params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
			if (!claimsPrint.isEmpty()) {
				reportGenerator.generate(report.getReportId(), user, params);
			}
		}
	}

	@Override
	public void generateEmailClaimLetter(UUID reportId, String user, String startDate, String endDate, 
			String reprint, List<Claim> claims) {
		
		Report report = reportService.findByReportId(reportId);
		
		if (report != null) {
			for(Claim claim : claims) {
				List<String> claimPrint = new ArrayList<>();
				claimPrint.add(claim.getClamnumOcc());
				
				Map<String, Object> params = new HashMap<>();
				params.put("clamnum", claim.getClamnum());
				params.put("occno", claim.getOccNo());
				params.put("startdate", claim.getReqDate());
				params.put("enddate", claim.getReqDate());
				params.put("claim_print", claimPrint);
				params.put("reprint", reprint);
				
				String fileName = FileUtil.generateFileName(report.getRptName() + "_" + claim.getClamnum() + claim.getOccNo(), user);
				String attachmentName = fileName+"."+(report.getFormat().equals(ReportConstant.XLS)?"xlsx":report.getFormat().toLowerCase());
				String filePath = env.getProperty("dir.pathOutput");
				
				Claim claimDetail = claimLetterRepository.findClaimDetail(
						claim.getChdrnum(), claim.getLetterType(), claim.getClamnum(), claim.getOccNo());
						
				if (claimDetail != null && claimDetail.getYgEmail().equals(EmailConstant.EMAIL)) {
					// params for sending email
					params.put(EmailConstant.EMAIL, true);
					params.put(EmailConstant.PARAM_YGEMAIL, claimDetail.getYgEmail());
					params.put(EmailConstant.PARAM_EMAIL_FROM, EmailConstant.EMAIL_HELLO_AL);
					params.put(EmailConstant.PARAM_TO_ID, claimDetail.getEmailTo().trim());
					params.put(EmailConstant.PARAM_CC_ID, (EmailConstant.EMAIL_GROUP_CLAIM
							+(claimDetail.getEmailCc().trim().isEmpty() ? "" : ", "+claimDetail.getEmailCc())));
					params.put(EmailConstant.PARAM_SUBJECT, claimLetterRepository.getSubjectEmail(claim.getChdrnum(), claim.getClamnum(), claim.getOccNo()));
					params.put(EmailConstant.PARAM_CONTENT, EmailConstant.CONTENT_CLAIM);
					params.put(EmailConstant.PARAM_ATTACH_NAME, attachmentName);
					params.put(EmailConstant.PARAM_FILEPATH, filePath+attachmentName);
					
					params.put(ReportConstant.FILENAME_PARAM, fileName);
					params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
					reportGenerator.generate(report.getReportId(), user, params);
				}
			}
		}
	}
}