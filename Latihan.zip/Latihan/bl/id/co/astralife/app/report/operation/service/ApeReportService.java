package id.co.astralife.app.report.operation.service;

import id.co.astralife.app.report.model.ApeRptForm;

import java.net.ConnectException;

public interface ApeReportService {

    void generateApeReport(ApeRptForm newForm, String user);

}
