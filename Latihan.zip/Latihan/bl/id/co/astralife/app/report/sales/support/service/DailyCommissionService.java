package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

public interface DailyCommissionService {

	void generateCommissionDetail(UUID reportId, String user, String date, String dateParam);
	
	void generateCommissionSummary(UUID reportId, String user, String date, String dateParam);
	
}
