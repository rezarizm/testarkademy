package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.NewBusinessService;

/**
 * Created by fadil.wiranata.
 */
public class NewBusinessJob extends QuartzJobBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(NewBusinessJob.class);

    @Autowired
    private ReportService reportService;

    @Autowired
    private NewBusinessService newBusinessService;

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
    	LOGGER.info("----------START New Business AFC & ASTRA Job----------");
    	
    	SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmmss");
    	Calendar calendar = Calendar.getInstance();
    	String genDate = sdf.format(calendar.getTime());
    	
        List<Report> report = reportService.findBySchedule(ReportConstant.DAILY);
        String fileName = "";
        
        for (Report rpt :report){
            if (rpt.getTemplate().equals(SalesSupportConstant.NEW_BUSINESS_AFC)){
            	fileName = SalesSupportConstant.NB_FILENAME + genDate;
                newBusinessService.generateNewBusiness(rpt.getReportId(), "SYSTEM", fileName);
            } else if (rpt.getTemplate().equals(SalesSupportConstant.NEW_BUSINESS_ASTRA)) {
            	fileName = SalesSupportConstant.NB_ASTRA_FILENAME + genDate;
            	newBusinessService.generateNewBusiness(rpt.getReportId(), "SYSTEM", fileName);
            }
        }
        
        LOGGER.info("----------END New Business AFC & ASTRA Job----------");
    }
}
