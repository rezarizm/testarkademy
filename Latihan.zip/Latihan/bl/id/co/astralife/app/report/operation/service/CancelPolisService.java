package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface CancelPolisService {

	void generateCancelPolis(UUID reportId, String user, String startDate, String endDate, String startDate1, String endDate1);
}
