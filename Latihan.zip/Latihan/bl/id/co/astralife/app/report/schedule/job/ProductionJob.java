package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import id.co.astralife.app.report.common.FinanceConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.finance.service.StatementOfAccountService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

public class ProductionJob extends QuartzJobBean{

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductionJob.class);

	@Autowired
    StatementOfAccountService statementOfAccountService;

    @Autowired
    ReportService reportService;
    
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START Production Job----------");
	
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    	
        Calendar calStart = Calendar.getInstance();
    	calStart.add(Calendar.MONTH, -2);
    	String dateStart = sdf.format(calStart.getTime());
    	Integer yearStart = Integer.parseInt(dateStart.substring(6, 10));
		Integer monthStart = Integer.parseInt(dateStart.substring(3, 5));
		calStart.set(yearStart, monthStart, 1);
		
		Calendar calEnd = Calendar.getInstance();
		calEnd.add(Calendar.MONTH, -1);
		String dateEnd = sdf.format(calEnd.getTime());
		Integer yearEnd = Integer.parseInt(dateEnd.substring(6, 10));
		Integer monthEnd = Integer.parseInt(dateEnd.substring(3, 5));
		calEnd.set(yearEnd, monthEnd, 0);
    	
		String startDate = sdf.format(calStart.getTime());
		String endDate = sdf.format(calEnd.getTime());
		
		LOGGER.info("------------------------");
		LOGGER.info("startDate : "+startDate);
		LOGGER.info("endDate : "+endDate);
		LOGGER.info("------------------------");
		
		List<Report> report = reportService.findBySchedule(ReportConstant.MONTHLY);
		
		for (Report rpt :report){
			if (rpt.getTemplate().equals(FinanceConstant.PRODUCTION)){
            	statementOfAccountService.generateProduction(rpt.getReportId(), "SYSTEM", startDate, endDate);
            } else if (rpt.getTemplate().equals(FinanceConstant.PRODUCTION_PDF)){
            	statementOfAccountService.generateProductionPdf(rpt.getReportId(), "SYSTEM", monthEnd.toString(), yearEnd.toString());
            }
		}
		
		LOGGER.info("-----------END Production Job-----------");
	}
}
