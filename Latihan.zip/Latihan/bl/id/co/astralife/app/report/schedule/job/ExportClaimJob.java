package id.co.astralife.app.report.schedule.job;

import id.co.astralife.app.report.ib.service.ExportClaimService;
import id.co.astralife.app.report.model.ExportClaimRequest;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ExportClaimJob extends QuartzJobBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExportClaimJob.class);

    @Autowired
    private ExportClaimService exportClaimService;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        LOGGER.info("----------START Export Claim Job----------");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Calendar calendar = Calendar.getInstance();
        String genDate = sdf.format(calendar.getTime());

        ExportClaimRequest exportReq = new ExportClaimRequest();
        exportReq.setStartDate(genDate);
        exportReq.setEndDate(genDate);
        exportReq.setUser("SYSTEM");
        exportReq.setSend(true);

        exportClaimService.generateExportClaim(exportReq);

        LOGGER.info("----------START Export Claim Job----------");
    }
}
