package id.co.astralife.app.report.exception;

/**
 * @author fadil.wiranata
 */
public class ParameterRequiredException extends RuntimeException {

    private static final long serialVersionUID = 2379857800446488088L;

    public ParameterRequiredException(String msg) {
        super(msg);
    }

    public ParameterRequiredException(String msg, Throwable t) {
        super(msg, t);
    }
}
