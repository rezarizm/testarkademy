package id.co.astralife.app.report.ib.service;

import id.co.astralife.app.report.model.ExportClaimRequest;

public interface ExportClaimService {

    void generateExportClaim(ExportClaimRequest exportReq);
}
