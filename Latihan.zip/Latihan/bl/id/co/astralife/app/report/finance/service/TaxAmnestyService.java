package id.co.astralife.app.report.finance.service;

import java.util.UUID;

public interface TaxAmnestyService {

	void generateTaxAmnesty(UUID reportId, String user);
	
}
