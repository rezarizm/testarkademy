package id.co.astralife.app.report.finance.service;

import java.util.UUID;

public interface AgentETaxService {

	void generateAgentETax(UUID reportId, String user);
}
