package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.ReNovaService;

/**
 * 
 * @author Michael
 * 
 * @Since 26 Jul 2017
 */
public class ReNovaJob extends QuartzJobBean{

	private static final Logger LOGGER = LoggerFactory.getLogger(ReNovaJob.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private ReNovaService reNovaService;
	
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		
		LOGGER.info("-------------START ReNova Job------------");
		
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMYYYY");
		String dateString = sdf.format(date);
		
		List<Report> reports = reportService.findBySchedule(ReportConstant.MONTHLY);
		
		for(Report report : reports){
			if(report.getTemplate().equals(OperationConstant.RENOVA))
				reNovaService.generateReNova(report.getReportId(), "SYSTEM", dateString);
		}
		
		LOGGER.info("-------------END ReNova Job-----------");
	}

}
