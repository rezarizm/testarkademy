package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

public interface FeeBasedService {
	
	void generateFeeBased(UUID rptId, String user, String genDate);
	
}