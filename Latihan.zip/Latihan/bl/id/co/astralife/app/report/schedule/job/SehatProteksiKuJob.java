package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.SehatProteksiKuService;
import id.co.astralife.app.report.report.service.ReportService;

public class SehatProteksiKuJob extends QuartzJobBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(SehatProteksiKuJob.class);

    @Autowired
    private SehatProteksiKuService sehatProteksiKuService;

    @Autowired
    private ReportService reportService;

    @Override
    protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
        LOGGER.info("----------START Sehat ProteksiKu Job----------");

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        Calendar date = Calendar.getInstance();
        date.add(Calendar.DATE, -1);
        String actionDate = sdf.format(date.getTime());

        List<Report> report = reportService.findBySchedule(ReportConstant.DAILY);

        for (Report rpt : report) {
            if (rpt.getTemplate().equals(OperationConstant.AVA_SEHAT_PROTEKSIKU)) {
                LOGGER.info("--GENERATE AVA Sehat Proteksiku: {}--", actionDate);
                sehatProteksiKuService.generateSehatProteksiKu(rpt.getReportId(), "SYSTEM", actionDate);
            }
        }

        LOGGER.info("----------END Sehat ProteksiKu Job----------");
    }
}
