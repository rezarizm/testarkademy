package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.IncentiveService;

public class IncentiveJob extends QuartzJobBean {
	public static final Logger LOGGER = LoggerFactory.getLogger(IncentiveJob.class);

	@Autowired
	private ReportService reportService;

	@Autowired
	private IncentiveService incentiveService;

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START Incentive Report Job----------");

		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");

		Calendar startCalendar = Calendar.getInstance();
		startCalendar.add(Calendar.MONTH, -1);
		startCalendar.set(Calendar.DATE, startCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		
		Calendar endCalendar = Calendar.getInstance();
		endCalendar.set(Calendar.DATE, endCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));

		Calendar genCalendar = Calendar.getInstance();
		String genDate = sdf.format(genCalendar.getTime());
		
		String startDate = sdf.format(startCalendar.getTime());
		String endDate = sdf.format(endCalendar.getTime());

		Report report = reportService.findByTemplate(SalesSupportConstant.INCENTIVE_REPORT);

		if (null != report) {
			incentiveService.generateIncentiveReport(report.getReportId(), "SYSTEM", genDate, startDate, endDate);
		}

		LOGGER.info("----------END Incentive Report Job----------");

	}
}