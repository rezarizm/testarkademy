package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.ClaimPregEmailService;
import id.co.astralife.app.report.report.service.ReportService;

public class ClaimPregEmailJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(ClaimPregEmailJob.class);
			
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private ClaimPregEmailService claimPregEmailService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START Claim Pre-Registration Email Job----------");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar calendar =  Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		String startDate = sdf.format(calendar.getTime());
		
		List<Report> reports = reportService.findBySchedule(ReportConstant.DAILY);
		for (Report rpt : reports){
			if(rpt.getTemplate().equals(OperationConstant.CLAIM_PRE_REG)){
				claimPregEmailService.processEmail(rpt.getReportId(), startDate, startDate, "SYSTEM");
				LOGGER.info("----------Processing Claim Pre-Registration in to processEmail method----------");
			}
		}
		
		LOGGER.info("----------END Claim Pre-Registration Email Job----------");
	}
}