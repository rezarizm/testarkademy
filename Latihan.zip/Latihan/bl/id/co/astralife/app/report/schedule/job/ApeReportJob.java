package id.co.astralife.app.report.schedule.job;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.ApeRptForm;
import id.co.astralife.app.report.operation.service.ApeReportService;
import id.co.astralife.app.report.report.service.ReportService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ApeReportJob extends QuartzJobBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(BiReportJob.class);

    @Autowired
    ApeReportService apeReportService;

    @Autowired
    ReportService reportService;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        LOGGER.info("----------START APE Report Job----------");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Calendar calendar = Calendar.getInstance();
        String dt = sdf.format(calendar.getTime());
        ApeRptForm newForm = new ApeRptForm();
        newForm.setStartDate(dt);
        newForm.setEndDate(dt);
        String user = "SYSTEM";

        Report report = reportService.findByTemplate(OperationConstant.APE_REPORT);
        if (null != report) {
            try {
                apeReportService.generateApeReport(newForm,user);
            }
            catch (Exception e) {
                LOGGER.error("ApeReportJob: Exception", e);
            }
        }

        LOGGER.info("----------END APE Report Job----------");
    }
}
