package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.ClaimReportGasiaConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.ClaimReportGasiaRequest;
import id.co.astralife.app.report.operation.service.ClaimReportGasiaService;
import id.co.astralife.app.report.report.service.ReportService;

public class ClaimReportGasiaJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(ClaimReportGasiaJob.class);

	@Autowired
	private ClaimReportGasiaService claimReportGasiaService;

	@Autowired
	private ReportService reportService;

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START Claim Report GASIA Job----------");

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		
		Calendar startCalendar = Calendar.getInstance();
		startCalendar.set(Calendar.DATE, 1);
		
		Calendar endCalendar = Calendar.getInstance();
		endCalendar.set(Calendar.DATE, endCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		
		String startDate = sdf.format(startCalendar.getTime());
		String endDate = sdf.format(endCalendar.getTime());

		Report report = reportService.findByTemplate(ClaimReportGasiaConstant.CLAIM_PAID_REPORT);
		if (null != report) {
			ClaimReportGasiaRequest claimReq = new ClaimReportGasiaRequest();
			claimReq.setUser("SYSTEM");
			claimReq.setStartDate(startDate);
			claimReq.setEndDate(endDate);
			claimReportGasiaService.processClaimGasia(claimReq);
		}

		LOGGER.info("----------END Claim Report GASIA Job----------");

	}

}
