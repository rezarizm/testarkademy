package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.GuaranteedCashPaymentConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportGuaranteedCashPaymentService;
import id.co.astralife.app.report.report.service.ReportService;

public class GuaranteedCashPaymentReportJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(GuaranteedCashPaymentReportJob.class);
	@Autowired
	private ReportService reportService;
	@Autowired
	private ReportGuaranteedCashPaymentService reportGuaranteedCashPaymentService ;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START Report Guaranteed Cash Payment Job----------");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.DATE, -1);
		String genDate = sdf.format(calendar.getTime());

		Report report = reportService.findByTemplate(GuaranteedCashPaymentConstant.GUARANTEED_CASH_PAYMENT_RPT_TEMPLATE);
		
		if(null != report){
			
			reportGuaranteedCashPaymentService.generateGuaranteedCashReport(report.getReportId(),  genDate, genDate ,"SYSTEM", true);
		}
        
		LOGGER.info("----------END Report Guaranteed Cash Payment Job----------");
	}

}
