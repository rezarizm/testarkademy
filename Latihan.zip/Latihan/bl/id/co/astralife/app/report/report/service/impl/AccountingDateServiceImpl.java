package id.co.astralife.app.report.report.service.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.iplus.entity.AccountingYear;
import id.co.astralife.app.report.iplus.repository.AccountingYearRepository;
import id.co.astralife.app.report.report.service.AccountingDateService;

@Service
public class AccountingDateServiceImpl implements AccountingDateService{

	@Autowired
	private AccountingYearRepository accountingYearRepository;
	
	@Override
	public Boolean checkEndDate(Date date) {
		Boolean end = false;
		
		AccountingYear accountingYear = accountingYearRepository.findFirstByEndDate(date);
		
		if(accountingYear != null)
			end = true;
		
		return end;
	}

}
