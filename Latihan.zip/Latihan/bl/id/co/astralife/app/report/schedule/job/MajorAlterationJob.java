package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.MajorAlterationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.ib.service.MajorAlterationService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;

public class MajorAlterationJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(MajorAlterationJob.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private MajorAlterationService majorAlterationService;

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		
		LOGGER.info("----------START Major Alteration Job----------");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar calendar =  Calendar.getInstance();
		calendar.add(Calendar.DATE, -1);
		String startDate = sdf.format(calendar.getTime());
		
		List<Report> reports = reportService.findBySchedule(ReportConstant.DAILY);
		for (Report report : reports) {
			if (report.getTemplate().equals(MajorAlterationConstant.UNUSED_PREM_TEMPLATE)) {
				majorAlterationService.generateUnusedPremium(report.getReportId(), "SYSTEM", "", startDate, startDate);
			} else if (report.getTemplate().equals(MajorAlterationConstant.MAJOR_ALT_HISTORY_TEMPLATE)) {
				majorAlterationService.generateMajorAlterationHistory(report.getReportId(), "SYSTEM", "", startDate, startDate);
			}
		}
		
		LOGGER.info("----------END Major Alteration Job----------");
	}

}
