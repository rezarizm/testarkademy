package id.co.astralife.app.report.report.service.impl;

import org.springframework.stereotype.Service;

import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.report.service.ConfigService;

@Service
public class ConfigServiceImpl implements ConfigService {

	private ConfigRepository configRepository;
	
	public ConfigServiceImpl (ConfigRepository configRepository) {
		this.configRepository = configRepository;
	}
	
	@Override
	public void save(Config config) {
		configRepository.save(config);
	}

	@Override
	public Config findFirstByConfigName(String configName) {
		return configRepository.findFirstByConfigName(configName);
	}

}
