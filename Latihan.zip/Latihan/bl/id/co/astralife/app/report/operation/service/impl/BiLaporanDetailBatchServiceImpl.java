package id.co.astralife.app.report.operation.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.operation.service.BiLaporanDetailBatchService;
/**
 * 
 * @author Michael
 *
 * @Since 7 Des 2017
 */
@Service
public class BiLaporanDetailBatchServiceImpl implements BiLaporanDetailBatchService {

	@Autowired
	private ReportGenerator reportGenerator;
	
	@Override
	public void generateBiLaporanDetail(UUID reportId, String user, String biType) {
		Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		String dateReport = sdf.format(date);
    	
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
		params.put(ReportConstant.FILENAME_PARAM, biType + dateReport);
		reportGenerator.generate(reportId, user, params);
	}
	
}
