package id.co.astralife.app.report.report.service;

import id.co.astralife.app.report.local.entity.Config;

public interface ConfigService {

	void save(Config config);
	
	Config findFirstByConfigName(String configName);
}
