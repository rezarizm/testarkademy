package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.DailyCommissionIsaveService;

public class DailyCommissionIsaveJob extends QuartzJobBean {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DailyCommissionIsaveJob.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private DailyCommissionIsaveService dailyCommissionIsaveService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START Daily iSave Job----------");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdfLong = new SimpleDateFormat("yyyyMMdd_HHmm");
		
		Calendar startCalendar = Calendar.getInstance();
		startCalendar.set(Calendar.DATE, 1);
		
		Calendar endCalendar = Calendar.getInstance();
		endCalendar.set(Calendar.DATE, endCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		
		Calendar calendar = Calendar.getInstance();
		String genDate = sdf.format(calendar.getTime());
		String genDateLong = sdfLong.format(calendar.getTime());
		String startDate = sdf.format(startCalendar.getTime());
		String endDate = sdf.format(endCalendar.getTime());
		String fileName = "IN_DAILY_" + genDate + "_Daily_Comm_RMCS_iSAVE_" + genDateLong;
		
		Report report = reportService.findByTemplate(SalesSupportConstant.DAILY_COMMISSION_ISAVE);
		
		if (report != null) {
			dailyCommissionIsaveService.generateDailyIsave(report.getReportId(), "SYSTEM", fileName, genDate, startDate, endDate);
		}
		
		LOGGER.info("----------END Daily iSave Job----------");
	}

}
