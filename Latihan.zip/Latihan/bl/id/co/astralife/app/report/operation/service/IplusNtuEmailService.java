package id.co.astralife.app.report.operation.service;

public interface IplusNtuEmailService {

	void sendEmailIplusNtuPolis(String user, String endDate);
	
}
