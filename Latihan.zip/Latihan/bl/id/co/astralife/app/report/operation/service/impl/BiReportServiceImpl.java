package id.co.astralife.app.report.operation.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.BiReportService;
import id.co.astralife.app.report.report.service.ReportService;

@Service
public class BiReportServiceImpl implements BiReportService {
	
	
	@Autowired
    private ReportGenerator reportGenerator;

    @Autowired
    private ReportService reportService;
	
	@Override
	public void generateBiReport(UUID reportId, String user, String month, String yearMonth) {
	
		Report report = reportService.findByReportId(reportId);
		
		Map<String, Object> params =  new HashMap<>();
    	params.put("yearMonth", yearMonth);
    	params.put("month", month);
    	
    	if (report!=null){
    		reportGenerator.generate(report.getReportId(), user, params);
    	}
	}
}
