package id.co.astralife.app.report.web;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import id.co.astralife.app.report.common.IbConstant;
import id.co.astralife.app.report.ib.service.ExportClaimService;
import id.co.astralife.app.report.model.ExportClaimRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/report/service")
public class ExportClaimController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExportClaimController.class);

    private final ExportClaimService exportClaimService;

    @Autowired
    public ExportClaimController(ExportClaimService exportClaimService) {
        this.exportClaimService = exportClaimService;
    }

    @RequestMapping(value = "/exportclaim", method = RequestMethod.POST)
    public String generateExportClaim(@RequestBody ExportClaimRequest exportReq) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            String params = mapper.writeValueAsString(exportReq);

            exportClaimService.generateExportClaim(exportReq);
            LOGGER.info("Generate Export Claim with params: {}", params);
        } catch (IllegalAccessError e) {
            LOGGER.error("IllegalAccessError: {}", e.getMessage());
            return IbConstant.IS_FAILED + ", " + IbConstant.ERROR_MESSAGE + ":" + e.getMessage();
        } catch (JsonProcessingException e) {
            LOGGER.error("JsonProcessingException: {}", e.getMessage());
        }

        return IbConstant.IS_SUCCESS;
    }
}
