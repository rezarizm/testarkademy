package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

public interface AolUserLoginCountService {

	void processAolUserLoginCopuntReport (UUID reportId, String user);
}
