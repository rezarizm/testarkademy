package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.BankRewardService;

public class BankRewardJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(BankRewardJob.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private BankRewardService bankRewardService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		
		LOGGER.info("-------------START BankReward Job------------");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
		SimpleDateFormat sdfParam = new SimpleDateFormat("MM-yyyy");
		
        Calendar calendar = Calendar.getInstance();
		String genDate = sdf.format(calendar.getTime());
		String fileName = "IS" + genDate;
		String dateParam = sdfParam.format(calendar.getTime());
		
		int today = calendar.get(Calendar.DATE); 
		int lastDay = calendar.getActualMaximum(Calendar.DATE);
		
		Report report = reportService.findByTemplate(SalesSupportConstant.BANK_REWARD);
		if (report != null && (today == 16 || today == lastDay)) {
			bankRewardService.generateBankReward(report.getReportId(), "SYSTEM", fileName, dateParam);
		}
		
		LOGGER.info("-------------END BankReward Job------------");
	}
}
