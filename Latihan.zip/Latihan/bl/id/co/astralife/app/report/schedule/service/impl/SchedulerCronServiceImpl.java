package id.co.astralife.app.report.schedule.service.impl;

import org.quartz.CronExpression;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerKey;
import org.quartz.impl.triggers.CronTriggerImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.schedule.service.SchedulerCronService;

import java.text.ParseException;

/**
 * Created by fadil.wiranata.
 */
@Service
public class SchedulerCronServiceImpl implements SchedulerCronService {

    private final SchedulerFactoryBean schedulerFactoryBean;

    @Autowired
    public SchedulerCronServiceImpl(SchedulerFactoryBean schedulerFactoryBean) {
        this.schedulerFactoryBean = schedulerFactoryBean;
    }

    @Override
    public void updateTriggerCronExpression(String triggerGroup, String triggerName, String cronExpression) throws ParseException, SchedulerException {
        Scheduler scheduler = schedulerFactoryBean.getScheduler();
        TriggerKey triggerKey = new TriggerKey(triggerName, triggerGroup);
        CronTriggerImpl cronTrigger = (CronTriggerImpl) scheduler.getTrigger(triggerKey);
        CronExpression expression = new CronExpression(cronExpression);
        cronTrigger.setCronExpression(expression);
        scheduler.rescheduleJob(triggerKey, cronTrigger);
    }
}
