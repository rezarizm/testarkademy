package id.co.astralife.app.report.config;

import java.io.IOException;
import java.util.Properties;

import javax.sql.DataSource;

import org.quartz.Trigger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.schedule.AutowiringSpringBeanJobFactory;
import id.co.astralife.app.report.schedule.job.AgentCommissionJob;
import id.co.astralife.app.report.schedule.job.AgentETaxJob;
import id.co.astralife.app.report.schedule.job.AolUserLoginCountJob;
import id.co.astralife.app.report.schedule.job.ApeReportJob;
import id.co.astralife.app.report.schedule.job.AsoReportJob;
import id.co.astralife.app.report.schedule.job.AutoRenewalJob;
import id.co.astralife.app.report.schedule.job.BankRewardJob;
import id.co.astralife.app.report.schedule.job.BiLaporanDetailBatchJob;
import id.co.astralife.app.report.schedule.job.BiLaporanJob;
import id.co.astralife.app.report.schedule.job.BiReportGroupJob;
import id.co.astralife.app.report.schedule.job.BiReportJob;
import id.co.astralife.app.report.schedule.job.BillingDetailJob;
import id.co.astralife.app.report.schedule.job.CertificateJob;
import id.co.astralife.app.report.schedule.job.ClaimLetterJob;
import id.co.astralife.app.report.schedule.job.ClaimPregEmailJob;
import id.co.astralife.app.report.schedule.job.DailyCommissionIsaveJob;
import id.co.astralife.app.report.schedule.job.DailyCommissionJob;
import id.co.astralife.app.report.schedule.job.DailyReportJob;
import id.co.astralife.app.report.schedule.job.EmailJob;
import id.co.astralife.app.report.schedule.job.EmailTrackerJob;
import id.co.astralife.app.report.schedule.job.ExcessJob;
import id.co.astralife.app.report.schedule.job.ExportClaimJob;
import id.co.astralife.app.report.schedule.job.FeeBasedJob;
import id.co.astralife.app.report.schedule.job.FinanceProductionJob;
import id.co.astralife.app.report.schedule.job.GroupPolicyJob;
import id.co.astralife.app.report.schedule.job.GuaranteedCashPaymentReportJob;
import id.co.astralife.app.report.schedule.job.IncentiveJob;
import id.co.astralife.app.report.schedule.job.IplusNtuEmailJob;
import id.co.astralife.app.report.schedule.job.IplusNtuIntJob;
import id.co.astralife.app.report.schedule.job.IplusNtuJob;
import id.co.astralife.app.report.schedule.job.MajorAlterationJob;
import id.co.astralife.app.report.schedule.job.MonthlyCommissionIsaveJob;
import id.co.astralife.app.report.schedule.job.NewBusinessJob;
import id.co.astralife.app.report.schedule.job.OjkEmailJob;
import id.co.astralife.app.report.schedule.job.OjkGeoCodeJob;
import id.co.astralife.app.report.schedule.job.PersistencyJob;
import id.co.astralife.app.report.schedule.job.PremiumJob;
import id.co.astralife.app.report.schedule.job.ProductionJob;
import id.co.astralife.app.report.schedule.job.ReNovaJob;
import id.co.astralife.app.report.schedule.job.ReportVoucherJob;
import id.co.astralife.app.report.schedule.job.SehatProteksiKuJob;
import id.co.astralife.app.report.schedule.job.SmePolicyJob;
import id.co.astralife.app.report.schedule.job.TaxAmnestyJob;

/**
 * @author fadil.wiranata
 */
@Configuration
@EnableScheduling
public class ScheduleConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleConfig.class);

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    @Qualifier("localDataSource")
    private DataSource dataSource;

    @Autowired
    @Qualifier("localTransactionManager")
    private PlatformTransactionManager transactionManager;

    @Autowired
    Environment env;

    @Bean
    public JobDetailFactoryBean premiumJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(PremiumJob.class);
        bean.setDurability(true);
        bean.setName("premiumJob");
        bean.setGroup(ReportConstant.FINANCE_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean premiumTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(premiumJob().getObject());
        cron.setBeanName("premiumTrigger");
        cron.setGroup(ReportConstant.FINANCE_JOBS);
        cron.setCronExpression(env.getProperty("premium-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean excessJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(ExcessJob.class);
        bean.setDurability(true);
        bean.setName("excessJob");
        bean.setGroup(ReportConstant.FINANCE_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean excessTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(excessJob().getObject());
        cron.setBeanName("excessTrigger");
        cron.setGroup(ReportConstant.FINANCE_JOBS);
        cron.setCronExpression(env.getProperty("excess-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean productionJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(ProductionJob.class);
        bean.setDurability(true);
        bean.setName("productionJob");
        bean.setGroup(ReportConstant.FINANCE_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean productionTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(productionJob().getObject());
        cron.setBeanName("productionTrigger");
        cron.setGroup(ReportConstant.FINANCE_JOBS);
        cron.setCronExpression(env.getProperty("production-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean biReportJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(BiReportJob.class);
        bean.setDurability(true);
        bean.setName("biReportJob");
        bean.setGroup(ReportConstant.FINANCE_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean biReportTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(biReportJob().getObject());
        cron.setBeanName("biReportTrigger");
        cron.setGroup(ReportConstant.FINANCE_JOBS);
        cron.setCronExpression(env.getProperty("biReport-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean persistencyJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(PersistencyJob.class);
        bean.setDurability(true);
        bean.setName("persistencyJob");
        bean.setGroup(ReportConstant.ACTUARY_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean persistencyTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(persistencyJob().getObject());
        cron.setBeanName("persistencyTrigger");
        cron.setGroup(ReportConstant.ACTUARY_JOBS);
        cron.setCronExpression(env.getProperty("persistency-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean certificateJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(CertificateJob.class);
        bean.setDurability(true);
        bean.setName("certificateJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean certificateTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(certificateJob().getObject());
        cron.setBeanName("certificateTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("certificate-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean sehatProteksiKuJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(SehatProteksiKuJob.class);
        bean.setDurability(true);
        bean.setName("sehatProteksiKuJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean sehatProteksiKuTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(sehatProteksiKuJob().getObject());
        cron.setBeanName("sehatProteksiKuTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("sehatProteksiKu-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean claimLetterJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(ClaimLetterJob.class);
        bean.setDurability(true);
        bean.setName("claimLetterJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean claimLetterTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(claimLetterJob().getObject());
        cron.setBeanName("claimLetterTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("claimLetter-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean taxAmnestyJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(TaxAmnestyJob.class);
        bean.setDurability(true);
        bean.setName("taxAmnestyJob");
        bean.setGroup(ReportConstant.FINANCE_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean taxAmnestyTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(taxAmnestyJob().getObject());
        cron.setBeanName("taxAmnestyTrigger");
        cron.setGroup(ReportConstant.FINANCE_JOBS);
        cron.setCronExpression(env.getProperty("taxAmnesty-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean emailJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(EmailJob.class);
        bean.setDurability(true);
        bean.setName("emailJob");
        bean.setGroup(ReportConstant.EMAIL_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean emailTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(emailJob().getObject());
        cron.setBeanName("emailTrigger");
        cron.setGroup(ReportConstant.EMAIL_JOBS);
        cron.setCronExpression(env.getProperty("email-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean emailTrackerJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(EmailTrackerJob.class);
        bean.setDurability(true);
        bean.setName("emailTrackerJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean emailTrackerTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(emailTrackerJob().getObject());
        cron.setBeanName("emailTrackerTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("emailTracker-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean agentETaxJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(AgentETaxJob.class);
        bean.setDurability(true);
        bean.setName("agentETaxJob");
        bean.setGroup(ReportConstant.FINANCE_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean agentETaxTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(agentETaxJob().getObject());
        cron.setBeanName("agentETaxTrigger");
        cron.setGroup(ReportConstant.FINANCE_JOBS);
        cron.setCronExpression(env.getProperty("agentETax-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean agentCommissionJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(AgentCommissionJob.class);
        bean.setDurability(true);
        bean.setName("agentCommissionJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean agentCommissionTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(agentCommissionJob().getObject());
        cron.setBeanName("agentCommissionTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("agentCommission-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean newBusinessJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(NewBusinessJob.class);
        bean.setDurability(true);
        bean.setName("newBusinessJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean newBusinessTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(newBusinessJob().getObject());
        cron.setBeanName("newBusinessTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("newBusiness-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean smePolicyJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(SmePolicyJob.class);
        bean.setDurability(true);
        bean.setName("smePolicyJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean smePolicyTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(smePolicyJob().getObject());
        cron.setBeanName("smePolicyTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("smePolicy-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean iplusNtuJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(IplusNtuJob.class);
        bean.setDurability(true);
        bean.setName("iplusNtuJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean iplusNtuTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(iplusNtuJob().getObject());
        cron.setBeanName("iplusNtuTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("iplusNtu-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean iplusNtuEmailJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(IplusNtuEmailJob.class);
        bean.setDurability(true);
        bean.setName("iplusNtuEmailJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean iplusNtuEmailTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(iplusNtuEmailJob().getObject());
        cron.setBeanName("iplusNtuEmailTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("iplusNtuEmail-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean iplusNtuIntJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(IplusNtuIntJob.class);
        bean.setDurability(true);
        bean.setName("iplusNtuIntJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean iplusNtuIntTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(iplusNtuIntJob().getObject());
        cron.setBeanName("iplusNtuIntTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("iplusNtuInt-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean dailyCommissionJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(DailyCommissionJob.class);
        bean.setDurability(true);
        bean.setName("dailyCommissionJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean dailyCommissionTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(dailyCommissionJob().getObject());
        cron.setBeanName("dailyCommissionTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("dailyCommission-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean financeProductionJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(FinanceProductionJob.class);
        bean.setDurability(true);
        bean.setName("financeProductionJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean financeProductionTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(financeProductionJob().getObject());
        cron.setBeanName("financeProductionTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("financeProd-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean claimPregEmailJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(ClaimPregEmailJob.class);
        bean.setDurability(true);
        bean.setName("claimPregEmailJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean claimPregEmailTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(claimPregEmailJob().getObject());
        cron.setBeanName("claimPregEmailTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("claimPregEmail-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean reportVoucherJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(ReportVoucherJob.class);
        bean.setDurability(true);
        bean.setName("reportVoucherJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public JobDetailFactoryBean biReportGroupJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(BiReportGroupJob.class);
        bean.setDurability(true);
        bean.setName("biReportGroupJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean reportVoucherTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(reportVoucherJob().getObject());
        cron.setBeanName("reportVoucherTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("reportVoucher-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean biLaporanJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(BiLaporanJob.class);
        bean.setDurability(true);
        bean.setName("biLaporanJob");
        bean.setGroup(ReportConstant.FINANCE_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean biLaporanTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(biLaporanJob().getObject());
        cron.setBeanName("biLaporanTrigger");
        cron.setGroup(ReportConstant.FINANCE_JOBS);
        cron.setCronExpression(env.getProperty("biLaporan-cron"));
        return cron;
    }

    @Bean
    public CronTriggerFactoryBean biReportGroupTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(biReportGroupJob().getObject());
        cron.setBeanName("biReportGroupTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("biReportGroup-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean dailyReportJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(DailyReportJob.class);
        bean.setDurability(true);
        bean.setName("dailyReportJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean dailyReportTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(dailyReportJob().getObject());
        cron.setBeanName("dailyReportTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("dailyReport-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean incentiveJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(IncentiveJob.class);
        bean.setDurability(true);
        bean.setName("incentiveJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean incentiveTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(incentiveJob().getObject());
        cron.setBeanName("incentiveTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("incentive-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean feeBasedJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(FeeBasedJob.class);
        bean.setDurability(true);
        bean.setName("feeBasedJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean feeBasedTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(feeBasedJob().getObject());
        cron.setBeanName("feeBasedTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("feeBased-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean reNovaJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(ReNovaJob.class);
        bean.setDurability(true);
        bean.setName("reNovaJob");
        bean.setGroup(ReportConstant.ACTUARY_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean reNovaTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(reNovaJob().getObject());
        cron.setBeanName("reNovaTrigger");
        cron.setGroup(ReportConstant.ACTUARY_JOBS);
        cron.setCronExpression(env.getProperty("reNova-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean biLaporanDetailBatchJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(BiLaporanDetailBatchJob.class);
        bean.setDurability(true);
        bean.setName("biLaporanDetailJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean biLaporanDetailBatchTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(biLaporanDetailBatchJob().getObject());
        cron.setBeanName("biLaporanDetailTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("biLaporanDetail-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean ojkGeoCodeJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(OjkGeoCodeJob.class);
        bean.setDurability(true);
        bean.setName("ojkGeoCodeJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean ojkGeoCodeTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(ojkGeoCodeJob().getObject());
        cron.setBeanName("ojkGeoCodeTrigger");
        cron.setGroup(ReportConstant.FINANCE_JOBS);
        cron.setCronExpression(env.getProperty("ojkGeoCode-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean ojkEmailJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(OjkEmailJob.class);
        bean.setDurability(true);
        bean.setName("ojkEmailJob");
        bean.setGroup(ReportConstant.FINANCE_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean ojkEmailTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(ojkEmailJob().getObject());
        cron.setBeanName("ojkEmailTrigger");
        cron.setGroup(ReportConstant.FINANCE_JOBS);
        cron.setCronExpression(env.getProperty("ojkEmail-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean groupPolicyJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(GroupPolicyJob.class);
        bean.setDurability(true);
        bean.setName("groupPolicyJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean groupPolicyTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(groupPolicyJob().getObject());
        cron.setBeanName("groupPolicyTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("groupPolicy-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean aolUserCountJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(AolUserLoginCountJob.class);
        bean.setDurability(true);
        bean.setName("aolUserCountJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean aolUserCountTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(aolUserCountJob().getObject());
        cron.setBeanName("aolUserCountTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("aolUserLoginCount-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean autoRenewalJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(AutoRenewalJob.class);
        bean.setDurability(true);
        bean.setName("autoRenewalJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean autoRenewalTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(autoRenewalJob().getObject());
        cron.setBeanName("autoRenewalTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("autoRenewal-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean dailyCommissionIsaveJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(DailyCommissionIsaveJob.class);
        bean.setDurability(true);
        bean.setName("dailyCommissionIsaveJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean dailyCommissionIsaveTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(dailyCommissionIsaveJob().getObject());
        cron.setBeanName("dailyCommissionIsaveTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("dailyCommissionIsave-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean monthlyCommissionIsaveJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(MonthlyCommissionIsaveJob.class);
        bean.setDurability(true);
        bean.setName("monthlyCommissionIsaveJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean monthlyCommissionIsaveTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(monthlyCommissionIsaveJob().getObject());
        cron.setBeanName("monthlyCommissionIsaveTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("monthlyCommissionIsave-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean bankRewardJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(BankRewardJob.class);
        bean.setDurability(true);
        bean.setName("bankRewardJob");
        bean.setGroup(ReportConstant.CSS_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean bankRewardTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(bankRewardJob().getObject());
        cron.setBeanName("bankRewardTrigger");
        cron.setGroup(ReportConstant.CSS_JOBS);
        cron.setCronExpression(env.getProperty("bankReward-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean exportClaimJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(ExportClaimJob.class);
        bean.setDurability(true);
        bean.setName("exportClaimJob");
        bean.setGroup(ReportConstant.IB_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean exportClaimTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(exportClaimJob().getObject());
        cron.setBeanName("exportClaimTrigger");
        cron.setGroup(ReportConstant.IB_JOBS);
        cron.setCronExpression(env.getProperty("exportClaim-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean billingDetailJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(BillingDetailJob.class);
        bean.setDurability(true);
        bean.setName("billingDetailJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean billingDetailTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(billingDetailJob().getObject());
        cron.setBeanName("billingDetailTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("billingDetail-cron"));
        return cron;
    }

    @Bean
    public JobDetailFactoryBean apeReportJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(ApeReportJob.class);
        bean.setDurability(true);
        bean.setName("apeReportJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean apeReportTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(apeReportJob().getObject());
        cron.setBeanName("apeReportTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("apeReport-cron"));
        return cron;
    }
    
    @Bean
    public JobDetailFactoryBean asoReportJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(AsoReportJob.class);
        bean.setDurability(true);
        bean.setName("asoReportJob");
        bean.setGroup(ReportConstant.FINANCE_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean asoReportTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(asoReportJob().getObject());
        cron.setBeanName("asoReportTrigger");
        cron.setGroup(ReportConstant.FINANCE_JOBS);
        cron.setCronExpression(env.getProperty("asoReport-cron"));
        return cron;
    }
    
    @Bean
    public JobDetailFactoryBean majorAlterationJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(MajorAlterationJob.class);
        bean.setDurability(true);
        bean.setName("majorAlterationJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean majorAlterationTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(majorAlterationJob().getObject());
        cron.setBeanName("majorAlterationTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("majorAlteration-cron"));
        return cron;
    }
    
    @Bean
    public JobDetailFactoryBean gcpReportJob() {
        JobDetailFactoryBean bean = new JobDetailFactoryBean();
        bean.setJobClass(GuaranteedCashPaymentReportJob.class);
        bean.setDurability(true);
        bean.setName("gcpReportJob");
        bean.setGroup(ReportConstant.OPERATION_JOBS);
        return bean;
    }

    @Bean
    public CronTriggerFactoryBean gcpReportTrigger() {
        CronTriggerFactoryBean cron = new CronTriggerFactoryBean();
        cron.setJobDetail(gcpReportJob().getObject());
        cron.setBeanName("gcpReportTrigger");
        cron.setGroup(ReportConstant.OPERATION_JOBS);
        cron.setCronExpression(env.getProperty("gcpReport-cron"));
        return cron;
    }

    @Bean
    public SchedulerFactoryBean quartzScheduler() {
        SchedulerFactoryBean scheduler = new SchedulerFactoryBean();
        scheduler.setOverwriteExistingJobs(true);
        scheduler.setSchedulerName("report-scheduler");

        AutowiringSpringBeanJobFactory jobFactory = new AutowiringSpringBeanJobFactory();
        jobFactory.setApplicationContext(applicationContext);
        scheduler.setJobFactory(jobFactory);

        scheduler.setDataSource(dataSource);
        scheduler.setTransactionManager(transactionManager);
        scheduler.setWaitForJobsToCompleteOnShutdown(true);
        scheduler.setQuartzProperties(quartzProperties());

        Trigger[] triggers = {
                premiumTrigger().getObject(),
                excessTrigger().getObject(),
                productionTrigger().getObject(),
                biReportTrigger().getObject(),
                persistencyTrigger().getObject(),
                certificateTrigger().getObject(),
                sehatProteksiKuTrigger().getObject(),
                claimLetterTrigger().getObject(),
                taxAmnestyTrigger().getObject(),
                emailTrigger().getObject(),
                emailTrackerTrigger().getObject(),
                agentETaxTrigger().getObject(),
                agentCommissionTrigger().getObject(),
                newBusinessTrigger().getObject(),
                smePolicyTrigger().getObject(),
                iplusNtuTrigger().getObject(),
                iplusNtuEmailTrigger().getObject(),
                iplusNtuIntTrigger().getObject(),
                dailyCommissionTrigger().getObject(),
                financeProductionTrigger().getObject(),
                claimPregEmailTrigger().getObject(),
                reportVoucherTrigger().getObject(),
                biReportGroupTrigger().getObject(),
                biLaporanTrigger().getObject(),
                dailyReportTrigger().getObject(),
                incentiveTrigger().getObject(),
                feeBasedTrigger().getObject(),
                reNovaTrigger().getObject(),
                biLaporanDetailBatchTrigger().getObject(),
                ojkGeoCodeTrigger().getObject(),
                ojkEmailTrigger().getObject(),
                groupPolicyTrigger().getObject(),
                aolUserCountTrigger().getObject(),
                autoRenewalTrigger().getObject(),
                dailyCommissionIsaveTrigger().getObject(),
                monthlyCommissionIsaveTrigger().getObject(),
                bankRewardTrigger().getObject(),
                exportClaimTrigger().getObject(),
                billingDetailTrigger().getObject(),
                apeReportTrigger().getObject(),
                asoReportTrigger().getObject(),
                majorAlterationTrigger().getObject(),
                gcpReportTrigger().getObject()
        };

        scheduler.setTriggers(triggers);
        return scheduler;
    }

    private Properties quartzProperties() {
        PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();
        propertiesFactoryBean.setLocation(new ClassPathResource("/quartz.properties"));
        Properties properties = null;
        try {
            propertiesFactoryBean.afterPropertiesSet();
            properties = propertiesFactoryBean.getObject();
        } catch (IOException e) {
            LOGGER.error("Unable to load quartz.properties", e);
        }
        return properties;
    }

}