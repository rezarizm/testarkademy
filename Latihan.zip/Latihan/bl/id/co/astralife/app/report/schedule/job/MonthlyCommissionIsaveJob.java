package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.MonthlyCommissionIsaveService;

public class MonthlyCommissionIsaveJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(MonthlyCommissionIsaveJob.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private MonthlyCommissionIsaveService monthlyCommissionIsaveService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START Monthly iSave Job----------");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdfGen = new SimpleDateFormat("yyyyMMdd_HHmm");
		
		Calendar startCalendar = Calendar.getInstance();
		startCalendar.set(Calendar.DATE, 1);
		
		Calendar endCalendar = Calendar.getInstance();
		endCalendar.set(Calendar.DATE, endCalendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		
		Calendar calendar = Calendar.getInstance();
		String genDate = sdfGen.format(calendar.getTime());
		String startDate = sdf.format(startCalendar.getTime());
		String endDate = sdf.format(endCalendar.getTime());
		String fileName = "Monthly_Comm_RMCS_iSAVE_" + genDate;
		
		Report report = reportService.findByTemplate(SalesSupportConstant.MONTHLY_COMMISSION_ISAVE);
		
		if (report != null) {
			monthlyCommissionIsaveService.generateMonthlyIsave(report.getReportId(), "SYSTEM", fileName, startDate, endDate);
		}
		
		LOGGER.info("----------END Monthly iSave Job----------");
	}
}
