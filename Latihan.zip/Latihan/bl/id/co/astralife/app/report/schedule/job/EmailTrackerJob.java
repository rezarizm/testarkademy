package id.co.astralife.app.report.schedule.job;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.EmailTrackerService;
import id.co.astralife.app.report.report.service.ReportService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class EmailTrackerJob extends QuartzJobBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailTrackerJob.class);

    @Autowired
    EmailTrackerService emailTrackerService;

    @Autowired
    ReportService reportService;

    @Override
    protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
        LOGGER.info("----------START Email Tracker Job----------");

        SimpleDateFormat formatString = new SimpleDateFormat("yyyyMMdd");
        Calendar start = Calendar.getInstance();
        start.add(Calendar.DATE, -1);
        String startDate = formatString.format(start.getTime());

        List<Report> reports = reportService.findBySchedule(ReportConstant.DAILY);

        for (Report rpt : reports) {
            if (rpt.getTemplate().equals(OperationConstant.EMAIL_TRACKER)) {
                //sysdate-1, start and end date are the same
                emailTrackerService.generateEmailTracker(rpt.getReportId(), "SYSTEM", startDate, startDate);
            }
        }

        LOGGER.info("----------END Email Tracker Job----------");
    }

}
