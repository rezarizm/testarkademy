package id.co.astralife.app.report.schedule.job;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.email.service.EmailService;

public class EmailJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailJob.class);
	
	@Autowired
	EmailService emailService;
	
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START Email Job----------");
		
		emailService.emailScheduler("SYSTEM");
		
		LOGGER.info("----------END Email Job----------");
	}
}
