package id.co.astralife.app.report.operation.service;

import net.sf.jasperreports.engine.JRException;

import java.net.ConnectException;
import java.sql.SQLException;
import id.co.astralife.app.report.model.BillingDetailRequest;

public interface BillingDetailService {

    public void generateBillingDetail(BillingDetailRequest request) throws ConnectException, SQLException, JRException;

}
