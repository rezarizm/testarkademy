package id.co.astralife.app.report.web;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.SmePolicyConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.ClaimLetterRequest;
import id.co.astralife.app.report.model.SmePolicyRequest;
import id.co.astralife.app.report.operation.service.ClaimLetterService;
import id.co.astralife.app.report.operation.service.SmePolicyService;
import id.co.astralife.app.report.report.service.ReportService;

@RestController
@RequestMapping(value = "/report/service")
public class RestControllerReport {

	private static final Logger LOGGER = LoggerFactory.getLogger(RestControllerReport.class);
	private static final String SUCCESS = "success";
	private static final String ERROR = "ERROR: report or data is not found";

	@Autowired
	private ClaimLetterService claimLetterService;
	
	@Autowired
	private SmePolicyService smePolicyService;

	@Autowired
	private ReportService reportService;

	@RequestMapping(value = "/claimletter", method = RequestMethod.POST)
	public String claimLetterService(@RequestBody ClaimLetterRequest claimReq, HttpServletResponse response) {

		Report report = reportService.findByTemplate(OperationConstant.CLAIM_LETTER);
		// user = "SYSTEM", startDate = (yyyyMMdd) &  endDate = (yyyyMMdd)
		if (report != null && StringUtils.isNotBlank(claimReq.getUser()) && StringUtils.isNotBlank(claimReq.getStartDate()) 
				&& StringUtils.isNotBlank(claimReq.getEndDate())) {
			claimLetterService.generateClaimLetter(report.getReportId(), claimReq.getUser(), claimReq.getStartDate(),
					claimReq.getEndDate());
			return SUCCESS;
		} else {
			LOGGER.error(ERROR);
			return ERROR;
		}
	}
	
	@RequestMapping(value = "/smepolicy", method = RequestMethod.POST)
	public String smePolicyService(@RequestBody SmePolicyRequest smeReq, HttpServletResponse response) {

		Report report = reportService.findByTemplate(SmePolicyConstant.SME_POLICY);
		// user = "SYSTEM" & startDate = (yyyyMMdd) & endDate = (yyyyMMdd)
		if (report != null && StringUtils.isNotBlank(smeReq.getUser()) && StringUtils.isNotBlank(smeReq.getStartDate())
				&& StringUtils.isNotBlank(smeReq.getEndDate())) {
			smePolicyService.generateSmePolicy(report.getReportId(), smeReq.getUser(), smeReq.getStartDate(),
					smeReq.getEndDate());
			return SUCCESS;
		} else {
			LOGGER.error(ERROR);
			return ERROR;
		}
	}	
}
