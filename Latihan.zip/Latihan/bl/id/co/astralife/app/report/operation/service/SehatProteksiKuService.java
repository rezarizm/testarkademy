package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface SehatProteksiKuService {

	void generateSehatProteksiKu(UUID reportId, String user, String actionDate);
}
