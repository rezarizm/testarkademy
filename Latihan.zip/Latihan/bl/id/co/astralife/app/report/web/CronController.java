package id.co.astralife.app.report.web;

import id.co.astralife.app.report.model.CronRequest;
import id.co.astralife.app.report.schedule.service.SchedulerCronService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Created by fadil.wiranata.
 */
@RestController
@RequestMapping("/api")
public class CronController {

    private Logger logger = LoggerFactory.getLogger(CronController.class);

    @Autowired
    private SchedulerCronService schedulerCronService;

    @RequestMapping(value = "/cron", method = RequestMethod.POST)
    public ResponseEntity<String> updateTriggerCronExpression(@RequestBody CronRequest cronRequest) {
        logger.info("Update trigger: " + cronRequest.getTriggerName() + " with cron expression: " + cronRequest.getCronExpression());
        try {
            schedulerCronService.updateTriggerCronExpression(cronRequest.getTriggerGroup(), cronRequest.getTriggerName(), cronRequest.getCronExpression());
        } catch (Exception ex) {
            return new ResponseEntity<>(ex.getMessage()+ex, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>("OK. Update trigger: " + cronRequest.getTriggerName() + ", cron: " + cronRequest.getCronExpression(), HttpStatus.OK);
    }
}
