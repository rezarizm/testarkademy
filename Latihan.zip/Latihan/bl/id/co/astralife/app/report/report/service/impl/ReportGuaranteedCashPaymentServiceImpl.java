package id.co.astralife.app.report.report.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.FinanceConstant;
import id.co.astralife.app.report.common.GuaranteedCashPaymentConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.EmailUtil;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.dm.entity.GCPReport;
import id.co.astralife.app.report.dm.repository.GCPReportRepository;
import id.co.astralife.app.report.email.service.EmailService;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.report.service.ReportGuaranteedCashPaymentService;
import id.co.astralife.app.report.report.service.ReportService;

@Service
public class ReportGuaranteedCashPaymentServiceImpl implements ReportGuaranteedCashPaymentService{
	
	private static final String FROM_ID = "no-reply@astralife.co.id";
	private static final String DIR_PATH_OUTPUT = "dir.pathOutput";
	private static final Logger LOGGER = LoggerFactory.getLogger(ReportGuaranteedCashPaymentServiceImpl.class);
	@Value("${dir.email.template}")
	private String dirEmailTemp;

	private ReportService reportService;

	private ReportGenerator reportGenerator;

	private ConfigRepository configRepository;

	private Environment env;

	private GCPReportRepository gCPReportRepository;
	
	private final EmailService emailService;
	
	@Autowired
	public ReportGuaranteedCashPaymentServiceImpl(ReportService reportService, ReportGenerator reportGenerator,
			ConfigRepository configRepository, Environment env, GCPReportRepository gCPReportRepository, EmailService emailService) {
		this.reportService = reportService;
		this.reportGenerator = reportGenerator;
		this.configRepository = configRepository;
		this.env = env;
		this.gCPReportRepository = gCPReportRepository;
		this.emailService = emailService;
	}

	@Override
	public void generateGuaranteedCashReport(UUID rptId, String startDate, String endDate, String user, boolean isEmail) {

		Report report = reportService.findByReportId(rptId);

		GCPReport gcpReport = gCPReportRepository.countData(startDate, endDate);
	
		if(gcpReport.getCountData() >0) {
		Map<String, Object> params = new HashMap<>();

			
			String fileName = FileUtil.generateFileName(report.getRptName(), user);
			String attachmentName = fileName + "."
					+ ((ReportConstant.XLS).equals(report.getFormat()) ? "xlsx" : report.getFormat().toLowerCase());
			
			String filePath = env.getProperty(DIR_PATH_OUTPUT);
			
			List<Config> configs = configRepository.findData(GuaranteedCashPaymentConstant.GUARANTEED_CASH_PAYMENT_RPT_CONFIG);
			String toIds = EmailUtil.buildIdsFromConfig(configs);
			
			params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
			params.put(FinanceConstant.PARAM_START_DATE, startDate);
			params.put(FinanceConstant.PARAM_END_DATE, endDate);			
			
			if(isEmail) {
				String template = dirEmailTemp + GuaranteedCashPaymentConstant.GUARANTEED_CASH_PAYMENT_RPT_EMAIL_TEMPLATE;
				params.put(EmailConstant.EMAIL, true);
				params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
				params.put(EmailConstant.PARAM_EMAIL_FROM, FROM_ID);
				params.put(EmailConstant.PARAM_TO_ID, toIds);
				params.put(EmailConstant.PARAM_SUBJECT, GuaranteedCashPaymentConstant.GUARANTEED_CASH_PAYMENT_RPT_SUBJECT + startDate);
				params.put(EmailConstant.PARAM_CONTENT, emailService.renderByTemplate(template, "UTF-8", new HashMap<String, String>()));
				params.put(EmailConstant.PARAM_ATTACH_NAME, attachmentName);
				params.put(EmailConstant.PARAM_FILEPATH, filePath+attachmentName);
				
				params.put(EmailConstant.IS_VISIBLE, true);
			}	
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			
			reportGenerator.generate(rptId, user, params);
		}
		else {
			LOGGER.info("No Data for Guaranteed Cash Payment Report");
		}
			

	}  
	
	       
		
	
	


}
