package id.co.astralife.app.report.operation.service.impl;

import id.co.astralife.app.report.common.CryptoConstant;
import id.co.astralife.app.report.common.FtpConstant;
import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.ApeRptForm;
import id.co.astralife.app.report.operation.service.ApeReportService;
import id.co.astralife.app.report.report.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.net.ConnectException;
import java.util.HashMap;
import java.util.Map;

@Service
public class ApeReportServiceImpl implements ApeReportService {

    @Autowired
    private ReportService reportService;

    @Autowired
    private ReportGenerator reportGenerator;

    @Autowired
    private Environment env;

    @Override
    public void generateApeReport(ApeRptForm apeForm, String user) {
        Map<String, Object> params = new HashMap<>();
        params.put(OperationConstant.PARAM_START_DATE, apeForm.getStartDate());
        params.put(OperationConstant.PARAM_END_DATE, apeForm.getEndDate());
        params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
        params.put(ReportConstant.FILEQUERY_PARAM,ReportConstant.APE_REPORT_QUERY);
//        params.put(CryptoConstant.PGP_ENCRYPT,true);
        params.put(FtpConstant.SFTP,true);
        params.put(FtpConstant.FTP_OUTPUT_DIR,env.getProperty("dir.sftpApeReport"));


        Report report = reportService.findByTemplate(OperationConstant.APE_REPORT);
        String fileName = FileUtil.generateFileName(report.getRptName(), user);

        if (report.getReportId() != null) {
            params.put(ReportConstant.FILENAME_PARAM, fileName);
            params.put(FtpConstant.FTP_OUTPUT_NAME, fileName + ".xlsx");
            reportGenerator.generate(report.getReportId(),user,params);

        } else {
            throw new NullPointerException();
        }
    }
}
