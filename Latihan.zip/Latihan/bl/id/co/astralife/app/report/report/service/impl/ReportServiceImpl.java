package id.co.astralife.app.report.report.service.impl;

import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.repository.ReportRepository;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReportServiceImpl implements ReportService{

	@Autowired
	private ReportRepository reportRepository;
	
	@Override
	public Report findByReportId(UUID reportId) {
		return reportRepository.findByReportId(reportId);
	}

	@Override
	public Report findByRptName(String rptName) {
		return reportRepository.findByRptName(rptName);
	}
	
	@Override
	public Report findByTemplate(String template) {
		return reportRepository.findByTemplate(template);
	}

	@Override
	public List<Report> findAll() {
		return reportRepository.findAll();
	}

	@Override
	public List<Report> findBySchedule(String schedule) {
		return reportRepository.findBySchedule(schedule);
	}
}