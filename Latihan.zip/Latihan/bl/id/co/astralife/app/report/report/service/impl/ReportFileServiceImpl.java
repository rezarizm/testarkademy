package id.co.astralife.app.report.report.service.impl;

import java.util.UUID;

import id.co.astralife.app.report.report.service.ReportFileService;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.local.repository.ReportFileRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReportFileServiceImpl implements ReportFileService{

	@Autowired
	private ReportFileRepository reportFileRepository;

	@Override
	public ReportFile findById(UUID id) {
		return reportFileRepository.findById(id);
	}
	
	@Override
	public ReportFile save(ReportFile reportFile) {
		return reportFileRepository.save(reportFile);
	}

}
