package id.co.astralife.app.report.schedule.job;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OjkConstant;
import id.co.astralife.app.report.finance.service.OjkService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;

public class OjkGeoCodeJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(OjkGeoCodeJob.class);

	@Autowired
	private ReportService reportService;

	@Autowired
	private OjkService ojkService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START OJK GEO CODE JOB----------");

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdfTime = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar cal = Calendar.getInstance();

		cal.set(Calendar.DATE, 1);
		String startDate = sdf.format(cal.getTime());
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
		String endDate = sdf.format(cal.getTime());

		Date from = null;
		Date to = null;
		try {
			from = sdfTime.parse(startDate + "000000");
			to = sdfTime.parse(endDate + "235959");
		} catch (ParseException e) {
			LOGGER.error("ParseException:" + e.getMessage(), e);
		}
		
		Report report = reportService.findByTemplate(OjkConstant.OJK_REPORT_TEMP);
		if (report != null) {
			ojkService.getAddressByGeoCode(from, to, "SYSTEM");
		}

		LOGGER.info("----------END OJK GEO CODE JOB----------");
	}
}
