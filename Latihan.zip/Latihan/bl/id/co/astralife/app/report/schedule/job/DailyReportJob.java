package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.DailyReportService;

public class DailyReportJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(DailyReportJob.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private DailyReportService dailyReportService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START Daily Report Job----------");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdfLong = new SimpleDateFormat("dd MMMMM yyyy HHmm");
		Calendar calendar = Calendar.getInstance();
		String genDate = sdf.format(calendar.getTime());
		String genDateLong = sdfLong.format(calendar.getTime());
		String fileName = "IN_DAILY_" + genDate + "_In Branch Daily MI Report " + genDateLong 
				+ "_RMCS Selling";
		
		Report report = reportService.findByTemplate(SalesSupportConstant.DAILY_REPORT);
		
		if(null != report){
			dailyReportService.generateDailyReport(report.getReportId(), "SYSTEM", genDate, fileName);
		}
		
		LOGGER.info("----------END Daily Report Job----------");
	}
}