package id.co.astralife.app.report.operation.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ClaimReportGasiaConstant;
import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.ClaimReportGasiaRequest;
import id.co.astralife.app.report.operation.service.ClaimReportGasiaService;
import id.co.astralife.app.report.report.service.ReportService;

@Service
public class ClaimReportGasiaServiceImpl implements ClaimReportGasiaService {

	private final ReportService reportService;
	private final ReportGenerator reportGenerator;
	
	@Value("${dir.pathOutput}")
	private String pathOutput;
	
	@Autowired
	public ClaimReportGasiaServiceImpl(ReportService reportService, ReportGenerator reportGenerator) {
		this.reportService = reportService;
		this.reportGenerator = reportGenerator;
	}
	
	@Override
	public void processClaimGasia(ClaimReportGasiaRequest claimReq) {
		Report claimPaid = reportService.findByTemplate(ClaimReportGasiaConstant.CLAIM_PAID_REPORT);
		Report claimPayable = reportService.findByTemplate(ClaimReportGasiaConstant.CLAIM_PAYABLE_REPORT);
		
		this.generateClaimReport(claimReq, claimPaid);
		this.generateClaimReport(claimReq, claimPayable);
	}
	
	@Override
	public void generateClaimReport(ClaimReportGasiaRequest claimReq, Report report) {
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_DM);
		params.put(OperationConstant.PARAM_START_DATE, claimReq.getStartDate());
		params.put(OperationConstant.PARAM_END_DATE, claimReq.getEndDate());
		String emailSubject = report.getRptName() + "_" + claimReq.getStartDate() + "-" + claimReq.getEndDate();
		
		String fileName = FileUtil.generateFileName(report.getRptName(), claimReq.getUser());
		params.put(ReportConstant.FILENAME_PARAM, fileName);
		if (claimReq.getEmailAddress() != null && !claimReq.getEmailAddress().isEmpty()) {
			params.put(EmailConstant.EMAIL, true);
			params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
			params.put(EmailConstant.PARAM_EMAIL_FROM, EmailConstant.EMAIL_SENDER_NO_REPLY);
			params.put(EmailConstant.PARAM_TO_ID, claimReq.getEmailAddress());
			params.put(EmailConstant.PARAM_SUBJECT, emailSubject);
			params.put(EmailConstant.PARAM_CONTENT, " ");
			params.put(EmailConstant.PARAM_ATTACH_NAME, fileName + ".xlsx");
			params.put(EmailConstant.PARAM_FILEPATH, pathOutput + fileName + ".xlsx");			
		}
		reportGenerator.generate(report.getReportId(), claimReq.getUser(), params);
	}
	
}
