package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface IplusNtuInternalService {

	void processIplusNtuInternalReport (UUID reportId, String user, String endDate);
	
}
