package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

public interface MonthlyCommissionIsaveService {

	void generateMonthlyIsave(UUID rptId, String user, String fileName, String startDate, String endDate);

}
