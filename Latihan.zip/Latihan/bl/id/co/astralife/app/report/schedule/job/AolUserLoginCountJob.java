package id.co.astralife.app.report.schedule.job;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.AolUserLoginCountService;

public class AolUserLoginCountJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(IplusNtuIntJob.class);

	@Autowired
	private ReportService reportService;

	@Autowired
	private AolUserLoginCountService userLoginCountService;

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START AOL USER LOGIN COUNT REPORT Job----------");

		Report report = reportService.findByRptName(OperationConstant.AOL_USER_LOGIN_COUNT_REPORT);

		if (report != null) {
			userLoginCountService.processAolUserLoginCopuntReport(report.getReportId(), "SYSTEM");
		}

		LOGGER.info("----------END AOL USER LOGIN COUNT REPORT Job----------");
	}

}
