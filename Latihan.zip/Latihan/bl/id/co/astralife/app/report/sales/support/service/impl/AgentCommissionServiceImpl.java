package id.co.astralife.app.report.sales.support.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.AgentCommissionService;

@Service
public class AgentCommissionServiceImpl implements AgentCommissionService {

    private final ReportGenerator reportGenerator;

    private final ReportService reportService;

    @Autowired
    public AgentCommissionServiceImpl(ReportGenerator reportGenerator, ReportService reportService) {
        this.reportGenerator = reportGenerator;
        this.reportService = reportService;
    }

    @Override
    public void generateAgentCommission(UUID reportId, String user, String startDate, String endDate) {
        Report report = reportService.findByReportId(reportId);
        
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmmss");
    	Date date = new Date();
    	String genDate = sdf.format(date);
        
        Map<String, Object> params = new HashMap<>();
        params.put(SalesSupportConstant.PARAM_START_DATE, startDate);
        params.put(SalesSupportConstant.PARAM_END_DATE, endDate);
        params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
        
        if (report != null) {
        	if (report.getTemplate().equals(SalesSupportConstant.AGENT_COMMISSION)){
            	params.put(ReportConstant.FILENAME_PARAM, SalesSupportConstant.AC_AFC_FILENAME + genDate);
            } else if (report.getTemplate().equals(SalesSupportConstant.AGENT_COMMISSION_ECOM)){
            	params.put(ReportConstant.FILENAME_PARAM, SalesSupportConstant.AC_ECOMM_FILENAME + genDate);
            } else if (report.getTemplate().equals(SalesSupportConstant.AGENT_COMMISSION_ECOM_ASTRA_COOP)) {
            	params.put(ReportConstant.FILENAME_PARAM, SalesSupportConstant.AGENT_COMMISSION_ECOM_ASTRA_COOP_FILENAME + genDate);
            }
            reportGenerator.generate(report.getReportId(), user, params);
        }
    }
}