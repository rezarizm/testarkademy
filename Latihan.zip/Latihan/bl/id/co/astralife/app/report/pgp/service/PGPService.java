package id.co.astralife.app.report.pgp.service;

import java.util.List;

import id.co.astralife.app.report.exception.CryptoServiceException;

public interface PGPService {

	byte[] encrypt(byte[] plainText, String publicKey) throws CryptoServiceException;

	List<String> encryptFiles(List<String> filePaths);
}
