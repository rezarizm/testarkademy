package id.co.astralife.app.report.schedule.job;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import id.co.astralife.app.report.common.AsoConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.AsoService;
import id.co.astralife.app.report.report.service.ReportService;

public class AsoReportJob extends QuartzJobBean {

  private static final Logger LOGGER = LoggerFactory.getLogger(AsoReportJob.class);

  @Autowired
  private ReportService reportService;

  @Autowired
  private AsoService asoService;

  @Override
  protected void executeInternal(JobExecutionContext context) throws JobExecutionException {

    LOGGER.info("----------START ASO Report Job----------");

    Report report = reportService.findByTemplate(AsoConstant.ASO_REPORT);
    if (null != report) {
      asoService.generateAsoReport(report.getReportId(), "SYSTEM", true);
    }

    LOGGER.info("----------END ASO Report Job----------");
  }
}
