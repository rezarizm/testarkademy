package id.co.astralife.app.report.finance.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.FinanceConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.finance.service.TaxAmnestyService;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.report.service.ReportService;

@Service
public class TaxAmnestyServiceImpl implements TaxAmnestyService {

	@Autowired
    ReportGenerator reportGenerator;

    @Autowired
    ReportService reportService;
    
    @Autowired
	Environment env;
    
    @Autowired
    ConfigRepository configRepository;

	@Override
	public void generateTaxAmnesty(UUID reportId, String user) {

		Report report = reportService.findByReportId(reportId);
		
		Date dateTime = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
        String password = sdf.format(dateTime);
        
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.ZIP_COMP, true);
		params.put(ReportConstant.ZIP_PASS, password);
		
		if (report != null) {
			String fileName = report.getRptName() +"_"+ password;
			String attachmentName = fileName + ".zip";
			String filePath = env.getProperty("dir.pathOutput");
			
			List<Config> configs = configRepository.findData(FinanceConstant.TAX_AMNESTY_EMAIL);
			StringBuilder sb =  new StringBuilder();
			if (configs.isEmpty()) {
				sb.append("");
			} else {
				for (Config config : configs) {
					sb.append(config.getConfigValue()+",");
				}
				sb.deleteCharAt(sb.length()-1);
			}
			String toIds = sb.toString();
			// params for send email
			params.put(EmailConstant.EMAIL, true);
			params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
			params.put(EmailConstant.PARAM_EMAIL_FROM, EmailConstant.EMAIL_FROM_TAX_AMNESTY);
			params.put(EmailConstant.PARAM_TO_ID, toIds);
			params.put(EmailConstant.PARAM_SUBJECT, "Daily Report iPrime Khusus - "+password);
			params.put(EmailConstant.PARAM_CONTENT, EmailConstant.CONTENT_TAX_AMNESTY);
			params.put(EmailConstant.PARAM_ATTACH_NAME, attachmentName);
			params.put(EmailConstant.PARAM_FILEPATH, filePath+attachmentName);
			
			params.put(EmailConstant.IS_VISIBLE, true);
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			reportGenerator.generate(report.getReportId(), user, params);
		}
	}   
}
