package id.co.astralife.app.report.schedule.job;

import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.BiLaporanService;
import id.co.astralife.app.report.report.service.AccountingDateService;
import id.co.astralife.app.report.report.service.ReportService;

public class BiLaporanJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(BiLaporanJob.class);

	@Autowired
	BiLaporanService biLaporanService;

	@Autowired
	AccountingDateService accountingDateService;

	@Autowired
	ReportService reportService;

	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START BI Laporan Job----------");
		
		Calendar calendarStart = Calendar.getInstance();

		int year = calendarStart.get(Calendar.YEAR);
		int month = calendarStart.get(Calendar.MONTH) + 1;
		
		String yearString = Integer.toString(year);
		String monthString = Integer.toString(month);
		if (monthString.length() == 1) {
			monthString = "0" + monthString;			
		}	

		Report report = reportService.findByTemplate(OperationConstant.BI_LAPORAN);
		if (null != report) {
			biLaporanService.generateBiLaporan(report.getReportId(), "SYSTEM", monthString, yearString);
		}

		LOGGER.info("----------END BI Laporan Job----------");
	}

}
