package id.co.astralife.app.report.ib.service;

import java.util.UUID;

public interface MajorAlterationService {

	void generateUnusedPremium(UUID reportId, String user, String policyNo, String startDate, String endDate);
	
	void generateMajorAlterationHistory(UUID reportId, String user, String policyNo, String startDate, String endDate);
}
