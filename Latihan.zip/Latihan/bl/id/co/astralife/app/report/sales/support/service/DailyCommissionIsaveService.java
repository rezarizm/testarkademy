package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

public interface DailyCommissionIsaveService {

	void generateDailyIsave(UUID rptId, String user, String fileName, String genDate, String startDate, String endDate);

}
