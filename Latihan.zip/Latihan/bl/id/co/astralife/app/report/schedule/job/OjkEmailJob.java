package id.co.astralife.app.report.schedule.job;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OjkConstant;
import id.co.astralife.app.report.finance.service.OjkService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;

public class OjkEmailJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(OjkEmailJob.class);
	private static final String SYSTEM = "SYSTEM";
	
	@Autowired
	private ReportService reportService;

	@Autowired
	private OjkService ojkService;
	
	@Value("${ojk.remind.date}")
	private int remindDate;

	@Value("${ojk.sum.date}")
	private int sumDate;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START OJK Email Job----------");

		Calendar calendar = Calendar.getInstance();
        int date = calendar.get(Calendar.DATE);
        
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdfTime = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar cal = Calendar.getInstance();

		cal.set(Calendar.DATE, 1);
		String startDate = sdf.format(cal.getTime());
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
		String endDate = sdf.format(cal.getTime());

		Date from = null;
		Date to = null;
		try {
			from = sdfTime.parse(startDate + "000000");
			to = sdfTime.parse(endDate + "235959");
		} catch (ParseException e) {
			LOGGER.error("ParseException:" + e.getMessage(), e);
		}

		Report report = reportService.findByTemplate(OjkConstant.OJK_REPORT_TEMP);
		if (date == remindDate && report != null) {
			ojkService.remindUploadData(report.getReportId(), from, to, SYSTEM);
		}
		if (date == sumDate && report != null) {
			ojkService.generateAndEmailOjkReport(report.getReportId(), SYSTEM, OjkConstant.QUARTERLY, from, to);
			ojkService.generateAndEmailOjkReport(report.getReportId(), SYSTEM, OjkConstant.YEARLY, from, to);
		}
		
		LOGGER.info("----------END OJK Email Job----------");
	}
}
