package id.co.astralife.app.report.sales.support.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.local.repository.ReportFileRepository;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.IncentiveService;

@Service
public class IncentiveServiceImpl implements IncentiveService {

	private static final Logger LOGGER = LoggerFactory.getLogger(IncentiveServiceImpl.class);

	@Autowired
	private ReportGenerator reportGenerator;

	@Autowired
	private ReportService reportService;

	@Autowired
	private ReportFileRepository reportFileRepository;

	@Override
	public void generateIncentiveReport(UUID rptId, String user, String genDate, String startDate, String endDate) {

		SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss");
		SimpleDateFormat sdfParam = new SimpleDateFormat("yyyyMMddHHmmss");

		Date from = null;
		Date to = null;
		Date fromParam = null;
		Date toParam = null;
		try {
			from = sdf.parse(genDate + "000000");
			to = sdf.parse(genDate + "235959");
			fromParam = sdf.parse(startDate + "220001");
			toParam = sdf.parse(endDate + "220000");
		} catch (ParseException e) {
			LOGGER.error("ParseException" + e.getMessage());
		}
		String startDateParam = sdfParam.format(fromParam);
		String endDateParam = sdfParam.format(toParam);

		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
		params.put(SalesSupportConstant.PARAM_START_DATE, startDateParam);
		params.put(SalesSupportConstant.PARAM_END_DATE, endDateParam);

		Report report = reportService.findByReportId(rptId);
		ReportFile file = reportFileRepository.findFirstByRptIdAndCreateDateBetween(rptId, from, to);
		if (null == file && null != report) {
			params.put(ReportConstant.FILENAME_PARAM, "IR" + endDate);
			reportGenerator.generate(report.getReportId(), user, params);
		}
	}
}