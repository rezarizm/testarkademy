package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.FeeBasedService;

public class FeeBasedJob extends QuartzJobBean {

	public static final Logger LOGGER = LoggerFactory.getLogger(FeeBasedJob.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private FeeBasedService feeBasedService;
	
	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START Fee Based Report Job----------");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		Calendar genCalendar = Calendar.getInstance();
		String genDate = sdf.format(genCalendar.getTime());
		
		Report report = reportService.findByTemplate(SalesSupportConstant.FEE_BASED_REPORT);
		
		if (null != report){
			feeBasedService.generateFeeBased(report.getReportId(), "SYSTEM", genDate);
		}
		 
		LOGGER.info("----------END Fee Based Report Job----------");
	}
}