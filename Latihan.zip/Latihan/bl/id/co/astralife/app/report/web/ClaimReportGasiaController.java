package id.co.astralife.app.report.web;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import id.co.astralife.app.report.common.ClaimReportGasiaConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.ClaimReportGasiaRequest;
import id.co.astralife.app.report.operation.service.ClaimReportGasiaService;
import id.co.astralife.app.report.report.service.ReportService;

@RestController
@RequestMapping(value = "/report/service")
public class ClaimReportGasiaController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ClaimReportGasiaController.class);
	private static final String IS_SUCCESS = "success";
	private static final String IS_FAILED = "failed";
	private static final String ERROR_MESSAGE = "errorMessage";

	private final ClaimReportGasiaService claimReportGasiaService;
	private final ReportService reportService;

	@Autowired
	public ClaimReportGasiaController(ClaimReportGasiaService claimReportGasiaService, ReportService reportService) {
		this.claimReportGasiaService = claimReportGasiaService;
		this.reportService = reportService;
	}

	@RequestMapping(value = "/claimgasia", method = RequestMethod.POST)
	public String generateClaimReport(@RequestBody ClaimReportGasiaRequest claimReq, HttpServletResponse response) {
		Report report = new Report();
		try {
			if (claimReq.getTypeReport().equals(ClaimReportGasiaConstant.CLAIM_PAID_REPORT)) {
				report = reportService.findByTemplate(ClaimReportGasiaConstant.CLAIM_PAID_REPORT);
			} else {
				report = reportService.findByTemplate(ClaimReportGasiaConstant.CLAIM_PAYABLE_REPORT);
			}
			claimReportGasiaService.generateClaimReport(claimReq, report);
		} catch (IllegalAccessError e) {
			LOGGER.error("IllegalAccessError:", e.getMessage());
			return IS_FAILED + ", " + ERROR_MESSAGE + ":" + e.getMessage();
		}
		return IS_SUCCESS;
	}

}
