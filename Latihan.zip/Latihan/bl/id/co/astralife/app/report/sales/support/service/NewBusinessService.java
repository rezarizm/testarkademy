package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

/**
 * Created by fadil.wiranata.
 */
public interface NewBusinessService {

    void generateNewBusiness(UUID reportId, String user, String fileName);
    
}
