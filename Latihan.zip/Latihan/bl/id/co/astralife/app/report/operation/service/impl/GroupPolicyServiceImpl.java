package id.co.astralife.app.report.operation.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.GroupPolicyConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.mirror.entity.GroupPolicy;
import id.co.astralife.app.report.mirror.repository.GroupPolicyRepository;
import id.co.astralife.app.report.operation.service.GroupPolicyService;

@Service
public class GroupPolicyServiceImpl implements GroupPolicyService {

	private static final Logger LOGGER = LoggerFactory.getLogger(GroupPolicyServiceImpl.class);

	@Autowired
	private GroupPolicyRepository groupPolicyRepository;

	@Autowired
	private ReportGenerator reportGenerator;

	@Override
	public void generateGroupPolicy(UUID reportId, String user, String startDate, String endDate) {
		List<GroupPolicy> groupPolicies = groupPolicyRepository.findByDateBetween(startDate, endDate);
		if (groupPolicies.isEmpty()) {
			LOGGER.info("----------Processing GROUP LIFE POLICY, data is empty with date between {} to {} ----------",
					startDate, endDate);
		} else {
			LOGGER.info("----------Processing GROUP LIFE POLICY, generating file with date between {} to {} ----------",
					startDate, endDate);
			for (GroupPolicy groupPolicy : groupPolicies) {
				GroupPolicy gpForNextRow = groupPolicyRepository.findForNextRow(groupPolicy.getPolicyNo(),
						groupPolicy.getTranNo());
				GroupPolicy checkReversed = groupPolicyRepository.findCheckReversed(gpForNextRow.getPolicyNo(),
						gpForNextRow.getId() + 1);
				if (checkReversed == null) {
					Map<String, Object> params = new HashMap<>();
					params.put(GroupPolicyConstant.PARAM_POL_NO, groupPolicy.getPolicyNo());
					params.put(GroupPolicyConstant.PARAM_TRAN_NO, groupPolicy.getTranNo());
					params.put(GroupPolicyConstant.PARAM_CNT_TYPE, groupPolicy.getCntType());
					params.put(GroupPolicyConstant.PARAM_PRINT_PC, "Y");
					params.put(GroupPolicyConstant.PARAM_PRINT_BS, "Y");
					params.put(GroupPolicyConstant.PARAM_PRINT_PS, "Y");
					params.put(GroupPolicyConstant.PARAM_PRINT_GP, "Y");
					params.put(GroupPolicyConstant.PARAM_REPRINT, "N");
					params.put(ReportConstant.FILENAME_PARAM,
							FileUtil.generateFileName("Group_Life_" + groupPolicy.getPolicyNo(), user));
					reportGenerator.generate(reportId, user, params);
				}
			}
		}
	}
}