package id.co.astralife.app.report.operation.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.FileUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.iplus.repository.ContractRepository;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.CertificateService;
import id.co.astralife.app.report.report.service.ReportService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CertificateServiceImpl implements CertificateService {

    @Autowired
    ReportGenerator reportGenerator;

    @Autowired
    ReportService reportService;

    @Autowired
    ContractRepository contractRepository; 
    
    @Override
    public void generateCertificate(UUID reportId, String user, String issdate) {
    	String issdatePrint = issdate.replaceAll("(.+)/(.+)/(.+)", "$3$2$1");
        generateCertificate(reportId, user, ReportConstant.POLICY_TYPE_GNL, "", "", "", issdatePrint, "N");
        generateCertificate(reportId, user, ReportConstant.POLICY_TYPE_GPA, "", "", "", issdatePrint, "N");
    }

    @Override
    public void generatePrintReport(UUID reportId, String issdate) {
        String issdatePrint = issdate.replaceAll("(.+)/(.+)/(.+)", "$3$2$1");
        generatePrintReport(reportId, ReportConstant.POLICY_TYPE_GNL, issdatePrint);
        generatePrintReport(reportId, ReportConstant.POLICY_TYPE_GPA, issdatePrint);
    }

    @Override
    public void generatePrintReport(UUID reportId, String policyType, String issdate) {
        Report report = reportService.findByReportId(reportId);
        Map<String, Object> params = new HashMap<>();
        params.put(OperationConstant.PARAM_POL_TYPE, policyType);
        params.put(OperationConstant.PARAM_ISS_DATE, issdate);
        if (report != null) {
            reportGenerator.generate(report.getReportId(), "SYSTEM", params);
        }
    }

    @Override
    public void generateCertificate(UUID reportId, String user, String policyType, String policyNo, String memberNo, String dependentNo, 
    		String issdate, String reprint) {
        Report report = reportService.findByReportId(reportId);
        Map<String, Object> params = new HashMap<>();
        params.put(OperationConstant.PARAM_POL_TYPE, policyType);
        params.put(OperationConstant.PARAM_POL_NO, policyNo);
        params.put(OperationConstant.PARAM_MEMBER_NO, memberNo);
        params.put(OperationConstant.PARAM_DPNT_NO, dependentNo);
        params.put(OperationConstant.PARAM_ISS_DATE, issdate);
        params.put(OperationConstant.PARAM_REPRINT, reprint);
        if (report != null) {
            //Custom file name
            params.put(ReportConstant.FILENAME_PARAM, FileUtil.generateFileName(report.getRptName() + "_" + policyType, user));
            reportGenerator.generate(report.getReportId(), user, params);
        }
    }

	@Override
	public void generateIproKreditku(UUID reportId, String user, String trdate) {
		String trdatePrint = trdate.replaceAll("(\\d{2})\\/(\\d{2})\\/\\d{2}(\\d{2})", "$3$2$1");
		generateIproKreditku(reportId, user, "", "", "", "", trdatePrint, "N" );
	}

	@Override
	public void generateIproKreditku(UUID reportId, String user, String policyNo, String memberNo, String dependentNo,
			String effDate, String trdate, String reprint) {
		Report report = reportService.findByReportId(reportId);
        Map<String, Object> params = new HashMap<>();
        params.put(OperationConstant.PARAM_POL_NO, policyNo);
        params.put(OperationConstant.PARAM_MEMBER_NO, memberNo);
        params.put(OperationConstant.PARAM_DPNT_NO, dependentNo);
        params.put(OperationConstant.PARAM_EFF_DATE, effDate);
        params.put(OperationConstant.PARAM_TR_DATE, trdate);
        params.put(OperationConstant.PARAM_REPRINT, reprint);
        if (report != null) {
        	params.put(ReportConstant.FILENAME_PARAM, FileUtil.generateFileName(report.getRptName(), user));
            reportGenerator.generate(report.getReportId(), user, params);
        }
	}
}
