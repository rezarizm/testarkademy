package id.co.astralife.app.report.schedule.job;

import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.FinanceConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.finance.service.TaxAmnestyService;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;

public class TaxAmnestyJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(TaxAmnestyJob.class);
	
	@Autowired
	ReportService reportService;
	
	@Autowired
	TaxAmnestyService taxAmnestyService; 
	
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		
		LOGGER.info("----------START Tax Amnesty Job----------");
		
		List<Report> reports = reportService.findBySchedule(ReportConstant.DAILY);
		
		for (Report rpt : reports) {
			if (rpt.getTemplate().equals(FinanceConstant.DAILY_REPORT_IPRIME_KHUSUS)){
				taxAmnestyService.generateTaxAmnesty(rpt.getReportId(), "SYSTEM");
			}
		}
		
		LOGGER.info("----------END Tax Amnesty Job----------");
	}

}
