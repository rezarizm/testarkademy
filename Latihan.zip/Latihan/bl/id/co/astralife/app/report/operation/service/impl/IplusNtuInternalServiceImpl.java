package id.co.astralife.app.report.operation.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.entity.ReportFile;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.local.repository.ReportFileRepository;
import id.co.astralife.app.report.local.repository.ReportRepository;
import id.co.astralife.app.report.operation.service.IplusNtuInternalService;

@Service 
public class IplusNtuInternalServiceImpl implements IplusNtuInternalService {

	private static final Logger LOGGER = LoggerFactory.getLogger(IplusNtuInternalServiceImpl.class);
			
	@Autowired
    private ReportGenerator reportGenerator;
	
	@Autowired
	private ReportRepository reportRepository;
	
	@Autowired
	private ReportFileRepository reportFileRepository;
	
	@Autowired
    private Environment env;
	
	@Autowired
    private ConfigRepository configRepository;
	
	@Override
	public void processIplusNtuInternalReport(UUID reportId, String user, String endDate) {
		
		Report report = reportRepository.findByReportId(reportId);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Date dateFrom = null;
		Date dateTo = null;
		try {
			dateFrom = sdf.parse(endDate+"000000");
			dateTo = sdf.parse(endDate+"235959");
		} catch (ParseException e) {
			LOGGER.error("ParseException"+e.getMessage());
		}
		
		Set<String> rptNames = new HashSet<>();
		rptNames.add(OperationConstant.PROPOSAL_POLIS);
		rptNames.add(OperationConstant.CANCEL_POLIS);
		
		Set<UUID> rptIds = this.getReportIds(rptNames);
		List<String> rptIdString = new ArrayList<>();
		for (UUID rptId : rptIds) {
			rptIdString.add(rptId.toString().toUpperCase().replaceAll("-", ""));
		}
		
		ReportFile fileNtuInt = reportFileRepository.findFirstByRptIdAndCreateByAndCreateDateBetween(reportId, user, dateFrom, dateTo);
		if (report != null && fileNtuInt == null) {
			Map<String, Object> params = new HashMap<>();
			params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_LOCAL);
			params.put(ReportConstant.FIELD_DELIMITER, "|");
			params.put(OperationConstant.PARAM_END_DATE, endDate);
			params.put("report_id", rptIdString);
			params.put("fileNameIn", OperationConstant.IPLUS_NTU_PROP_FILENAME+"|"+OperationConstant.IPLUS_NTU_CANCEL_FILENAME);
			
			String fileName = OperationConstant.IPLUS_NTU_INTERNAL_FILENAME + endDate;
			String attachmentName = fileName+"."+(report.getFormat().equals(ReportConstant.XLS)?"xlsx":report.getFormat().toLowerCase());
			String filePath = env.getProperty("dir.pathOutput");
			
			List<Config> configs = configRepository.findData(OperationConstant.IPLUS_NTU_EMAIL_IN);
			StringBuilder sb =  new StringBuilder();
			if (configs.isEmpty()) {
				sb.append("");
			} else {
				for (Config config : configs) {
					sb.append(config.getConfigValue()+",");
				}
				sb.deleteCharAt(sb.length()-1);
			}
			String toIds = sb.toString();
			
			// params for send email
			params.put(EmailConstant.EMAIL, true);
			params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
			params.put(EmailConstant.PARAM_EMAIL_FROM, EmailConstant.EMAIL_FROM_IPLUS_NTU);
			params.put(EmailConstant.PARAM_TO_ID, toIds);
			params.put(EmailConstant.PARAM_SUBJECT, EmailConstant.SUBJECT_IPLUS_NTU_IN);
			params.put(EmailConstant.PARAM_CONTENT, EmailConstant.CONTENT_IPLUS_NTU_IN);
			params.put(EmailConstant.PARAM_ATTACH_NAME, attachmentName);
			params.put(EmailConstant.PARAM_FILEPATH, filePath+attachmentName);
			
			params.put(EmailConstant.IS_VISIBLE, true);
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			reportGenerator.generate(report.getReportId(), user, params);
			
		}
	}
	
	private Set<UUID> getReportIds(Set<String> rptNames) {
		Set<UUID> rptIds = new HashSet<>();
		List<Report> reports = reportRepository.findByRptNameIn(rptNames);
		
		if(!reports.isEmpty()){
			for (Report report : reports){
				rptIds.add(report.getReportId());
			}
		}
		return rptIds;
	}
}