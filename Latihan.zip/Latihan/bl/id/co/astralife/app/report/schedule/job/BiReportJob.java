package id.co.astralife.app.report.schedule.job;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.BiReportService;
import id.co.astralife.app.report.report.service.ReportService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class BiReportJob extends QuartzJobBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(BiReportJob.class);

    @Autowired
    BiReportService biReportService;

    @Autowired
    ReportService reportService;

    @Override
    protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {

        LOGGER.info("----------START BI Report Job----------");
        Date date = new Date();
        Calendar calenderStart = Calendar.getInstance();
        calenderStart.setTime(date);
        calenderStart.add(Calendar.MONTH, -1);

        int year = calenderStart.get(Calendar.YEAR);
        int month = calenderStart.get(Calendar.MONTH) + 1;

        List<Report> reports = reportService.findBySchedule(ReportConstant.MONTHLY);

        for (Report report : reports) {
            if (report.getTemplate().equals(OperationConstant.BI_XLS)) {
                biReportService.generateBiReport(report.getReportId(), "SYSTEM", Integer.toString(month), Integer.toString(year));
            }
        }
        LOGGER.info("----------END BI Report Job----------");
    }

}
