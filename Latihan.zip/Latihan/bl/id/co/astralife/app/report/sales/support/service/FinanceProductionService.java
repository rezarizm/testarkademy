package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

import id.co.astralife.app.report.local.entity.Report;

/**
 * Service for finance production report.
 *
 * @since 30 Mei 2017
 * @version 1.0
 * @author sayid.sidqi
 */
public interface FinanceProductionService {

	/**
	 * Generate finance production report
	 * 
	 * @param reportId
	 *            identifier of {@link Report}.
	 * @param user
	 *            name of person or system who generate the report
	 */
	public void generateFinanceProdcution(UUID reportId, String user);

}
