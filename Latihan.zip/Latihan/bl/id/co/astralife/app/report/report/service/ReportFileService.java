package id.co.astralife.app.report.report.service;

import java.util.UUID;

import id.co.astralife.app.report.local.entity.ReportFile;

public interface ReportFileService {

	ReportFile findById (UUID id);
	
    ReportFile save(ReportFile reportFile);
    
}
