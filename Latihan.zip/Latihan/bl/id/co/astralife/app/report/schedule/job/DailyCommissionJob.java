package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.DailyCommissionAppBuddiesService;
import id.co.astralife.app.report.sales.support.service.DailyCommissionService;
import id.co.astralife.app.report.sales.support.service.AgentCommissionService;

public class DailyCommissionJob extends QuartzJobBean {
	
    private static final Logger LOGGER = LoggerFactory.getLogger(DailyCommissionJob.class);
	
    @Autowired
    private ReportService reportService;
    
    @Autowired
    private DailyCommissionService dailyCommissionService;
    
    @Autowired
    private DailyCommissionAppBuddiesService dailyCommissionAppBuddiesService;
    
    @Autowired
    private AgentCommissionService agentCommissionService;
    
    @Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
    	LOGGER.info("----------START Daily Commission Job----------");

    	SimpleDateFormat sdfSumm = new SimpleDateFormat("ddMMyyyy");
    	SimpleDateFormat sdfDet = new SimpleDateFormat("ddMMyyyyHHmmss");
    	SimpleDateFormat sdfParam = new SimpleDateFormat("yyyyMMdd");
    	
    	Calendar calendar = Calendar.getInstance();
    	String genDateSumm = sdfSumm.format(calendar.getTime());
    	String genDateDet = sdfDet.format(calendar.getTime());
    	String dateParam = sdfParam.format(calendar.getTime());
    			
    	Calendar startCalendar = Calendar.getInstance();
        startCalendar.set(Calendar.DATE, 1);
        String startDate = sdfParam.format(startCalendar.getTime());
        
        Calendar endCalendar = Calendar.getInstance();
        String endDate = sdfParam.format(endCalendar.getTime());
        
    	List<Report> reports = reportService.findBySchedule(ReportConstant.DAILY);
    	
    	for (Report rpt : reports){
    		if(rpt.getTemplate().equals(SalesSupportConstant.COMMISSION_DETAIL)){
    			dailyCommissionService.generateCommissionDetail(rpt.getReportId(), "SYSTEM", genDateDet, dateParam);
    		} else if (rpt.getTemplate().equals(SalesSupportConstant.COMMISSION_SUMMARY)){
    			dailyCommissionService.generateCommissionSummary(rpt.getReportId(), "SYSTEM", genDateSumm, dateParam);
    		} else if(rpt.getTemplate().equals(SalesSupportConstant.COMMISSION_APPBUDDIES_DETAIL)){
    			dailyCommissionAppBuddiesService.generateCommissionAppBuddiesDetail(rpt.getReportId(), "SYSTEM", genDateDet, dateParam);    			
    		} else if (rpt.getTemplate().equals(SalesSupportConstant.COMMISSION_APPBUDDIES_SUMMARY)){
    			dailyCommissionAppBuddiesService.generateCommissionAppBuddiesSummary(rpt.getReportId(), "SYSTEM", genDateSumm, dateParam);
    		} else if (rpt.getTemplate().equals(SalesSupportConstant.AGENT_COMMISSION_ECOM_ASTRA_COOP)){
        		agentCommissionService.generateAgentCommission(rpt.getReportId(), "SYSTEM", startDate, endDate);
            }
    	}
    	
    	LOGGER.info("----------END Daily Commission Job----------");
	}
}