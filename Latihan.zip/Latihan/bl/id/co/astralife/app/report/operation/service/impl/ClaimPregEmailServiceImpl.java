package id.co.astralife.app.report.operation.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.email.service.EmailService;
import id.co.astralife.app.report.local.entity.Email;
import id.co.astralife.app.report.mirror.entity.ClaimPreg;
import id.co.astralife.app.report.mirror.entity.ClaimPregEml;
import id.co.astralife.app.report.mirror.repository.ClaimPregEmlRepository;
import id.co.astralife.app.report.mirror.repository.ClaimPregRepository;
import id.co.astralife.app.report.operation.service.ClaimPregEmailService;

@Service
public class ClaimPregEmailServiceImpl implements ClaimPregEmailService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ClaimPregEmailServiceImpl.class);
			
	@Autowired
	private ClaimPregEmlRepository claimPregEmlRepository;
	
	@Autowired
	private ClaimPregRepository claimPregRepository;

	@Autowired
	private EmailService emailService;

	@Async
	public void processEmail(UUID reportId, String startDate, String endDate, String user) {
		List<ClaimPreg> claimPregs = claimPregRepository.findClaimPregByReceivedDateBetween(startDate, endDate);
		LOGGER.info("----------Processing Claim Pre-Registration, (GET) Data Size = {}----------",claimPregs.size());
		if(!claimPregs.isEmpty()){
			LOGGER.info("----------Processing Claim Pre-Registration, START execute data----------");
			List<Email> emails = new ArrayList<>();
			for (ClaimPreg claimPreg : claimPregs) {
				ClaimPregEml claimPregEml = claimPregEmlRepository.findEmailClaimPregByRefNoAndPolicyNoAndMbrNo(
						claimPreg.getRefNo(), claimPreg.getPolicyNo(),
						claimPreg.getMemberNo().substring(0, claimPreg.getMemberNo().lastIndexOf('-')));
				if (claimPregEml != null && claimPregEml.getYgcaPolNo() > 0) {
					Email email = new Email();
					email.setStatus(ReportConstant.PROCESSING);
					email.setYgEmail(EmailConstant.EMAIL);
					email.setFromId(EmailConstant.EMAIL_GROUP_CLAIM);
					email.setToId(claimPregEml.getEmpEmail() == null ? "" : claimPregEml.getEmpEmail().trim());
					email.setCcId(EmailConstant.EMAIL_GROUP_CLAIM);
					email.setSubject(EmailConstant.SUBJECT_CLAIMPREG + " - " + claimPreg.getPolicyNo() + " - "
							+ claimPreg.getMemberNo());
					email.setContent(this.getContent(claimPreg));
					email.setAttachName("");
					email.setAttachPath("");
					email.setCreateBy(user);
					email.setReportId(reportId);
					emails.add(email);
				}
			}
			LOGGER.info("----------Processing Claim Pre-Registration, END execute data----------");
			emailService.save(emails);
			LOGGER.info("----------Processing Claim Pre-Registration, (SAVE) Email Data Size = {}----------",emails.size());
		}
	}

	private String getContent(ClaimPreg claimPreg) {
		Map<String, String> contentParams = new HashMap<>();
		contentParams.put(EmailConstant.EMP_NAME, claimPreg.getEmplooyeeName());
		contentParams.put(EmailConstant.REC_DATE,
				claimPreg.getReceivedDate().replaceAll("(\\d{4})(\\d{2})(\\d{2})", "$3\\/$2\\/$1"));
		contentParams.put(EmailConstant.POL_NO, claimPreg.getPolicyNo());
		contentParams.put(EmailConstant.MBR_NO, claimPreg.getMemberNo());
		contentParams.put(EmailConstant.PATIENT_NAME, claimPreg.getPatientName());
		contentParams.put(EmailConstant.INV_DATE,
				claimPreg.getInvoiceDate().replaceAll("(\\d{4})(\\d{2})(\\d{2})", "$3\\/$2\\/$1"));
		contentParams.put(EmailConstant.REF_NO, claimPreg.getRefNo());
		return emailService.render(EmailConstant.CONTENT_CLAIMPREG, contentParams);
	}
}