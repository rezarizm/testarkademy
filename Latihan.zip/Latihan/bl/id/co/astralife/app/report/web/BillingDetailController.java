package id.co.astralife.app.report.web;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.model.BillingDetailRequest;
import id.co.astralife.app.report.operation.service.BillingDetailService;
import id.co.astralife.app.report.report.service.ReportService;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.net.ConnectException;
import java.sql.SQLException;

@RestController
@RequestMapping(value = "/report/service")
public class BillingDetailController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BillingDetailController.class);
	private static final String IS_SUCCESS = "success";
	private static final String IS_FAILED = "failed";
	private static final String ERROR_MESSAGE = "errorMessage";

	private final BillingDetailService billingDetailService;
	private final ReportService reportService;

	@Autowired
	public BillingDetailController(BillingDetailService billingDetailService, ReportService reportService) {
		this.billingDetailService = billingDetailService;
		this.reportService = reportService;
	}
	
	@RequestMapping(value = "/billing/detail", method = RequestMethod.POST)
	public String generatePropRenewal(@RequestBody BillingDetailRequest billingDetailRequest) {
		try {
			Report report = reportService.findByRptName(OperationConstant.BILLING_DETAIL);

			if (report != null && StringUtils.isNotBlank(billingDetailRequest.getUser()) && StringUtils.isNotBlank(billingDetailRequest.getStartDate())
					&& StringUtils.isNotBlank(billingDetailRequest.getEndDate()) ) {
				billingDetailService.generateBillingDetail(billingDetailRequest);
				return IS_SUCCESS;
			} else {
				LOGGER.error(IS_FAILED);
				return IS_FAILED;
			}

		} catch (IllegalAccessError e) {
			LOGGER.error("IllegalAccessError:{}", e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ":" + e.getMessage();
		} catch (ConnectException e) {
			LOGGER.error("ConnectException:{}", e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ":" + e.getMessage();
		} catch (SQLException e) {
			LOGGER.error("SQLException:{}", e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ":" + e.getMessage();
		} catch (JRException e) {
			LOGGER.error("JREException:{}", e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ":" + e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception:{}", e.getMessage(), e);
			return IS_FAILED + ", " + ERROR_MESSAGE + ":" + e.getMessage();
		}
	}
}
