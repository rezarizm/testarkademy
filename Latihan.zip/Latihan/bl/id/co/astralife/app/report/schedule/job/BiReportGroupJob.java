package id.co.astralife.app.report.schedule.job;

import java.util.Calendar;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.BiReportGroupService;
import id.co.astralife.app.report.report.service.ReportService;

public class BiReportGroupJob extends QuartzJobBean {

	private static final Logger LOGGER = LoggerFactory.getLogger(BiReportGroupJob.class);

	@Autowired
	private ReportService reportService;

	@Autowired
	private BiReportGroupService biReportGroupService;

	@Override
	protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
		LOGGER.info("----------START BI Report Group Job----------");

		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, -1);
		calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));

		// Calendar.MONTH start from 0
		Integer month = calendar.get(Calendar.MONTH) + 1;
		Integer year = calendar.get(Calendar.YEAR);

		Report report = reportService.findByTemplate(OperationConstant.BI_GROUP_XLS);
		if (null != report) {
			biReportGroupService.generateBiReportGroup(report.getReportId(), "SYSTEM", month.toString(),
					year.toString());
		}

		LOGGER.info("----------END BI Report Group Job----------");
	}
}