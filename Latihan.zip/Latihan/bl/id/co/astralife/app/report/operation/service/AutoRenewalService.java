package id.co.astralife.app.report.operation.service;

import java.util.List;

import id.co.astralife.app.report.dm.entity.AutoRenewal;
import id.co.astralife.app.report.model.AutoRenewalRequest;
import id.co.astralife.app.report.model.EmailEntity.AttachmentDetail;

public interface AutoRenewalService {
	
	void processBillAutoRenewal(AutoRenewalRequest renewReq);
	
	void generateBillAutoRenewal(AutoRenewalRequest renewReq);
	
	void generatePropAutoRenewal(AutoRenewalRequest renewReq);
	
	AttachmentDetail generateProposalReport(AutoRenewal propAutoRenewal, String user, String policyNo, String reprint);
	
	AttachmentDetail generateMemberListReport(AutoRenewal propAutoRenewal, String user, String policyNo);
	
	void emailPropAutoRenewal(AutoRenewal propAutoRenewal, List<AttachmentDetail> attachmentDetails, String user);

	List<AutoRenewal> generateListRenewals(AutoRenewalRequest renewReq);
}
