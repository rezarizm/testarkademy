package id.co.astralife.app.report.finance.service.impl;

import id.co.astralife.app.report.common.FinanceConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.finance.service.StatementOfAccountService;
import id.co.astralife.app.report.local.entity.Report;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author fadil.wiranata
 */
@Service
public class StatementOfAccountServiceImpl implements StatementOfAccountService {

    @Autowired
    ReportGenerator reportGenerator;

    @Autowired
    ReportService reportService;

    public void generateSummary(UUID reportId, String user) {
        generateSummary(reportId, user, ReportConstant.CUR_IDR);
        generateSummary(reportId, user, ReportConstant.CUR_USD);
    }

    public void generateSummary(UUID reportId, String user, String currency) {
        Report report = reportService.findByReportId(reportId);
        Map<String, Object> params = new HashMap<>();
        params.put(FinanceConstant.PARAM_CURRENCY, currency);
        // Defensive
        if (report != null) {
            reportGenerator.generate(report.getReportId(), user, params);
        }
    }

    public void generateDetail(UUID reportId, String user) {
        generateDetail(reportId, user, ReportConstant.CUR_IDR);
        generateDetail(reportId, user, ReportConstant.CUR_USD);
    }

    public void generateDetail(UUID reportId, String user, String currency) {
        generateDetail(reportId, user, currency, ReportConstant.SRC_BR);
        generateDetail(reportId, user, currency, ReportConstant.SRC_DI);
        generateDetail(reportId, user, currency, ReportConstant.SRC_IA);
    }

    public void generateDetail(UUID reportId, String user, String currency, String srcCode) {
        Report report = reportService.findByReportId(reportId);
        Map<String, Object> params = new HashMap<>();
        params.put(FinanceConstant.PARAM_CURRENCY, currency);
        params.put(FinanceConstant.PARAM_SOURCE, srcCode);
        if (report != null) {
            reportGenerator.generate(report.getReportId(), user, params);
        }
    }

	@Override
	public void generateProduction(UUID reportId, String user, String startDate, String endDate) {
		generateProduction(reportId, user, startDate, endDate, ReportConstant.CUR_IDR);
		generateProduction(reportId, user, startDate, endDate, ReportConstant.CUR_USD);
	}
	
	@Override
	public void generateProduction(UUID reportId, String user, String startDate, String endDate, String currency) {
		generateProduction (reportId, user, startDate, endDate, currency, ReportConstant.STCB_DIR );
		generateProduction (reportId, user, startDate, endDate, currency, ReportConstant.STCB_AGT );
		generateProduction (reportId, user, startDate, endDate, currency, ReportConstant.STCB_BRO );
		generateProduction (reportId, user, startDate, endDate, currency, ReportConstant.STCB_IAG );
	}

	@Override
	public void generateProduction(UUID reportId, String user, String startDate, String endDate, String currency, String stcb) {
		Report report = reportService.findByReportId(reportId);
    	Map<String, Object> params =  new HashMap<>();
    	params.put(FinanceConstant.PARAM_START_DATE, startDate);
    	params.put(FinanceConstant.PARAM_END_DATE, endDate);
    	params.put(FinanceConstant.PARAM_CURRENCY, currency);
    	params.put(FinanceConstant.PARAM_STCB, stcb);
    	params.put(FinanceConstant.PARAM_YEARS, "");
    	params.put(FinanceConstant.PARAM_START_MONTH, "");
    	params.put(FinanceConstant.PARAM_END_MONTH, "");
    	if (report!=null){
    		reportGenerator.generate(report.getReportId(), user, params);
    	}
	}

	@Override
	public void generateProductionPdf (UUID reportId, String user, String month, String years) {
		Report report = reportService.findByReportId(reportId);
    	Map<String, Object> params =  new HashMap<>();
    	params.put(FinanceConstant.PARAM_MONTH, month);
    	params.put(FinanceConstant.PARAM_YEARS, years);    	
    	if (report!=null){
    		reportGenerator.generate(report.getReportId(), user, params);
    	}		
	}
}
