package id.co.astralife.app.report.actuary.service;

import java.util.UUID;

public interface PersistencyService {

	void generatePersistency(UUID reportId, String user);
}
