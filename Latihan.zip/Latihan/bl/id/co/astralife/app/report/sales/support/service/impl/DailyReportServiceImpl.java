package id.co.astralife.app.report.sales.support.service.impl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.CryptoConstant;
import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.common.util.EmailUtil;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.email.service.EmailService;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.local.repository.ConfigRepository;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.DailyReportService;

@Service
public class DailyReportServiceImpl implements DailyReportService {

	public static final Logger LOGGER = LoggerFactory.getLogger(DailyReportServiceImpl.class);

	@Autowired
	private ReportService reportService;

	@Autowired
	private ReportGenerator reportGenerator;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private ConfigRepository configRepository;
	
	@Autowired
	Environment env;
	
	@Override
	public void generateDailyReport(UUID rptId, String user, String genDate, String fileName) {
		Report report = reportService.findByReportId(rptId);
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
		
		if (report != null) {
			List<Config> configs = configRepository.findData(SalesSupportConstant.DAILY_REPORT_EMAIL);
			String toIds = EmailUtil.buildIdsFromConfig(configs);
			
			/*params.put(EmailConstant.EMAIL, true);
			params.put(EmailConstant.PARAM_YGEMAIL, EmailConstant.EMAIL);
			params.put(EmailConstant.PARAM_EMAIL_FROM, EmailConstant.EMAIL_SENDER_NO_REPLY);
			params.put(EmailConstant.PARAM_TO_ID, toIds);
			params.put(EmailConstant.PARAM_SUBJECT, 
					emailService.render(EmailConstant.SUBJECT_DAILY_MI, this.getSubjectDate()));
			params.put(EmailConstant.PARAM_CONTENT, 
					emailService.render(EmailConstant.CONTENT_DAILY_MI, this.getSubjectDate()));
			params.put(EmailConstant.PARAM_ATTACH_NAME, "");
			params.put(EmailConstant.PARAM_FILEPATH, "");
			
			params.put(CryptoConstant.PGP_ENCRYPT, true);*/
			
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			reportGenerator.generate(report.getReportId(), user, params);
		}
	}
	
	private Map<String, String> getSubjectDate() {
		SimpleDateFormat sdfSubject = new SimpleDateFormat("dd MMMMM yyyy");
		Date date = new Date();
		String dayMonthYear = sdfSubject.format(date);
		Map<String, String> params = new HashMap<>();
		params.put(EmailConstant.DAILY_MI_DAY_MONTH_YEAR, dayMonthYear);
		return params;
	}
}
