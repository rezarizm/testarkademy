package id.co.astralife.app.report.sales.support.service;

import java.util.UUID;

public interface BankRewardService {

	void generateBankReward(UUID reportId, String user, String fileName, String dateParam);
}
