package id.co.astralife.app.report.operation.service;

import java.util.Map;
import java.util.UUID;

public interface SmePolicyService {

	void generateSmePolicy(UUID reportId, String user, String startDate, String endDate);
	
	void generateSmePolicy(UUID reportId, String user, String policyNo, Map<String, Object> params);
}
