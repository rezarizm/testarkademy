package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface GroupPolicyService {

	void generateGroupPolicy(UUID reportId, String user, String startDate, String endDate);
	
}
