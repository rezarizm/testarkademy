package id.co.astralife.app.report.sales.support.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.SalesSupportConstant;
import id.co.astralife.app.report.core.ReportGenerator;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.report.service.ReportService;
import id.co.astralife.app.report.sales.support.service.MonthlyCommissionIsaveService;

@Service
public class MonthlyCommissionIsaveServiceImpl implements MonthlyCommissionIsaveService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MonthlyCommissionIsaveServiceImpl.class);
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private ReportGenerator reportGenerator;
	
	@Autowired
	Environment env;
	
	@Override
	public void generateMonthlyIsave(UUID rptId, String user, String fileName, String startDate, String endDate) {
		SimpleDateFormat sdfParam = new SimpleDateFormat("yyyyMMddHHmmss");
		
		Date fromParam = null;
		Date toParam = null;
		try {
			fromParam = sdfParam.parse(startDate + "000000");
			toParam = sdfParam.parse(endDate + "235959");
		} catch (ParseException e) {
			LOGGER.error("ParseException" + e.getMessage());
		}
		
		String startDateParam = sdfParam.format(fromParam);
		String endDateParam = sdfParam.format(toParam);
		
		Report report = reportService.findByReportId(rptId);
		Map<String, Object> params = new HashMap<>();
		params.put(ReportConstant.DATASOURCE, ReportConstant.DATASOURCE_IPLUS);
		params.put(SalesSupportConstant.PARAM_START_DATE, startDateParam);
		params.put(SalesSupportConstant.PARAM_END_DATE, endDateParam);
		
		if (report != null) {
			params.put(ReportConstant.FILENAME_PARAM, fileName);
			reportGenerator.generate(report.getReportId(), user, params);
		}
	}
}
