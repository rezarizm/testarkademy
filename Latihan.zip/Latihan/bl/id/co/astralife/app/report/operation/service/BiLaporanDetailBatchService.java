package id.co.astralife.app.report.operation.service;

import java.util.UUID;

/**
 * 
 * @author Michael
 *
 * @Since 7 Des 2017
 */
public interface BiLaporanDetailBatchService {

	void generateBiLaporanDetail(UUID reportId, String user, String biType);
	
}
