package id.co.astralife.app.report.schedule.job;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

import id.co.astralife.app.report.common.OperationConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.local.entity.Report;
import id.co.astralife.app.report.operation.service.CancelPolisService;
import id.co.astralife.app.report.operation.service.ProposalPolisService;
import id.co.astralife.app.report.report.service.ReportService;

public class IplusNtuJob extends QuartzJobBean {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(IplusNtuJob.class);
	private static final String SYSTEM = "SYSTEM";
	
	@Autowired
	private ReportService reportService;
	
	@Autowired
	private ProposalPolisService proposalPolisService;
	
	@Autowired
	private CancelPolisService cancelPolisService;
	
	@Override
	protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
		LOGGER.info("----------START IPLUS NTU POLIS Job----------");
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		
		Calendar calendar = Calendar.getInstance();
		String endDate = dateFormat.format(calendar.getTime());
		
		Calendar calendar1 = Calendar.getInstance();
		calendar1.add(Calendar.DATE, -1);
		String endDate1 = dateFormat.format(calendar1.getTime());
		
		Calendar calendar2 = Calendar.getInstance();
		calendar2.add(Calendar.DATE, -2);
		
		String startDate;
		String startDate1;
		
		if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {
			startDate = dateFormat.format(calendar1.getTime());
			startDate1 = dateFormat.format(calendar2.getTime());
		} else {
			startDate = endDate;
			startDate1 = endDate1;
		}
		
		List<Report> reports = reportService.findBySchedule(ReportConstant.DAILY);
		for (Report rpt : reports) {
			if (rpt.getTemplate().equals(OperationConstant.PROPOSAL_POLIS)){
				proposalPolisService.generateProposalPolis(rpt.getReportId(), SYSTEM, endDate);
			} else if (rpt.getTemplate().equals(OperationConstant.CANCEL_POLIS)) {
				cancelPolisService.generateCancelPolis(rpt.getReportId(), SYSTEM, startDate, endDate, startDate1, endDate1);
			}
		}
		
		LOGGER.info("----------END IPLUS NTU POLIS Job----------");
	}
}