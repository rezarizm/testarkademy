package id.co.astralife.app.report.geocode.impl;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import id.co.astralife.app.report.common.OjkConstant;
import id.co.astralife.app.report.geocode.GeoCodeService;
import id.co.astralife.app.report.model.GeoCode;

@Service
public class GeoCodeServiceImpl implements GeoCodeService {

	private static final Logger LOGGER = LoggerFactory.getLogger(GeoCodeServiceImpl.class);
	
	@Override
	public GeoCode runGeoCodeConvAddr(Map<String, String> uriVar) {

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<GeoCode> response = null;
		GeoCode geoCode = null;

		String url = "http://maps.googleapis.com/maps/api/geocode/json?address={address}&language=id&region=ID";

		LOGGER.info("ID {}, Request: http://maps.googleapis.com/maps/api/geocode/json?address={}&language=id&region=ID",
				uriVar.get(OjkConstant.ID), uriVar.get(OjkConstant.ADDRESS_URIVAR));
		try {
			Thread.sleep(1000L);
			response = restTemplate.postForEntity(url, null, GeoCode.class, uriVar);
			geoCode = response.getBody();
			LOGGER.info("ID {}, Response Body: {}", uriVar.get(OjkConstant.ID), geoCode);
		} catch (RestClientException e) {
			LOGGER.error("RestClientException: runGeoCodeConvAddr: " + e.getMessage(), e);
			LOGGER.error("Response: runGeoCodeConvAddr: {}", new ResponseEntity<>("ERROR", HttpStatus.BAD_REQUEST));
			return null;
		} catch (Exception e) {
			LOGGER.error("Exception: runGeoCodeConvAddr: " + e.getMessage(), e);
			return null;
		}
		return geoCode;
	}

}
