package id.co.astralife.app.report.operation.service;

import java.util.UUID;

public interface BiReportService {

	void generateBiReport(UUID reportId, String user, String month, String yearMonth);
}
