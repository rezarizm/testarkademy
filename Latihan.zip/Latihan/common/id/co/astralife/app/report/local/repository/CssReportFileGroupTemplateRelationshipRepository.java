package id.co.astralife.app.report.local.repository;


import id.co.astralife.app.report.local.entity.CssReportFileGroupTemplateRelationship;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface CssReportFileGroupTemplateRelationshipRepository extends JpaRepository<CssReportFileGroupTemplateRelationship, UUID>{
    List<CssReportFileGroupTemplateRelationship> findTemplateRelationByCssTemplateId(String cssTemplateId);
}
