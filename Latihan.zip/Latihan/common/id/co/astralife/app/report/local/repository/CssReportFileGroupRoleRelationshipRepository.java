package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssReportFileGroupRoleRelationship;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface CssReportFileGroupRoleRelationshipRepository extends JpaRepository<CssReportFileGroupRoleRelationship, UUID> {
    List<CssReportFileGroupRoleRelationship> findRolesByCssFileGroupId(String cssFileGroupId);
}
