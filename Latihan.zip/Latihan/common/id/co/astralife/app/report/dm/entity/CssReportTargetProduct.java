package id.co.astralife.app.report.dm.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@Entity
@Table(name = "CSS_TARGET_PRODUCT")
public class CssReportTargetProduct implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PRODUCT")
    private String product;

    @Column(name = "MONTH")
    private Integer month;

    @Column(name = "YEAR")
    private Integer year;

    @Column(name = "APE")
    private Integer ape;
}
