package id.co.astralife.app.report.local.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.AttachDetail;

public interface AttachDetailRepository extends JpaRepository<AttachDetail, UUID> {

	List<AttachDetail> findByEmailId(UUID emailId);
	
}
