package id.co.astralife.app.report.local.repository;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.Email;

public interface EmailRepository extends JpaRepository<Email, UUID>{

	Email findByEmailId (UUID emailId);
	
	List<Email> findByStatusAndYgEmail(String status, String ygEmail);
	
	Email findFirstByAttachName(String attachName);
	
	Email findFirstBySubjectAndCreateDateBetween(String subject, Date from, Date to);
	
	
	List<Email> findByEmailIdIn(Set<UUID> emailIds);
	
	List<Email> findByCreateDateBetween(Date startDate, Date endDate);
	
	List<Email> findByFromIdInAndCreateDateBetween(Set<String> fromIds, Date startDate, Date endDate);
	
	List<Email> findByReportIdInAndCreateDateBetween(Set<UUID> rptIds, Date startDate, Date endDate);
}
