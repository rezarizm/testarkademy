package id.co.astralife.app.report.dm.repository;

import id.co.astralife.app.report.dm.entity.CssReportNonRider;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CssReportNonRiderRepository extends JpaRepository<CssReportNonRider, String> {
}
