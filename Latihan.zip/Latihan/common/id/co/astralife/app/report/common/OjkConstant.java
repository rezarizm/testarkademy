package id.co.astralife.app.report.common;

public class OjkConstant {
	
	public static final String OJK_REPORT_TEMP = "AutomateOjkReport";
	public static final String OJK_UNCOMP_NO_TEMP = "UncompleteOjkNoTemplate";
	
	// Sheet Name Summary 
	public static final String PREMI = "PREMI";
	public static final String CLAIM = "CLAIM";
	
	// Sheet/Category (of 6) <see rpt_config with config name = 'OJK_SHEET_NAME'>
	public static final String CLAIM_HEALTH = "claim health";
	public static final String CLAIM_LIFE = "claim life";
	public static final String CLAIM_UL = "claim ul";
	public static final String PREMI_HEALTH = "premi health";
	public static final String PREMI_LIFE = "premi life";
	public static final String PREMI_UL = "premi ul";

	// Header Name OjkData
	public static final String ACC_CODE = "account code";
	public static final String BASE_AMT = "base amount";
	public static final String JOURNAL_TYPE = "journal type";
	public static final String TRANS_REF = "transaction reference";

	// Header Name OjkMaster
	public static final String MASTER_POL_NO = "policy number";
	public static final String MASTER_AREA_CODE = "area code";
	public static final String MASTER_JOURNAL_TYPE = "journal type";
	public static final String MASTER_CITY = "city";
	public static final String MASTER_PROV = "province";

	// Config List (ConfigName)
	public static final String OJK_SHEET_NAME = "OJK_SHEET_NAME";
	public static final String OJK_ROW_HEADER = "OJK_ROW_HEADER";
	public static final String OJK_JT_NOT_DEFAULT = "OJK_JT_NOT_DEFAULT";
	public static final String OJK_EMAIL_TO = "OJK_EMAIL_TO";
	public static final String OJK_MASTER_EMAIL_TO = "OJK_MASTER_EMAIL_TO";
	public static final String OJK_MASTER_EMAIL_CC = "OJK_MASTER_EMAIL_CC";
	public static final String OJK_GEOCODE_SHEET = "OJK_GEOCODE_SHEET";
	public static final String OJK_GEOCODE_CURRENT_MONTH = "OJK_GEOCODE_CURRENT_MONTH";
	public static final String OJK_GEOCODE_SHEET_SUM_RUNNED = "OJK_GEOCODE_SHEET_SUM_RUNNED";
	public static final String OJK_GEOCODE_SHEET_RUNNING_PER_DAY = "OJK_GEOCODE_SHEET_RUNNING_PER_DAY";
	public static final String OJK_GEOCODE_AVAILABLE_DAY = "OJK_GEOCODE_AVAILABLE_DAY";
	
	public static final String JAKSEL_AREA_CODE = "3174";
	
	public static final String OJK_GEOCODE_SHEET_DAY_COUNT = "OJK_GEOCODE_SHEET_DAY_COUNT";
	
	// ojk geo code break time
	public static final String OJK_GEOCODE_BREAK_TIME = "OJK_GEOCODE_BREAK_TIME";
	
	// Journal Type Constant
	public static final String JT_ASLI = "ASLI";
	public static final String JT_LIFE = "LIFE";
	public static final String JT_GASIA = "GASIA";
	
	// Source Of Address
	public static final String SOA_AREA_JASKEL = "DEFAULT AREA_CODE " + JAKSEL_AREA_CODE;
	public static final String SOA_OJK_MASTER = "OJK_MASTER";
	public static final String SOA_ID_NO = "AREA_CODE WITH ID_NO ";
	public static final String SOA_GEO_CODE = "GEO_CODE";

	// address map
	public static final String ADDRESS_URIVAR = "address";
	public static final String ADDR_01 = "address01";
	public static final String ADDR_02 = "address02";
	public static final String ADDR_03 = "address03";
	
	// params
	public static final String PARAM_CAT_PREMI = "cat_premi";
	public static final String PARAM_CAT_CLAIM = "cat_claim";
	
	// ojk master file name
	public static final String UNCOMP_ALL_FILE_NAME = "Uncomplete_All_Data_OJK";
	public static final String UNCOMP_FILE_NAME = "Uncomplete_OJK";
	
	// ?1 = trans_ref
	public static final String GROUP_OJK_POLNO_QUERY = " with rtrn as (  " +
			" select rdocnum,  " +
			" substr(rldgacct, 1, 8) clamnum,  " +
			" substr(rldgacct, 10, 2) gcoccno  " +
			" from odsdta.gartrnpf  " +
			" where rldgpfx ='GC'  " +
			" and rdocpfx ='RQ'  " +
			" and trim(rdocnum) = ?1  " +
			" and length(rldgacct) >= 11  " +
			" and sacscode = 'GC'  " +
			" order by trandate desc  " +
			" ),  " +
			" rtrn_last as (  " +
			" select distinct gclh.chdrnum from rtrn  " +
			" inner join odsdta.gagclhpf gclh on trim(rtrn.clamnum) = trim(gclh.clamnum)  " +
			                        " and trim(rtrn.gcoccno) = trim(gclh.gcoccno)  " +
			" )  " +
			" select * from rtrn_last  " +
			" where rownum <= 1  ";
	
	public static final String CLIENT_TAB_NAME = "with client as ";
	
	public static final String VALID_CLIENT_QUERY = " valid_client as (select " +
            "  policy_no, " +
            "  id_no,  " +
            "  dob, " +
            "  case when trim(policy_no) is not null and trim(id_no) is not null " +
            "       then case when substr(id_no,9,4) = substr(dob,3,4) " +
            "                 then case when substr(id_no,7,2) > 40  " +
            "                           then case when (substr(id_no,7,2)-40)||substr(id_no,9,4) = dob then 1 else 0 end " +
            "                           else case when substr(id_no,7,6) = dob then 1 else 0 end " +
            "                      end " +
            "                 else 0 " +
            "            end " +
            "       else 0 " +
            "  end is_valid, " +
            "  decode(address01,null,' ',address01) address01, " +
            "  decode(address02,null,' ',address02) address02, " +
            "  decode(address03,null,' ',address03) address03 " +
            "  from client  " +
            "  where rownum <= 1 " +
            "  )  " +
            "  select * from valid_client ";
	
	public static final String VALID_PARAM_QUERY = " where is_valid = ?2 ";
	
	public static final String ASLI_GET_CLIENT_QUERY = " with ip_client as ( " +
			" select  " +
			" cl.pk_party, " +
			" pid.id_number client_id_number, " +
			" cl.date_of_birth, " +
			" pa.kecamatan, " +
			" pa.kabupaten_kota kabupaten, " +
			" pa.province, " +
			" cin.name cin_name, " +
			" cl.valid " +
			" from (select a.pk_party, b.date_of_birth, a.valid " +
			"       from odsdta.ipparty a inner join odsdta.ipperson b on a.pk_party = b.pk_person " +
			"       union all " +
			"       select a.pk_party, null as date_of_birth, a.valid " +
			"       from odsdta.ipparty a inner join odsdta.ipcompany c on a.pk_party = c.pk_company " +
			"         ) cl " +
			" left join odsdta.ipparty_address pa on pa.fk_party = cl.pk_party and pa.valid = 1 " +
			" left join odsdta.ipparty_id pid on cl.pk_party = pid.fk_party and pid.valid = 1 " +
			" left join odsdta.iplookup cin on pid.fk_reference = cin.pk_lookup " +
			" ), " +
			" client as  (   " +
			" select   " +
			" contract.contract_no policy_no,   " +
			" ip_client.client_id_number id_no,   " +
			" to_char(ip_client.date_of_birth, 'DDMMYY') dob,   " +
			" ip_client.kecamatan address01,   " +
			" ip_client.kabupaten address02,   " +
			" ip_client.province address03   " +
			" from   " +
			" (select * from odsdta.ipcontract   " +
			" where contract_no = ?1   " +
			" ) contract   " +
			" inner join ip_client on contract.fk_party_owner = ip_client.pk_party   " +
			"                       and ip_client.valid = 1   " +
			"                       and ip_client.cin_name = 'KTP'   " +
			" ),  ";
	
	// ?1 = policy_no, ?2 = is_valid
	public static final String ASLI_OJK_CLIENT_QUERY = ASLI_GET_CLIENT_QUERY + VALID_CLIENT_QUERY + VALID_PARAM_QUERY;
	
	// ?1 = policy_no 
	public static final String ASLI_OJK_CLIENT_QUERY_BY_POLNO = ASLI_GET_CLIENT_QUERY + VALID_CLIENT_QUERY;
	
	public static final String GROUP_GET_CLIENT_QUERY = CLIENT_TAB_NAME + " ( " +
			" select  " +
			" policy_no,  " +
			" id_no,  " +
			" dob,  " +
			" cltaddr02 address01, " +
			" cltaddr03 address02, " +
			" cltaddr04||' '||cltaddr05 address03  " +
			" from (select  " +
			"       chdr.chdrnum policy_no,  " +
			"       trim(clnt.secuityno) id_no,  " +
			"       regexp_replace(trim(cltdob),'([[:digit:]]{2})([[:digit:]]{2})([[:digit:]]{2})([[:digit:]]{2})','\\4\\3\\2') dob,  " +
			"       case when lower(clnt.cltaddr02) like '%up%' then ' ' " +
			"           when lower(clnt.cltaddr02) like '%attn%' then ' ' " +
			"           when lower(clnt.cltaddr02) like '%ibu%' then ' ' " +
			"           when lower(clnt.cltaddr02) like '%bapak%' then ' ' " +
			"           else clnt.cltaddr02 " +
			"       end cltaddr02, " +
			"       case when lower(clnt.cltaddr03) like '%up%' then ' ' " +
			"           when lower(clnt.cltaddr03) like '%attn%' then ' ' " +
			"           when lower(clnt.cltaddr03) like '%ibu%' then ' ' " +
			"           when lower(clnt.cltaddr03) like '%bapak%' then ' ' " +
			"           else clnt.cltaddr03 " +
			"       end cltaddr03, " +
			"       case when lower(clnt.cltaddr04) like '%up%' then ' ' " +
			"           when lower(clnt.cltaddr04) like '%attn%' then ' ' " +
			"           when lower(clnt.cltaddr04) like '%ibu%' then ' ' " +
			"           when lower(clnt.cltaddr04) like '%bapak%' then ' ' " +
			"           else clnt.cltaddr04 " +
			"       end cltaddr04, " +
			"       case when lower(clnt.cltaddr05) like '%up%' then ' ' " +
			"           when lower(clnt.cltaddr05) like '%attn%' then ' ' " +
			"           when lower(clnt.cltaddr05) like '%ibu%' then ' ' " +
			"           when lower(clnt.cltaddr05) like '%bapak%' then ' ' " +
			"           else clnt.cltaddr05 " +
			"       end cltaddr05  " +
			"       from  " +
			"        (select * from odsdta.gachdrpf  " +
			"         where chdrnum = ?1  " +
			"        ) chdr  " +
			"        inner join odsdta.gaclntpf clnt on trim(chdr.cownnum) = trim(clnt.clntnum)  " +
			" ) " +
			" ), ";
	
	// ?1 = policy_no, ?2 = is_valid
	public static final String GROUP_OJK_CLIENT_QUERY = GROUP_GET_CLIENT_QUERY  + VALID_CLIENT_QUERY + VALID_PARAM_QUERY;
	
	// ?1 = policy_no 
	public static final String GROUP_OJK_CLIENT_QUERY_BY_POLNO = GROUP_GET_CLIENT_QUERY + VALID_CLIENT_QUERY;
	
	public static final String LIFE_GET_CLIENT_QUERY = CLIENT_TAB_NAME + " ( " +
			"   select " +
			"   chdr.chdrnum policy_no, " +
			"   trim(clnt.secuityno) id_no, " +
			"   regexp_replace(trim(cltdob),'([[:digit:]]{2})([[:digit:]]{2})([[:digit:]]{2})([[:digit:]]{2})','\\4\\3\\2') dob, " +
			"   clnt.cltaddr02 address01, " +
			"   clnt.cltaddr03 address02,  " +
			"   clnt.cltaddr04 address03 " +
			"   from " +
			"     (select * from odsdta.lfchdrpf " +
			"     where chdrnum = ?1 " +
			"     ) chdr " +
			"     inner join odsdta.lfclntpf clnt on trim(chdr.cownnum) = trim(clnt.clntnum) " +
			" ), "; 
	
	// ?1 = policy_no, ?2 = is_valid
	public static final String LIFE_OJK_CLIENT_QUERY = LIFE_GET_CLIENT_QUERY + VALID_CLIENT_QUERY + VALID_PARAM_QUERY;
	
	// ?1 = policy_no 
	public static final String LIFE_OJK_CLIENT_QUERY_BY_POLNO = LIFE_GET_CLIENT_QUERY + VALID_CLIENT_QUERY;
		
	public static final String OJK_GEOCODE_SHEET_DAY_COUNT_QUERY = "select " +
			" config_id, " +
			" config_name, " +
			" config_value from( " +
			"   select rownum num, " +
			"   config_id, " +
			"   config_name, " +
			"   config_value from ( " +
			"     select * from rpt_config " + 
			"     where config_name = ?1 " +
			"     order by config_value desc " + 
			"     ) " +
			"   ) ";
	
	public static final String OJK_GEOCODE_NEXT_SHEET_DAY_COUNT_QUERY = OJK_GEOCODE_SHEET_DAY_COUNT_QUERY + " where num > ?2 ";
	public static final String OJK_GEOCODE_CURRENT_SHEET_DAY_COUNT_BETWEEN_QUERY = OJK_GEOCODE_SHEET_DAY_COUNT_QUERY
			+ " where num between ?2 and ?3 ";
	
	public static final String OJK_SOURCE = "OJK_SOURCE";
	public static final String OJK_MASTER = "OJK_MASTER";
	public static final String OJK_AREA = "OJK_AREA";
	
	public static final String FREQUENCY = "freq";
	public static final String QUARTERLY = "QRTRLY";
	public static final String YEARLY = "YEARY";
	
	public static final String GNL = "GNL";
	
	public static final String ID = "ID";
	
	private OjkConstant() {
		throw new IllegalAccessError("Ojk Constant Class");
	}
}
