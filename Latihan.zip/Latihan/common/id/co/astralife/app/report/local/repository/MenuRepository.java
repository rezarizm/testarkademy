package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.Menu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * @author fadil.wiranata
 */
public interface MenuRepository extends JpaRepository<Menu, UUID> {

    List<Menu> findByParentIdIsNullOrderBySequenceAsc();

    Set<Menu> findByIdIn(Set<UUID> menuIds);

    @Query(nativeQuery=true)
    List<Menu> findByUserId(UUID userId);
}
