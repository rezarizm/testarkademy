package id.co.astralife.app.report.model;

import java.util.List;

import lombok.Data;

@Data
public class GeoCode {
	
	@Data
	public static class Result {
		private List<AddressComponent> address_components;
	}
	
	@Data
	public static class AddressComponent {
		private String long_name;
		private String short_name;
		private List<String> types;
	}

	private List<Result> results;
	private String status;
	
}
