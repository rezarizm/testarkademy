package id.co.astralife.app.report.eb.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.eb.entity.ExportFile;

public interface ExportFileRepository extends JpaRepository<ExportFile, Long> {

}
