package id.co.astralife.app.report.dm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.dm.entity.GroupOjkPolNo;

public interface GroupOjkPolNoRepository extends JpaRepository<GroupOjkPolNo, String> {

	@Query(nativeQuery = true)
	GroupOjkPolNo findPolicyNoByTransRef(String transRef);

}
