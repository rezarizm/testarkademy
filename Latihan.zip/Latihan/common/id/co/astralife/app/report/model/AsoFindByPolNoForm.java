package id.co.astralife.app.report.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AsoFindByPolNoForm {
  
    @JsonProperty("policyNumber")
    private String policyNumber;
}
