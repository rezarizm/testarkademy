package id.co.astralife.app.report.local.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.UUID;

@Entity
@Data
@Table(name = "CSS_REPORT_GROUP_TEMPLATE_REL")
public class CssReportFileGroupTemplateRelationship implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "ID_REL", nullable = false)
    private UUID idRel;

    @Column(name = "FILE_GROUP_ID", nullable = false)
    private String cssFileGroupId;

    @Column(name = "TEMPLATE_ID", nullable = false)
    private String cssTemplateId;
}
