package id.co.astralife.app.report.common;

public class AutoRenewalConstant {

	public static final String PROP_AUTO_RENEWAL= "ProposalAutoRenewal";
	public static final String BILL_AUTO_RENEWAL = "BillingAutoRenewal";
	public static final String LIST_MBR_AUTO_RENEWAL = "ListMemberAutoRenewal";
	
	public static final String START_POLICY_PERIOD = "START_POLICY_PERIOD";
	public static final String END_POLICY_PERIOD = "END_POLICY_PERIOD";
	
	public static final String SUBJECT_RENEWAL = "Billing Renewal Automation ";
	
	/**
	 *
	 * @param START_DATE <yyyyMMdd>
	 * @param END_DATE <yyyyMMdd>
	 */
	public static final String QUERY_BILL_AUTO_RENEWAL = "SELECT POLICY_NO, POLICY_HOLDER, '' CONTRACT_TYPE, '' CURR_CODE, '' BILLING_CURRENCY, '' EMAIL_TO, START_DATE, EXPIRY_DATE, EXCLUDE, '' EXCLUDE_POLICY, '' CHANNEL, '' SOB FROM TABLE(PKG_AUTO_RENEWAL.GET_LIST_BILL(?1, ?2))";
	
	/**
	 * @param POLICY_NO
	 */
	public static final String QUERY_PROPOSAL_RENEWAL = "SELECT POLICY_NO, POLICY_HOLDER, CONTRACT_TYPE, CURR_CODE, BILLING_CURRENCY, EMAIL_TO, START_DATE, EXPIRY_DATE, EXCLUDE, EXCLUDE_POLICY, CHANNEL, SOB FROM TABLE(PKG_AUTO_RENEWAL.GET_PROP_POLICY(?1))";
	
	/**
	 * @param POLICY_NO
	 */
	public static final String QUERY_COUNT_PROPOSAL_RENEWAL = "SELECT POLICY_NO, '' POLICY_HOLDER, CONTRACT_TYPE, CURR_CODE, '' BILLING_CURRENCY, '' EMAIL_TO, '' START_DATE, '' EXPIRY_DATE, EXCLUDE, EXCLUDE_POLICY, '' CHANNEL, '' SOB FROM TABLE(PKG_AUTO_RENEWAL.GET_VALIDATE_POLICY(?1))";
	
	/**
	 * @param POLICY_NO
	 */
	public static final String QUERY_GET_CURRENCY = "SELECT POLICY_NO, '' POLICY_HOLDER, '' CONTRACT_TYPE, CURR_CODE, BILLING_CURRENCY, '' EMAIL_TO, '' START_DATE, '' EXPIRY_DATE, '' EXCLUDE, '' EXCLUDE_POLICY, '' CHANNEL, '' SOB FROM TABLE(PKG_AUTO_RENEWAL.GET_CURRENCY(?1))";
	
	
	public static final String QUERY_EMAIL_CC = "SELECT * FROM TABLE(PKG_AUTO_RENEWAL.GET_EMAIL_CC(?1))";

	public static final String QUERY_GET_CNT_TYPE = "select contract_type from table(PKG_AUTO_RENEWAL.GET_CONTRACT_TYPE)";
	
	private AutoRenewalConstant () {
		throw new IllegalAccessError("AutoRenewalConstant Class");
	}
}
