package id.co.astralife.app.report.local.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class CssReportFileGroupTemplateId implements Serializable{

	private static final long serialVersionUID = 1L;

	private String cssFileGroupId;

    private String cssTemplateId;
}
