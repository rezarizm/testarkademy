package id.co.astralife.app.report.model;

import java.util.List;
import java.util.UUID;

import lombok.Data;

@Data
public class UserForm {

	private UUID userId;
	
	private List<UUID> roleId;
	
	private String loginId;
	
	private String status;
	
}
