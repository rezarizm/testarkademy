package id.co.astralife.app.report.local.entity;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Entity
@Data
/*@NamedNativeQueries(
        @NamedNativeQuery(
                name = "ReportFile.findByUserName", 
                query = ReportConstant.REPORT_FILE_QUERY, 
                resultClass = ReportFile.class
        )
)*/
@Table(name = "RPT_REPORT_FILE")
public class ReportFile extends BaseEntity {

    private static final long serialVersionUID = 7382782406331789766L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "FILE_ID", nullable = false)
    private UUID id;

    @Column(name="RPT_ID")
    private UUID rptId;
    
    @ManyToOne
    @JoinColumn(name = "RPT_ID", insertable= false, updatable=false)
    private Report report;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "FOLDER_PATH")
    private String folderPath;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "CREATE_BY")
    private String createBy;

    @Column(name = "IS_VISIBLE")
    private boolean isVisible;
    
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;
}
