package id.co.astralife.app.report.common.util;

import id.co.astralife.app.report.common.util.exception.CryptoServiceException;

import java.io.File;

public interface CryptoService {
    byte[] encrypt(byte[] plainText, String publicKey) throws CryptoServiceException;

    void encrypt(File plainFile, File chiperFileDestination, String publicKey) throws CryptoServiceException;

    byte[] decrypt(byte[] chiperText, String privateKeyString, String passPhrase) throws CryptoServiceException;

    void decrypt(File chiperFile, File plainFileDestination, String privateKey, String passPhrase) throws CryptoServiceException;
}
