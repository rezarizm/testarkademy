package id.co.astralife.app.report.model;

import java.math.BigDecimal;
import java.util.UUID;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AsoSetupDTO {

    @JsonProperty("thId")
    private UUID id;

    @JsonProperty("policyNo")
    private String policyNo;

    @JsonProperty("threshold")
    private BigDecimal threshold;

    @JsonProperty("deposit")
    private BigDecimal deposit;

    @JsonProperty("createBy")
    private String createBy;

    @JsonProperty("createDate")
    private String createDate;
}
