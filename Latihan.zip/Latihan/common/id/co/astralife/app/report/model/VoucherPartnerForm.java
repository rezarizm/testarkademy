package id.co.astralife.app.report.model;

import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;
import lombok.Setter;

/**
 * POJO for upload voucher partner.
 *
 * @since 25 Apr 2017
 * @version 1.0
 * @author sayid.sidqi
 */
@Getter
@Setter
public class VoucherPartnerForm {
	private String agentCode;
	private MultipartFile voucherFile;
}
