package id.co.astralife.app.report.common;

/**
 * Provides constants for controller class.
 *
 * @author sayid.sidqi
 * @version 1.0
 * @since 7 Apr 2017
 */
public enum MessageSourceKey {
	
	UPLOAD_VOUCHER_PARTNER_TTL("upload.voucher.partner.ttl"),
	UPLOAD_VOUCHER_PARTNER_SUBTTL("upload.voucher.partner.subttl"),
	UPLOAD_VOUCHER_INTERN_TTL("upload.voucher.internal.ttl"),
	UPLOAD_VOUCHER_INTERN_SUBTTL("upload.voucher.internal.subttl"),
	UPLOAD_FILE_SUCCESS("upload.file.success"),
	UPLOAD_FILE_INVALID_EXTENSION("upload.file.invalid.extension"),
	UPLOAD_FILE_INVALID_FORMAT("upload.file.invalid.format"),
	UPLOAD_FILE_EMPTY("upload.file.empty"),
	UPLOAD_FILE_ERROR("upload.file.error"),
	FORM_FIELD_ERROR("form.field.error"),
	REPORT_GENGERATION_SUCCESS("report.generation.succes"),
	REPORT_GENERATION_ERROR("report.generation.error"),
	REPORT_GENERATION_TTL("report.generation.ttl"),
	REPORT_GENERATION_PERMATA_LOGIN_DETAIL_TTL("report.generation.aol.userlogin.ttl"),
	MAX_SIZE_EXCEEDED("max.file.size.exceeded");
	
	private String key;
	
	/**
	 * Instantiates a new controller constant.
	 *
	 * @param strVal the string value
	 */
	private MessageSourceKey(String key) {
		this.key = key;
	}
	
	/**
	 * Gets the string value of constant.
	 *
	 * @return its string value defined in this enum.
	 */
	public String getKey() {
		return key;
	}

}
