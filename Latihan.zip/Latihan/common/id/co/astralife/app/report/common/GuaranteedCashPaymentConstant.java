package id.co.astralife.app.report.common;

public class GuaranteedCashPaymentConstant {
	
	public static final String GUARANTEED_CASH_PAYMENT_DATA_COUNT = "select count(*) count_data from table(pkg_gcp_rpt.get_gcp(?1,?2))";
	public static final String GUARANTEED_CASH_PAYMENT_RPT_CONFIG = "GCP_Report_EMAIL";
	public static final String GUARANTEED_CASH_PAYMENT_RPT_TEMPLATE = "GuaranteedCashPaymentReport";
	public static final String GUARANTEED_CASH_PAYMENT_RPT_SUBJECT = "Daily Report Guarantee Cash Payment - ";
	public static final String GUARANTEED_CASH_PAYMENT_RPT_EMAIL_TEMPLATE= "guaranteedcashpaymentreport.html";
	 private  GuaranteedCashPaymentConstant() {
		    throw new IllegalStateException("Constant class");
		  }

}

