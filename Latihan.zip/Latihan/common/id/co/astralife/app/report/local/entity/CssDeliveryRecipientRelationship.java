package id.co.astralife.app.report.local.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.UUID;

@Data
@Entity
@Table(name = "CSS_DELIVERY_RECIPIENT_REL")
public class CssDeliveryRecipientRelationship implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "ID_REL", nullable = false)
    private UUID idRel;

    @Column(name = "RECIPIENT_ID", nullable = false)
    private UUID cssRecipientId;

    @Column(name = "DELIVERY_GROUP_ID", nullable = false)
    private String cssDeliveryGroupId;
}
