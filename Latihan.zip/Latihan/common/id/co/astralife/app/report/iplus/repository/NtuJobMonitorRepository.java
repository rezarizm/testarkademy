package id.co.astralife.app.report.iplus.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.iplus.entity.NtuJobMonitor;

public interface NtuJobMonitorRepository extends JpaRepository<NtuJobMonitor, Long>{

	NtuJobMonitor findFirstByEndTimeBetweenAndStatus(Date from, Date to, String status);
}
