package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.common.PasswordConstant;
import id.co.astralife.app.report.local.entity.CssExcelPassword;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.UUID;

public interface CssExcelPasswordRepository extends JpaRepository<CssExcelPassword, String> {

    @Query(nativeQuery = true, value = PasswordConstant.findExcelPasswordQuery)
    CssExcelPassword findPasswordByCssRecipientId(UUID cssRecipientId);

    CssExcelPassword findCssExcelPasswordById(UUID id);
}
