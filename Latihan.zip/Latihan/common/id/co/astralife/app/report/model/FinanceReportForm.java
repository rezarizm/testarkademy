package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

/**
 * @author fadil.wiranata
 */
@Getter
@Setter
public class FinanceReportForm {
	
	private String format;
    private String type;
    private String currency;
    private String source;
    private String startdate;
    private String enddate;
    private String stcb;
    private String yearspdf;
    private String yearsxls;
    private String startmonth;
    private String endmonth;
    private String month;
}
