package id.co.astralife.app.report.local.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.OjkMaster;

public interface OjkMasterRepository extends JpaRepository<OjkMaster, UUID> {

	OjkMaster findFirstByPolicyNo(String policyNo);
	
}
