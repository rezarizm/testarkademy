package id.co.astralife.app.report.core;

import java.io.File;
import java.util.List;
import java.util.Map;

public interface ZipGenerator {

	void generateZip(List<File> filesToAdd, Map<String, Object> params);
}
