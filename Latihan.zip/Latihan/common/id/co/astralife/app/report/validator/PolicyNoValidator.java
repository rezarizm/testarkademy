package id.co.astralife.app.report.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;
import id.co.astralife.app.report.validator.annotation.PolicyNo;

public class PolicyNoValidator implements ConstraintValidator<PolicyNo, String> {

  @Override
  public void initialize(PolicyNo annotation) {
      //
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
      return StringUtils.trimToNull(value) != null && value.length() == 8;
  }

}
