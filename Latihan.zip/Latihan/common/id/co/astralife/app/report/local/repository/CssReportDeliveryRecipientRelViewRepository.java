package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssReportDeliveryRecipientRelView;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface CssReportDeliveryRecipientRelViewRepository extends JpaRepository<CssReportDeliveryRecipientRelView, UUID> {
    List<CssReportDeliveryRecipientRelView> findDeliveryRecipientByCssDeliveryGroupId(String cssDeliveryGroupId);

    CssReportDeliveryRecipientRelView findRecipientByCssDeliveryGroupId(String cssDeliveryGroupId);
}
