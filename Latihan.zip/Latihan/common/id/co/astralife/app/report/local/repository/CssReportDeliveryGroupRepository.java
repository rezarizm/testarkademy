package id.co.astralife.app.report.local.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import id.co.astralife.app.report.local.entity.CssReportDeliveryGroup;

public interface CssReportDeliveryGroupRepository extends JpaRepository<CssReportDeliveryGroup, Integer> {
	CssReportDeliveryGroup findCssReportDeliveryGroupByCssDeliveryGroupId(String cssDeliveryGroupId);
}
