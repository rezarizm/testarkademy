package id.co.astralife.app.report.model;

import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UploadForm {

	private String type;
	private MultipartFile file;
	private String rptFreq;
	private String monthUpload;
	
}
