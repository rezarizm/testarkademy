package id.co.astralife.app.report.dm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "GAGCLHPF")
public class ClaimPaidPayable implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "POLICY_NO")
	private String policyNo;

}
