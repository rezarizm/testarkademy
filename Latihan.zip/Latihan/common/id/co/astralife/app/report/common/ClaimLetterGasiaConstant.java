package id.co.astralife.app.report.common;

public class ClaimLetterGasiaConstant {

    /**
     * @param START_DATE <yyyyMMdd>
     * @param END_DATE <yyyyMMdd>
     */
    public static final String QUERY_CLAIM_LETTER_GASIA = "SELECT * FROM TABLE(PKG_TANGO_CLAIM_GASIA.GET_CLAIM_GASIA(?1, ?2))";

    /**
     * @param CLAIM_NO
     * @param OCCURRENCE_NO
     */
    public static final String QUERY_CLAIM_LETTER_GASIA_CLAIM = "SELECT * FROM TABLE(PKG_TANGO_CLAIM_GASIA.GET_CLAIM_GASIA_CLAIM(?1, ?2))";

    /**
     * @param PROVORG
     */
    public static final String QUERY_CLAIM_LETTER_GASIA_RECAP = "SELECT * FROM TABLE(PKG_TANGO_CLAIM_GASIA.GET_CLAIM_GASIA_RECAP(?1, ?2))";

    /**
     * @param XML_LOG_NAME
     */
    public static final String QUERY_FIND_TANGO_LOG = "SELECT * FROM TANGO_GASIA_LOG WHERE XML_LOG_NAME = ?1 AND ROWNUM = 1";

    /**
     * @param XML_LOG_NAME
     */
    public static final String QUERY_COUNT_TANGO_LOG = "SELECT COUNT(*) FROM TANGO_GASIA_LOG WHERE XML_LOG_NAME = ?1";

    public static final String YGEXPRCP = "YGEXPRCP";

    private ClaimLetterGasiaConstant() {
        throw new IllegalAccessError("ClaimLetterGasiaConstant class");
    }
}
