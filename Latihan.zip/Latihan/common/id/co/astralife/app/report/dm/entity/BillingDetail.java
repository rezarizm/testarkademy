package id.co.astralife.app.report.dm.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "GAGBIHPF")
public class BillingDetail implements Serializable {

  private static final long serialVersionUID = -3089089865215114962L;

  @Id
  @Column(name = "BILL_NO")
  private String billNo;

  @Column(name = "POLICY_NO")
  private String policyNo;

  @Column(name = "CONTRACT_TYPE")
  private String contractType;

  @Column(name = "ATTN_TO")
  private String ygattnto;

  @Column(name = "EMAIL_TO")
  private String emailTo;

  @Column(name = "TRDT")
  private String trdt;

  @Column(name = "SOB")
  private String sob;

  @Column(name = "EMAIL_CC")
  private String emailCc;

}
