package id.co.astralife.app.report.model;

public enum Stcb {

	DIR("DIR"), AGT("AGT"), BRO("BRO"), IAG("IAG");
	
	private final String name;

	Stcb(final String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
