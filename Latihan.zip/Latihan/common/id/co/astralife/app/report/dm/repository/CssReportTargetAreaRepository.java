package id.co.astralife.app.report.dm.repository;

import id.co.astralife.app.report.dm.entity.CssReportTargetArea;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CssReportTargetAreaRepository extends JpaRepository<CssReportTargetArea, String> {
}
