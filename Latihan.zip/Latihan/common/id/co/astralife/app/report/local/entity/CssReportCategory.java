package id.co.astralife.app.report.local.entity;

import lombok.Data;

import javax.persistence.*;

import java.io.Serializable;

@Entity
@Data
@Table(name = "CSS_REPORT_CATEGORY")
public class CssReportCategory implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "CATEGORY_ID", nullable = false)
	private String cssCategoryId;

	@Column(name = "CATEGORY_NAME")
	private String cssCategoryName;
	
	@Column(name = "CATEGORY_VALUE")
	private String cssCategoryValue;
}
