package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApeRptForm {

	private String startDate;
	private String endDate;
	
}
