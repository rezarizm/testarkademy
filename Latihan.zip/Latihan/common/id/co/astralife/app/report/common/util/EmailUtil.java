package id.co.astralife.app.report.common.util;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import id.co.astralife.app.report.local.entity.AttachDetail;
import id.co.astralife.app.report.local.entity.Config;
import id.co.astralife.app.report.local.entity.Email;
import id.co.astralife.app.report.model.EmailEntity;
import id.co.astralife.app.report.model.EmailEntity.AttachmentDetail;
import id.co.astralife.app.report.model.EmailEntity.ContentDetail;

public class EmailUtil {
	
	public static final Logger LOGGER  = LoggerFactory.getLogger(EmailUtil.class);
	
	private EmailUtil(){
	}

	public static ResponseEntity<String> postForEntity(String url, String dataString){
		ResponseEntity<String> response = null; 
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity =  new HttpEntity<>(dataString, headers);
		
		try {
			response = restTemplate.postForEntity(url, httpEntity, String.class);
		} catch (Exception e){
			LOGGER.error("Response Entity, response:{}, body: {}, errorMessage:{}", response, dataString, e.getMessage());
			response = new ResponseEntity<>("ERROR", HttpStatus.BAD_REQUEST);
		}
		return response; 
	}
	
	public static EmailEntity<String> getEmailEntity(Email email, List<AttachDetail> attachDetails){
		
		boolean attachStatus = false;
		if (email.getAttachName() != null || email.getContentId() != null || !attachDetails.isEmpty()) {
			attachStatus = true;
		}
		
		EmailEntity<String> emailEntity = null;
		if (email.getToId() != null) {
			emailEntity = new EmailEntity<>();
			emailEntity.setFromId(email.getFromId());
			emailEntity.setToIds(getIdList(email.getToId()));
			emailEntity.setCcIds(getIdList(email.getCcId()));
			emailEntity.setBccIds(getIdList(email.getBccId()));
			emailEntity.setSubject(email.getSubject());
			emailEntity.setContent(email.getContent());
			emailEntity.setAttachmentStatus(attachStatus);
			emailEntity.setAttachmentDetails(getAttachDetails(email, attachDetails).isEmpty() ? null : getAttachDetails(email, attachDetails));
			emailEntity.setContentDetails(getContentDetails(email).isEmpty() ? null : getContentDetails(email));
		}
		return emailEntity;
	}
	
	public static List<String> getIdList(String ids) {
		List<String> idList = new ArrayList<>();
		if (ids != null) {
			boolean contains = ids.contains(",");
			if (contains) {
				String[] values = ids.split(",");
				for (String value : values) {
					value = value.trim();
					idList.add(value);
				} 
			} else {
				idList.add(ids.trim());
			}
		}
		return idList; 
	}
	
	public static List<ContentDetail> getContentDetails(Email email){
		List<ContentDetail> contentDetails = new ArrayList<>();
		if (email.getContentId() != null && email.getContentPath() != null){
			ContentDetail contentDetail = new ContentDetail();
			contentDetail.setContentId(email.getContentId());
			contentDetail.setContentPath(email.getContentPath());
			contentDetail.setContentType(email.getContentType());
			contentDetails.add(contentDetail);
		}
		return contentDetails;
	}
	
	public static List<AttachmentDetail> getAttachDetails(Email email, List<AttachDetail> attachDetails){
		List<AttachmentDetail> attahmentDetails = new ArrayList<>();
		
		if (email.getAttachName() != null && email.getAttachPath() != null) {
			AttachmentDetail attachmentDetail = new AttachmentDetail();
			attachmentDetail.setAttachmentName(email.getAttachName());
			attachmentDetail.setAttachmentPath(email.getAttachPath());
			attahmentDetails.add(attachmentDetail);
		} 
		
		if (!attachDetails.isEmpty()) {
			for (AttachDetail attachDetail : attachDetails) {
				AttachmentDetail attachmentDetail = new AttachmentDetail();
				attachmentDetail.setAttachmentName(attachDetail.getAttachName());
				attachmentDetail.setAttachmentPath(attachDetail.getAttachPath());
				attahmentDetails.add(attachmentDetail);
			}
		}
		return attahmentDetails;
	}
	
	public static String buildIdsFromConfig(List<Config> configs){
		StringBuilder sb =  new StringBuilder();
		if (configs.isEmpty()) {
			sb.append("");
		} else {
			for (Config config : configs) {
				sb.append(config.getConfigValue()+",");
			}
			sb.deleteCharAt(sb.length()-1);
		}
		return sb.toString();
	}
	
	public static AttachmentDetail setAttachmentDetail(String filePath, String fileName) {
		AttachmentDetail attachDetail = new AttachmentDetail();
		attachDetail.setAttachmentName(fileName);
		attachDetail.setAttachmentPath(filePath);
		return attachDetail;
	}
	
}