package id.co.astralife.app.report.local.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import id.co.astralife.app.report.local.entity.CssReportTemplate;

public interface CssReportTemplateRepository extends JpaRepository<CssReportTemplate, String>{
	
	CssReportTemplate findCssTemplateByCssTemplateId(String cssTemplateId);
	
}
