package id.co.astralife.app.report.local.repository;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.ReportFile;

public interface ReportFileRepository extends JpaRepository<ReportFile, String> {

	ReportFile findById (UUID id);
	
	ReportFile findByCreateBy(String createBy);
	
	ReportFile findByFileNameAndIsVisible(String fileName, boolean isVisible);
    
	Page<ReportFile> findByCreateByInAndRptIdInAndIsVisibleOrderByCreateDateDesc(Set<String> createBy, Set<UUID> rptId, boolean isVisible, Pageable pageable);

    Page<ReportFile> findByCreateByInAndRptIdInAndCreateDateBetweenAndIsVisibleOrderByCreateDateDesc(Set<String> createBy,
            Set<UUID> rptId, Date from, Date to, boolean isVisible, Pageable pageable);
    
    ReportFile findFirstByRptIdAndStatusInAndCreateByAndCreateDateBetween(UUID rptId, Set<String> status, String user, Date from, Date to);
    
    ReportFile findFirstByRptIdAndCreateByAndCreateDateBetween(UUID rptId, String user, Date from, Date to);
    
    ReportFile findFirstByRptIdAndCreateDateBetween(UUID rptId, Date from, Date to);
    
    List<ReportFile> findByRptIdAndCreateDateBetween(UUID rptId, Date from, Date to);
    
    ReportFile findFirstByFileNameAndIsVisible(String fileName, boolean isVisible);
}
