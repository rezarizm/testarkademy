package id.co.astralife.app.report.dm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.dm.entity.SmePolicy;

public interface SmePolicyRepository extends JpaRepository<SmePolicy, String>{

	@Query(nativeQuery = true)
	List<SmePolicy> findByDateBetween(String startDate, String endDate);
	
	@Query(nativeQuery = true)
	SmePolicy findByPolicyNoAndTranNo(String policyNo, String tranNo);
	
	@Query(nativeQuery = true)
	SmePolicy findForNextRow(String policyNo, String tranNo);
	
	@Query(nativeQuery = true)
	SmePolicy findCheckReversed(String policyNo, Long id);
	
}
