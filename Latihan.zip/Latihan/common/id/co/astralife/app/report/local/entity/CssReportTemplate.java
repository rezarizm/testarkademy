package id.co.astralife.app.report.local.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Data
@Table(name = "CSS_REPORT_TEMPLATE")
public class CssReportTemplate implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "TEMPLATE_ID", nullable = false)
    private String cssTemplateId;

    @Column(name = "TEMPLATE_NAME")
    private String cssTemplateName;

    @Column(name = "TEMPLATE_TYPE")
    private String cssTemplateType;

    @Column(name = "TEMPLATE_SERVICE_NAME")
    private String cssTemplateServiceName;
}
