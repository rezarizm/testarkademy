package id.co.astralife.app.report.dm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.common.MajorAlterationConstant;
import id.co.astralife.app.report.dm.entity.UnusedPremium;

public interface UnusedPremiumRepository extends JpaRepository<UnusedPremium, Long> {

	@Query(value = MajorAlterationConstant.QUERY_COUNT_UNUSED_PREMIUM, nativeQuery = true)
	Long countByPolicyNoAndTransactionDateBetween(String policyNo, String startDate, String enddDate);
}
