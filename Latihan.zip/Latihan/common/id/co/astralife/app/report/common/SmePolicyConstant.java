package id.co.astralife.app.report.common;

public class SmePolicyConstant {
	
	public static final String SME_POLICY = "AVAGroupMedicalProtection";
	
	public static final String PARAM_POL_NO = "policy_no";
	public static final String PARAM_TRAN_NO = "tran_no";
	public static final String PARAM_ISS_DATE = "iss_date";
	public static final String PARAM_CNT_TYPE = "cnt_type";
	public static final String PARAM_BATCTR_CODE = "batctr_code";
	public static final String PARAM_REPRINT = "reprint";
	
	// param startdate & enddate
	public static final String SME_BY_ISSDATE = "select * from table(pkg_sme_policy.get_data_by_date(?1,?2))";
	
	// param policyNo & tranno
	public static final String SME_BY_POLICY_NO = "select * from table(pkg_sme_policy.get_data_by_pol_no(?1,?2))";
	
	// param policyNo & tranno
	public static final String SME_POLICY_NEXT_ROW = "select * from table(pkg_sme_policy.get_next_row(?1,?2))";
	
	// param policyNo & id, if != null skip 
	public static final String SME_POLICY_CHECK_REVERSED = "select * from table(pkg_sme_policy.get_check_reversed(?1,?2))";
	
	private SmePolicyConstant(){
	}
	
}
