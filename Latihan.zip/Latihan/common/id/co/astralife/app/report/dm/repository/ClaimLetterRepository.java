package id.co.astralife.app.report.dm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.dm.entity.Claim;

public interface ClaimLetterRepository extends JpaRepository<Claim, String>{

	@Query(nativeQuery=true)
	List<Claim> findClaimData(String claimNo, String occNo, String letterType, String startDate, String endDate);
	
	@Query(nativeQuery=true)
	Claim findClaimDetail(String chdrnum, String letterType, String clamnum, String occNo);
	
	@Query(nativeQuery=true, value = ReportConstant.CLAIM_LETTER_GET_SUBJECT_EMAIL)
	String getSubjectEmail(String chdrnum, String clamNo, String occNo);
	
}
