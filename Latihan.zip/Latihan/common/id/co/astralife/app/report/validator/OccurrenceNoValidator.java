package id.co.astralife.app.report.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import id.co.astralife.app.report.validator.annotation.OccurrenceNo;

public class OccurrenceNoValidator implements ConstraintValidator<OccurrenceNo, String> {

	@Override
	public void initialize(OccurrenceNo annotation) {
		//
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
		return value == null || value.length() == 0 || value.length() == 2;
	}

}
