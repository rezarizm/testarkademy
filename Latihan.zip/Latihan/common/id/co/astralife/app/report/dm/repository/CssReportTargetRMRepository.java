package id.co.astralife.app.report.dm.repository;

import id.co.astralife.app.report.dm.entity.CssReportTargetRM;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CssReportTargetRMRepository extends JpaRepository<CssReportTargetRM, String> {
}
