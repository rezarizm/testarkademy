package id.co.astralife.app.report.iplus.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.iplus.entity.Contract;

public interface ContractRepository extends JpaRepository<Contract, Long>{

	@Query(nativeQuery=true)
	Contract findCountData(String actionDate);
	
}
