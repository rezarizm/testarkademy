package id.co.astralife.app.report.mirror.repository;

import id.co.astralife.app.report.mirror.entity.OutstandingPremium;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OutstandingPremiumRepository extends JpaRepository<OutstandingPremium, String>{

}
