package id.co.astralife.app.report.local.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.VoucherOrder;

public interface VoucherOrderRepository extends JpaRepository<VoucherOrder, UUID> {

	VoucherOrder findByOrderNoAndAgentCode(String orderNo, String agentCode);

}
