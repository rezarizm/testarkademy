package id.co.astralife.app.report.tango.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@Table(name = "TANGO_LETTER_LIST")
public class TangoLetterList implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "LETTER_CODE")
    private String letterCode;

    @Column(name = "LETTER_TYPE")
    private String letterType;

    @Column(name = "LETTER_NAME")
    private String letterName;

    @Column(name = "REST_ADDRESS")
    private String restAddress;
}
