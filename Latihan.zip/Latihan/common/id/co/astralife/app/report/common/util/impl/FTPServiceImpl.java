package id.co.astralife.app.report.common.util.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;

import id.co.astralife.app.report.common.util.FTPService;
import id.co.astralife.app.report.common.util.exception.FTPServiceException;



public class FTPServiceImpl implements FTPService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FTPServiceImpl.class);

    private String hostname;
    private String username;
    private String password;
    private String port;

    private int maxRetry = 2;
    private int delayRetry = 120000;


    @Override
    public void uploadFile(File fileToUpload, String hostDir) throws FTPServiceException {

        Session session = null;
        Channel channel = null;
        ChannelSftp channelSftp = null;

        int retryCounter = 0;
        boolean retries = true;

        while (retries) {

            retryCounter++;

            JSch jsch = new JSch();
            try (InputStream inputStream = new FileInputStream(fileToUpload)){
                session = jsch.getSession(username, hostname, Integer.valueOf(port));
                session.setPassword(password);
                Properties config = new Properties();
                config.put("StrictHostKeyChecking", "no");
                session.setConfig(config);
                session.connect();
                channel = session.openChannel("sftp");
                channel.connect();

                channelSftp = (ChannelSftp) channel;

                SftpATTRS sftpATTRS = null;
                try {
                    sftpATTRS = channelSftp.stat(hostDir);
                } catch (Exception e) {
                    LOGGER.info("Directory " + hostDir + " doesn't exists");
                }

                if (sftpATTRS != null) {
                    LOGGER.info("Directory exists IsDir="+ sftpATTRS.isDir());
                } else {
                    channelSftp.mkdir(hostDir);
                    LOGGER.info(hostDir + " directory has been created");
                }

                channelSftp.cd(hostDir);

                LOGGER.info("Uploading file " + fileToUpload.getName() + " to SFPT " + this.hostname);
                LOGGER.info("File size " + fileToUpload.getName() + ": " + fileToUpload.length() + " B");
                channelSftp.put(inputStream, fileToUpload.getName());

                LOGGER.info("Uploading file " + fileToUpload.getName() + " to SFPT " + this.hostname + " -- Success");
                retries = false;
            } catch (JSchException | IOException | SftpException e) {
                LOGGER.info("Uploading file " + fileToUpload.getName() + " to SFPT " + this.hostname + " -- Failed - " + retryCounter, e + "(st/nd/rd) tries");
                retries = retryCounter < this.maxRetry;
                if (!retries)
                    throw new FTPServiceException(e);
                else {
                    LOGGER.info("Retrying to connect to " + this.hostname + "...");
                    try {
                        Thread.sleep(this.delayRetry);
                    } catch (InterruptedException e1) {
                        LOGGER.error(e1.getMessage(), e1);
                    }
                }
            } finally {
                // Disconect
                if (session != null && session.isConnected()) {
                    session.disconnect();
                }
                if (channel != null && channel.isConnected()) {
                    channel.disconnect();
                }
                if (channelSftp != null && channelSftp.isConnected()) {
                    channelSftp.disconnect();
                }
            }


        }


    }


    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public int getMaxRetry() {
        return maxRetry;
    }

    public void setMaxRetry(int maxRetry) {
        this.maxRetry = maxRetry;
    }

    public int getDelayRetry() {
        return delayRetry;
    }

    public void setDelayRetry(int milis) {
        this.delayRetry = milis;
    }
}
