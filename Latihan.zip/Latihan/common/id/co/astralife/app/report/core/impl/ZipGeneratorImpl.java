package id.co.astralife.app.report.core.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.core.ZipGenerator;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.io.ZipOutputStream;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

@Service
public class ZipGeneratorImpl implements ZipGenerator{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ZipGeneratorImpl.class);
	
	@Override
	public void generateZip(List<File> filesToAdd, Map<String, Object> params) { 
		
		String filePath = params.get(ReportConstant.FILEPATH_PARAM).toString();
		
		ZipOutputStream outputStream = null;
		InputStream inputStream = null;
		try (ZipOutputStream outputStream1 = new ZipOutputStream(new FileOutputStream(
				new File((filePath.substring(0, filePath.lastIndexOf('.')))+".zip")))) {
			
			outputStream = outputStream1;
			ZipParameters parameters = new ZipParameters();
			parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
			parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
			if (params.containsKey(ReportConstant.ZIP_PASS)) {
				parameters.setEncryptFiles(true);
				parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
				parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
				if (params.get(ReportConstant.ZIP_PASS) != null) {
					parameters.setPassword(params.get(ReportConstant.ZIP_PASS).toString());
				} else {
					parameters.setPassword("password");
				}
			}
			
			for(int i=0; i < filesToAdd.size(); i++ ) {
				File file = filesToAdd.get(i);
				outputStream.putNextEntry(file, parameters);
				if(file.isDirectory()){
					outputStream.closeEntry();
					continue;
				}
				inputStream = new FileInputStream(file);
				byte [] readBuff = new byte[4096];
				int readLen = -1;
				while ((readLen = inputStream.read(readBuff)) != -1){
					outputStream.write(readBuff, 0, readLen);
				}
				outputStream.closeEntry();
				inputStream.close();
			}
			outputStream.finish();
		} catch (FileNotFoundException e) {
			LOGGER.error("File Not Found Exception ..."+ e.getMessage(), e);
		} catch (ZipException e) {
			LOGGER.error("Zip Exception ..." + e.getMessage(), e);
		} catch (IOException e) {
			LOGGER.error("IO Exception ..." + e.getMessage(), e);
		} finally {
			try {
				if (outputStream != null) {
					outputStream.close();
				}
				if (inputStream != null) {
					inputStream.close();
				}
			} catch (IOException e) {
				LOGGER.error("IO Exception ..." + e.getMessage(), e);
			}
		}
	}
}
