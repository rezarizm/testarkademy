package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssReportFileGroup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CssReportFileGroupRepository extends JpaRepository<CssReportFileGroup, String>{
	CssReportFileGroup findCssReportFileGroupByCssFileGroupId(String fileGroupId);
}
