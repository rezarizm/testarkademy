package id.co.astralife.app.report.common;

public class MajorAlterationConstant {

	public static final String UNUSED_PREM_TEMPLATE = "UnusedPremium";
    public static final String PARAM_START_DATE = "startDate";
    public static final String PARAM_END_DATE = "endDate";
    public static final String PARAM_POL_NO = "policyNo";
    
	public static final String QUERY_COUNT_UNUSED_PREMIUM = "select count(*) count_data from table(pkg_rpt_unused_premium.get_unused_premium(?1,?2,?3))"; 
	
	public static final String MAJOR_ALT_HISTORY_TEMPLATE = "MajorAlterationHistory";
	
	private MajorAlterationConstant() {
        throw new IllegalAccessError("Constant Class");
    }
}
