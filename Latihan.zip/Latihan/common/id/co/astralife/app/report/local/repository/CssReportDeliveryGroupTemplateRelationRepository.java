package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssReportDeliveryGroupTemplateRelation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface CssReportDeliveryGroupTemplateRelationRepository extends JpaRepository<CssReportDeliveryGroupTemplateRelation, UUID> {
    CssReportDeliveryGroupTemplateRelation findDeliveryTemplatesByIdRel(UUID idRel);

    List<CssReportDeliveryGroupTemplateRelation> findTemplateByCssDeliveryGroupId(String cssDeliveryGroupId);
}
