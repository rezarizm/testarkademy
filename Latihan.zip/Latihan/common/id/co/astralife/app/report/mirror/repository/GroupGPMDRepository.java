package id.co.astralife.app.report.mirror.repository;

import id.co.astralife.app.report.mirror.entity.GroupGPMD;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author fadil.wiranata
 */
public interface GroupGPMDRepository extends JpaRepository<GroupGPMD, String> {

    public Integer maxTranNoByPolicyNoAndMbrNoAndDpntNo(String policyNo, String mbrNo, String dpntNo);
}
