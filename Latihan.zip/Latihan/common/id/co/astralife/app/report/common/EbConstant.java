package id.co.astralife.app.report.common;

public class EbConstant {

	public static final int REFERENCE_NO = 0;
	public static final int USER = 1;
	public static final int CLAIM_TYPE = 2;
	public static final int CLAIM_NO = 3;
	public static final int POLICY_NO = 4;
	public static final int MEMBER_NO = 5;
	public static final int VIP = 6;
	public static final int POL_HOLDER = 7;
	public static final int SUBS = 8;
	public static final int BRANCH = 9;
	public static final int RECEIVED_DATE = 10;
	public static final int TIME_RECEIVED = 11;
	public static final int INVOICE_DATE = 12;
	public static final int EMP_NO = 13;
	public static final int EMP_NAME = 14;
	public static final int PATIENT_NAME = 15;
	public static final int PRODUCT = 16;
	public static final int TOT_AMT_INC = 17;
	public static final int REMARK = 18;
	public static final int POINT_OF_CARE = 19;
	public static final int CLM_PEND_AGING = 20;
	public static final int SRC_DOC = 21;
	
	public static final String EB_CLAIM_TEMP = "EbClaimNoTemplate";
	
	private EbConstant(){
		throw new IllegalAccessError("Constant Class");
	}
}
