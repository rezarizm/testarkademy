package id.co.astralife.app.report.mirror.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.ReportConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries({
	@NamedNativeQuery(name="BiReportGroup.getCountData", query=ReportConstant.BI_REPORT_GROUP, resultClass=BiReportGroup.class) 
})
@Table(name = "GACHDRPF")
public class BiReportGroup {

	@Id
	@Column(name = "COUNT_DATA")
	private Long count; 
}
