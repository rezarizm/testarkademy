package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;
import java.util.UUID;

/**
 * @author fadil.wiranata
 */
@Getter
@Setter
public class ReportRequest {

    private UUID id;
    private Map<String, Object> params;
}
