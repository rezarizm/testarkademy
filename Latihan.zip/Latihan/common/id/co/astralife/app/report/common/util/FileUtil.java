package id.co.astralife.app.report.common.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.zip.CRC32;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(FileUtil.class);
	
	private FileUtil() {
	}

	public static String generateFileName(String prefix, String user) {
		Date dateTime = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmmssSSS");
		String date = sdf.format(dateTime);

		CRC32 crc = new CRC32();
		crc.update(UUID.randomUUID().toString().getBytes());

		return prefix + "_" + user + "_" + date + "_" + crc.getValue();
	}

	public static String generateFileName(String prefix, String suffix, String user) {
		return prefix + "_" + user + "_" + suffix;
	}

	public static String generateDefaultFileName(String reportName, String userName) {
		return generateFileName(reportName, userName);
	}

	public static Boolean bufferFile(InputStream inputStream, OutputStream outputStream) {
		try {
			byte[] buffer = new byte[4096];
			int length;
			while ((length = inputStream.read(buffer)) > 0) {
				outputStream.write(buffer, 0, length);
				outputStream.flush();
			}
			inputStream.close();
			outputStream.close();
		} catch (IOException e) {
			LOGGER.error("IOException: bufferFile " + e.getMessage(), e);
		}
		return true;
	}
	
	public static <T> Boolean createTextFile(List<T> entities, String filePath, String headers) {
		try (FileWriter writer = new FileWriter(filePath)){
			writer.append(headers);
	 		writer.append("\r\n");
			for (T entity : entities){
				writer.append(entity.toString());
				writer.append("\r\n");
			}
			writer.flush();
	 		writer.close();
		} catch (IOException e) {
			LOGGER.error("IOException: createTextFile " + e.getMessage(), e);
			return false;
		}
		return true;
	}
}
