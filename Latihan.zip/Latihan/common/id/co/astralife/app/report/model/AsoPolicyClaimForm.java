package id.co.astralife.app.report.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import id.co.astralife.app.report.validator.annotation.PolicyNo;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Getter
@Setter
public class AsoPolicyClaimForm {

    @JsonProperty("policyNo")
    @PolicyNo
    private String policyNo;

    @JsonProperty("amount")
    @Digits(integer=15, fraction=2, message = "Please input valid number")
    @NotNull
    private BigDecimal amount;

    @JsonProperty("type")
    private String type;

    @JsonProperty("createBy")
    private String createBy;
}
