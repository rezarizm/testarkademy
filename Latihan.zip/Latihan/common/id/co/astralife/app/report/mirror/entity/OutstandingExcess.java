package id.co.astralife.app.report.mirror.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "V_RPT_OUTS_EXC")
public class OutstandingExcess {

	@Id
	@Column(name = "AGENT_NO")
	private String agentNo;
	
	@Column(name = "COMPANY_NAME")
	private String companyName;
	
	@Column(name = "EXC_CLAIM_AMT")
	private BigDecimal totalOutsExc;
	
}
