package id.co.astralife.app.report.email.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import id.co.astralife.app.report.local.entity.Email;
import id.co.astralife.app.report.model.EmailEntity;

public interface EmailService {
	
	Email findByEmailId (UUID emailId);
	
	void save (Email email);
	
	void save(List<Email> emails);

	void emailScheduler(String user);
	
	Email sendEmail (EmailEntity<String> emailEntity, Email email, String user);
	
	String render(String template, Map<String, String> params);
	
	String renderByTemplate(String templatePath, String charset, Map<String, String> params);
	
	Email findBySubjectAndCreateDateBetween (String subject, Date from, Date to);

	List<Email> findByEmailIdIn(Set<UUID> emailIds);
	
	List<Email> findByCreateDateBetween(Date startDate, Date endDate);
	
	List<Email> findByFromIdInAndCreateDateBetween(Set<String> fromIds, Date startDate, Date endDate);
	
	List<Email> findByReportIdInAndCreateDateBetween(Set<UUID> rptIds, Date startDate, Date endDate);
}
