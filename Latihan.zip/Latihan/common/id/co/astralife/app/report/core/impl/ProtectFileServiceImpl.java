package id.co.astralife.app.report.core.impl;

import id.co.astralife.app.report.core.ProtectFileService;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.crypt.EncryptionMode;
import org.apache.poi.poifs.crypt.Encryptor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.*;
import java.security.GeneralSecurityException;

@Service
public class ProtectFileServiceImpl implements ProtectFileService {

    public static final Logger LOGGER = LoggerFactory.getLogger(ProtectFileServiceImpl.class);

    @Override
    public void protectOoxmlFile(String fileName, String pathInput, String pathOutput, String password) {
        try {
            POIFSFileSystem fileSystem = new POIFSFileSystem();
            EncryptionInfo info = new EncryptionInfo(EncryptionMode.agile);

            Encryptor enc = info.getEncryptor();
            enc.confirmPassword(password);

            // Read in an existing OOXML file
            OPCPackage opc = OPCPackage.open(new File(pathInput + fileName), PackageAccess.READ_WRITE);
            OutputStream outputStream = enc.getDataStream(fileSystem);
            opc.save(outputStream);
            opc.close();

            // Write out the encrypted version
            FileOutputStream fileOutputStream = new FileOutputStream(pathOutput + fileName);
            fileSystem.writeFilesystem(fileOutputStream);
            fileOutputStream.close();
        } catch (IOException e) {
            LOGGER.error("IOException " + e.getMessage(), e);
        } catch (InvalidFormatException e) {
            LOGGER.error("InvalidFormatException " + e.getMessage(), e);
        } catch (GeneralSecurityException e) {
            LOGGER.error("GeneralSecurityException " + e.getMessage(), e);
        }

    }

    @Override
    public void makeReadOnly(String fileName, String pathInput, String pathOutput) {
        try {
            XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(pathInput + fileName));
            int getAllSheet = wb.getNumberOfSheets();
            for (int i = 0; i < getAllSheet; i++) {
                XSSFSheet sheet = wb.getSheetAt(i);
                sheet.enableLocking();
            }
            FileOutputStream fos = new FileOutputStream(pathOutput + fileName);
            wb.write(fos);
            wb.close();
            fos.flush();
            fos.close();
            LOGGER.info("SUCCESS: Set {} to Read Only Mode", fileName);
        } catch (Exception e) {
            LOGGER.error("\r\nERROR on protectFileService.makeReadOnly : " + e.getMessage(), e);
        }
    }

}
