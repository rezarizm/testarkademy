package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.User;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

/**
 * @author fadil.wiranata
 */
public interface UserRepository extends JpaRepository<User, UUID> {

	Page<User> findAll(Pageable pageable);
	
	User findByLoginId(String loginId);

    User getFirstByLoginId(String loginId);
    
    List<User> getByLoginIdIgnoreCaseContaining(String username);
}
