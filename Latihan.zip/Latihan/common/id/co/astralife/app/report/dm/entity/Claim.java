package id.co.astralife.app.report.dm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.ReportConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries({
		@NamedNativeQuery(name = "Claim.findClaimData", query = ReportConstant.CLAIM_LETTER_LETC, resultClass = Claim.class),
		@NamedNativeQuery(name = "Claim.findClaimDetail", query = ReportConstant.CLAIM_LETTER_PKG_CLAIM, resultClass = Claim.class),
})
@Table (name = "GALETCPF")
public class Claim implements Serializable {

	private static final long serialVersionUID = 8493467778698352729L;

	@Id
	@Column(name = "CLAMNUM_OCCNO")
	private String clamnumOcc;
	
	@Column(name = "CHDRNUM")
	private String chdrnum;
	
	@Column(name = "YGEMAIL")
	private String ygEmail;
	
	@Column(name = "PRTOPT")
	private String print;
	
	@Column(name = "EMAIL")
	private String emailTo;
	
	@Column(name = "EMAIL_CC")
	private String emailCc;
	
	@Column(name = "CLNTNUM")
	private String clntnum;
	
	@Column(name = "MBRNO")
	private String memberNo;
	
	@Column(name = "DPNTNO")
	private String dpntNo;
	
	@Column(name = "LETTYPE")
	private String letterType;
	
	@Column(name = "CLAMNUM")
	private String clamnum;
	
	@Column(name = "GCOCCNO")
	private String occNo;
	
	@Column(name = "LREQDATE")
	private String reqDate;
	
	@Column(name = "ORIGIN_LETTYPE")
	private String originLeterType;
	
	@Column(name = "COUNT_PRINT")
	private Long countPrint;
	
	@Column(name = "COUNT_ZZ5")
	private Long countZz5;
	
	@Column(name = "COUNT_CORR_DT")
	private Long countCorrDate;
	
}
