package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.common.ClaimLetterGasiaConstant;
import id.co.astralife.app.report.local.entity.TangoGasiaLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface TangoGasiaLogRepository extends JpaRepository<TangoGasiaLog, String> {

    @Query(nativeQuery = true)
    TangoGasiaLog findByXmlLogName(String xmlLogName);

    @Query(nativeQuery = true, value = ClaimLetterGasiaConstant.QUERY_COUNT_TANGO_LOG)
    Long countTangoGasiaLogByXmlLogName(String xmlLogName);
}
