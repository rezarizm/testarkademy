package id.co.astralife.app.report.common;

public class AsoConstant {

  private AsoConstant() {
    throw new IllegalAccessError("AsoConstant Class");
  }
  
  public static final String ASO_REPORT = "AsoReport";
  public static final String ASO_LETTER = "AsoLetter";
  public static final String JSON_SOURCE = "JSON_SOURCE";
  public static final String ASO_EMAIL_TO = "ASO_EMAIL_TO";
  public static final String EMAIL_CONTENT = "This email is sent automatically by system. Please don\'t reply.";
  
}
