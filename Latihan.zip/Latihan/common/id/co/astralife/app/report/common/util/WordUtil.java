package id.co.astralife.app.report.common.util;

import java.util.ArrayList;
import java.util.List;

public class WordUtil {

	private WordUtil(){
	}
	
	public static List<String> getSplitWordList(String words, String character) {
		List<String> wordList = new ArrayList<>();
		if (words != null) {
			boolean contains = words.contains(character);
			if (contains) {
				String[] values = words.split(character);
				for (String value : values) {
					value = value.trim();
					wordList.add(value);
				} 
			} else {
				wordList.add(words);
			}
		}
		return wordList; 
	}
}
