package id.co.astralife.app.report.local.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.UUID;

@Data
@Entity
@Table(name = "CSS_RPRT_DELIVERY_RECIPIENT_V")
public class CssReportDeliveryRecipientRelView implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "ID_REL", nullable = false)
    private UUID idRel;

    @Column(name = "RECIPIENT_ID", nullable = false)
    private UUID cssRecipientId;

    @Column(name = "RECIPIENT_ADDRESS", nullable = false)
    private String cssRecipientAddress;

    @Column(name = "RECIPIENT_NAME", nullable = false)
    private String cssRecipientName;

    @Column(name = "DELIVERY_GROUP_ID", nullable = false)
    private String cssDeliveryGroupId;

    @Column(name = "DELIVERY_GROUP_NAME", nullable = false)
    private String cssDeliveryGroupName;

    @Column(name = "CRON_EXPRESSION", nullable = false)
    private String cronExpression;
}
