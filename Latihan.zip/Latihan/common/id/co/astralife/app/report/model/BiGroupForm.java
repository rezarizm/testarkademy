package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BiGroupForm {

	private String month;
	private String year;
	private Boolean duplicate;
}
