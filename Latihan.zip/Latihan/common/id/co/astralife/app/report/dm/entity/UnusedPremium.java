package id.co.astralife.app.report.dm.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Data
@Entity
@Table(name = "IPCONTRACT")
public class UnusedPremium {

	@Id
	@Column(name = "ID")
	private Long id;
	
	@Column (name = "POLICY_NO")
	private String policyNo;
	
	@Column (name = "POLICY_OWNER")
	private String policyOwner;
	
	@Column (name = "PRODUCT")
	private String product;
	
	@Column (name = "TRANSACTION_TYPE")
	private String transType;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column (name = "TRANSACTION_DATE")
	private Date transDate;
	
	@Column (name = "UNUSED_AMOUNT")
	private BigDecimal unusedAmount;
}
