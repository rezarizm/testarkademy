package id.co.astralife.app.report.mirror.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author fadil.wiranata
 */
@Entity
@Table(name = "GAGIDTPF")
@NamedNativeQueries({
        @NamedNativeQuery(name = "GroupGIDT.maxIssDateByChdrNum",
                query ="select max(gidt.ISSDATE) from GAGIDTPF gidt where gidt.CHDRNUM = ?1")
})
public class GroupGIDT implements Serializable {

	private static final long serialVersionUID = -2605451662672410139L;

	@Id
    @Column(name = "CHDRNUM")
    private String chdrNum;

    @Id
    @Column(name = "TRANNO")
    private String tranNo;

    @Column(name = "ISSDATE")
    private String issDate;

    public String getChdrNum() {
        return chdrNum;
    }

    public void setChdrNum(String chdrNum) {
        this.chdrNum = chdrNum;
    }

    public String getTranNo() {
        return tranNo;
    }

    public void setTranNo(String tranNo) {
        this.tranNo = tranNo;
    }

    public String getIssDate() {
        return issDate;
    }

    public void setIssDate(String issDate) {
        this.issDate = issDate;
    }
}
