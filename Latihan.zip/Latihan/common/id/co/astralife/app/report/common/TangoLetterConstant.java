package id.co.astralife.app.report.common;

public class TangoLetterConstant {

    public static final String GET_ALL_LETTER_QUERY = "SELECT * FROM TANGO_LETTER_LIST ORDER BY LETTER_TYPE, LETTER_NAME";

    public static final String GET_REST_ADDRESS_QUERY = "SELECT REST_ADDRESS FROM TANGO_LETTER_LIST WHERE LETTER_CODE = ?1";

    private TangoLetterConstant() {
        throw new IllegalAccessError("TangoLetterConstant class");
    }
}
