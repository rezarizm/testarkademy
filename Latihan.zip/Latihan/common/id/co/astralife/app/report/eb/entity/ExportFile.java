package id.co.astralife.app.report.eb.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import lombok.Data;

@Data
@Entity
@Table(name = "CLAIM_EXPORT_FILES")
public class ExportFile implements Serializable {

	private static final long serialVersionUID = 5890791765217974399L;

	@Id
	@GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
	@Column(name = "FILE_ID", nullable = false)
	private UUID fileId;

	@Column(name = "FILE_PATH")
	private String filePath;

	@Column(name = "FILE_NAME")
	private String fileName;

	@Column(name = "GENERATED_BY")
	private String generatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "GENERATED_AT")
	private Date generatedAt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DATE_FROM")
	private Date dateFrom;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DATE_TO")
	private Date dateTo;
}
