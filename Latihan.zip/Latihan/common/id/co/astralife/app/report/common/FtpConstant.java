package id.co.astralife.app.report.common;

public class FtpConstant {

	public static final String SFTP = "sftp";
	public static final String SFTP_MANUAL_CONNECT = "ftpManualConnect";	
	public static final String FTP_HOST_NAME = "ftpHostName";
	public static final String FTP_USER_NAME = "ftpUserName";
	public static final String FTP_PASSWORD = "ftpPassword";
	public static final String FTP_PORT = "ftpPort";

	public static final String FTP_GENDATE = "ftpGenDate";
	public static final String FTP_OUTPUT_DIR = "ftpOutputDir";
	public static final String FTP_FOLDER_NAME = "ftpFolderName";
	public static final String FTP_OUTPUT_NAME = "ftpOutputName";
	public static final String FTP_CREATE_FOLDER = "ftpCreateFolder";
	
	public static final String SFTP_ENCRYPTED = "sftpEncrypted";
	public static final String FTP_ENCRYPTED_NAME = "ftpEncryptedName";
	public static final String FTP_ENCRYPTED_DIR = "ftpEncryptedDir";
	
	private FtpConstant() {
		throw new IllegalAccessError("Constant Class");
	}
}
