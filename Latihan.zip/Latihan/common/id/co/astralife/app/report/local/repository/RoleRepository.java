package id.co.astralife.app.report.local.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.Role;

import java.util.UUID;

public interface RoleRepository extends JpaRepository<Role, String>{
	Role findByRoleId(UUID roleId);
}
