package id.co.astralife.app.report.model;

import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
public class FileGroupRoleForm {
    private List<UUID> roleId;

    private String cssFileGroupId;
}
