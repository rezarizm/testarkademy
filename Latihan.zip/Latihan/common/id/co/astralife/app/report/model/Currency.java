package id.co.astralife.app.report.model;

/**
 * @author fadil.wiranata
 */
public enum Currency {

    IDR("IDR"), USD("USD");

    private final String name;

    Currency(final String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
