package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.ReportRole;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRoleRepository extends JpaRepository<ReportRole, UUID>{

	List<ReportRole> getByRoleIdIn(List<UUID> reports);
}
