package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ClaimReportGasiaRequest {

	private String startDate;
	private String endDate;	
	private String user;
	private String typeReport;
	private String emailAddress;
}
