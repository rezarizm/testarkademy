package id.co.astralife.app.report.local.entity;

import id.co.astralife.app.report.common.ClaimLetterGasiaConstant;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Data
@Entity
@NamedNativeQueries({
    @NamedNativeQuery(name = "TangoGasiaLog.findByXmlLogName", query = ClaimLetterGasiaConstant.QUERY_FIND_TANGO_LOG, resultClass = TangoGasiaLog.class)
})
@Table(name = "TANGO_GASIA_LOG")
public class TangoGasiaLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column (name = "GASIA_LOG_ID", nullable = false)
    private UUID gasiaLogId;

    @Column(name = "XML_LOG_NAME")
    private String xmlLogName;

    @Column(name = "FILE_NAME", nullable = false)
    private String fileName;

    @Column(name = "FILE_PATH", nullable = false)
    private String filePath;

    @Column(name = "CREATE_BY", nullable = false)
    private String createBy;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;
}
