package id.co.astralife.app.report.local.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.GenericGenerator;

import lombok.Data;

@Data
@Entity
@Table(name = "RPT_FUNCTION")
public class Function extends BaseEntity{

    private static final long serialVersionUID = -8018926365234285415L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "FUNC_ID", nullable = false)
    private UUID functionId;
    
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(name = "RPT_MENU_FUNCTION", 
        joinColumns = {@JoinColumn(name = "FUNC_ID", nullable = false, updatable = false)},
        inverseJoinColumns = {@JoinColumn(name = "MENU_ID", nullable = false, updatable = false)}
    )    
    private List<Menu> menus = new ArrayList<>();
    
}
