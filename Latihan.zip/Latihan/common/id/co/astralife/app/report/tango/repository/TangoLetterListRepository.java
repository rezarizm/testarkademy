package id.co.astralife.app.report.tango.repository;

import id.co.astralife.app.report.common.TangoLetterConstant;
import id.co.astralife.app.report.tango.entity.TangoLetterList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TangoLetterListRepository extends JpaRepository<TangoLetterList, String> {

    @Query(nativeQuery = true, value = TangoLetterConstant.GET_ALL_LETTER_QUERY)
    List<TangoLetterList> getTangoLetters();

    @Query(nativeQuery = true, value = TangoLetterConstant.GET_REST_ADDRESS_QUERY)
    String getRestAddress(String letterCode);
}
