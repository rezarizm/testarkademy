package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MajorAltRequest {

	private String user;
	private String policyNo;
	private String startDate;
	private String endDate;
	
}
