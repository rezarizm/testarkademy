package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GuaranteedCashReportForm {

	private String startDate;
	private String endDate;
	private Boolean isEmail=false;
	private String user;
	
	
}
