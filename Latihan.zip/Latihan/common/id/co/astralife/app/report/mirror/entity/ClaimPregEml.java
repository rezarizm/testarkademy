package id.co.astralife.app.report.mirror.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.ReportConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries(
		@NamedNativeQuery(name = "ClaimPregEml.findEmailClaimPregByRefNoAndPolicyNoAndMbrNo", query = ReportConstant.CLAIM_PREG_EMAIL, resultClass = ClaimPregEml.class)
)
@Table(name = "GAYCRHPF")
public class ClaimPregEml implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2559228277488946230L;

	@Id
	@Column(name="POL_NO")
	private String policyNo;

	@Column(name = "EMP_EMAIL")
	private String empEmail;

	@Column(name = "YGCA_POL_NO")
	private Long ygcaPolNo;
}
