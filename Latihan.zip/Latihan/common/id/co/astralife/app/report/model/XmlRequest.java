package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.Map;
import java.util.UUID;

@Getter
@Setter
public class XmlRequest {

    private UUID id;
    private Map<String, String> params;
    private Map<Object, Object> data;
    private String generatedDate;
    private String policyNo;
    private Date genDate;
    private String clientNo;
    private String startDate;
    private String endDate;
    private String letterType;
    private String letterCode;
    private String type;
    private String restAddress;
}
