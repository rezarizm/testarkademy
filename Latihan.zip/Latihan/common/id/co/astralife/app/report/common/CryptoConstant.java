package id.co.astralife.app.report.common;

public class CryptoConstant {

	public static final String PGP_ENCRYPT = "pgpEncrypt"; 
	
	private CryptoConstant() {
		throw new IllegalAccessError("Constant Class");
	}
}
