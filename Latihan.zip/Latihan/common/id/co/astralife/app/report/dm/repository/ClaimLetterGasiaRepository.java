package id.co.astralife.app.report.dm.repository;

import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.dm.entity.ClaimLetterGasia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ClaimLetterGasiaRepository extends JpaRepository<ClaimLetterGasia, Integer> {

    @Query(nativeQuery = true)
    List<ClaimLetterGasia> getClaimLetterGasiaByReqDate(String startDate, String endDate);

    @Query(nativeQuery = true)
    List<ClaimLetterGasia> getClaimLetterGasiaByClaimNoAndOccurrenceNo(String claimNo, String occurrenceNo);

    @Query(nativeQuery = true)
    List<ClaimLetterGasia> getClaimLetterGasiaByProvorg(String provorg, String authDate);
    
    @Query(nativeQuery=true, value = ReportConstant.CLAIM_LETTER_GET_SUBJECT_EMAIL)
    String getSubjectEmail(String chdrnum, String clamNo, String occNo);
}
