package id.co.astralife.app.report.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import id.co.astralife.app.report.validator.annotation.ClaimNo;

public class ClaimNoValidator implements ConstraintValidator<ClaimNo, String> {

	@Override
	public void initialize(ClaimNo annotation) {
		//
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
		return value == null || value.length() == 0 || value.length() == 8;
	}

}
