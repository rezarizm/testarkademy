package id.co.astralife.app.report.common;

/**
 * @author fadil.wiranata
 */
public class OperationConstant {

    public static final String CERTIFICATE = "Certificate";
    public static final String PRINT_REPORT = "PrintReport";
    public static final String AVA_IPRO_KREDITKU = "AVAiProKreditkuCertificate";
    public static final String EXREPRSH = "ExperienceRefundProfitSharing";
    public static final String BI_XLS = "BiReport";
    public static final String BI_GROUP_XLS = "BIReportGroup";
    public static final String AVA_SEHAT_PROTEKSIKU = "AVASehatProteksiKuCertificate";
    public static final String CLAIM_LETTER = "ClaimLetter";
    public static final String EMAIL_TRACKER = "EmailTracker";
    public static final String PROPOSAL_POLIS = "ProposalPolisReport";
    public static final String CANCEL_POLIS = "CancelPolisReport";
    public static final String IPLUS_NTU_INT_REPORT = "IplusNtuReport";
    public static final String CLAIM_PRE_REG = "ClaimPreRegistration";
    public static final String BI_LAPORAN = "BILaporan";
    public static final String APE_REPORT = "ApeReport";
    public static final String RENOVA = "RenovaTemplate";
    public static final String BI_NEW_POLICY = "BiNewPolicy";
    public static final String BI_PIF = "BiPIF";
    public static final String BI_DELIVERY_OF_POLICY = "BiDeliveryOfPolicy";
    public static final String BI_CANCELATION_OF_POLICY = "BiCancelationOfPolicy";
    public static final String BI_REFUND = "BiRefund";
    public static final String BI_CLAIM = "BiClaim";
    public static final String AOL_USER_LOGIN_COUNT_REPORT = "AolUserPermataLoginDetail";
    public static final String BILLING_DETAIL = "BillingDetail";
    
    public static final String PARAM_START_DATE = "startdate";
    public static final String PARAM_END_DATE = "enddate";
    public static final String PARAM_POL_TYPE = "policy_type";
    public static final String PARAM_POL_NO = "policy_no";
    public static final String PARAM_MEMBER_NO = "member_no";
    public static final String PARAM_DPNT_NO = "dpnt_no";
    public static final String PARAM_EFF_DATE = "eff_date";
    public static final String PARAM_TR_DATE = "trdate";
    public static final String PARAM_ISS_DATE = "issdate";
    public static final String PARAM_MONTH = "month";
    public static final String PARAM_YEAR_MONTH = "yearMonth";
    public static final String PARAM_YEAR = "year";
    public static final String PARAM_REPRINT = "reprint";
    public static final String PARAM_BILLNO = "billNo";
    public static final String PARAM_CONTRACT_TYPE = "contractType";

    public static final String IPLUS_NTU_EMAIL = "IPLUS_NTU_EMAIL";
    public static final String IPLUS_NTU_EMAIL_IN = "IPLUS_NTU_EMAIL_IN";
    
    public static final String IPLUS_NTU_PROP_FILENAME = "Data_Polis_";
    public static final String IPLUS_NTU_CANCEL_FILENAME = "Data_CancelPolis_NTU_";
    public static final String IPLUS_NTU_PROP_FIRST_FILENAME = "First_Data_Polis_";
    public static final String IPLUS_NTU_CANCEL_FIRST_FILENAME = "First_Data_CancelPolis_NTU_";
    public static final String IPLUS_NTU_INTERNAL_FILENAME = "Generate_Send_Email_Report_";
    
    public static final String AOL_LOGIN_COUNT_EMAIL = "AOL_LOGIN_COUNT_EMAIL";
    public static final String AOL_LOGIN_COUNT_EMAIL_CC = "AOL_LOGIN_COUNT_EMAIL_CC";
    
    private OperationConstant() {
        throw new IllegalAccessError("Constant Class");
    }
}
