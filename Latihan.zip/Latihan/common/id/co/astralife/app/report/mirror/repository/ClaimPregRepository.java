package id.co.astralife.app.report.mirror.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.mirror.entity.ClaimPreg;

public interface ClaimPregRepository extends JpaRepository<ClaimPreg, String>{

	@Query(nativeQuery = true)
	List<ClaimPreg> findClaimPregByReceivedDateBetween(String startDate, String endDate);
	
}
