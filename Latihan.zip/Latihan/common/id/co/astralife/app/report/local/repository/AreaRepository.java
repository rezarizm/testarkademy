package id.co.astralife.app.report.local.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.Area;

public interface AreaRepository extends JpaRepository<Area, String>{
	
	Area findFirstByAreaCode(String areaCode);
	
	List<Area> findByProvince(String province);
	
	Area findFirstByProvinceAndCity(String province, String city);

}
