package id.co.astralife.app.report.mirror.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.ReportConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries({
	@NamedNativeQuery(name="BiReport.findBiReprintData", query=ReportConstant.BI_REPORT_FOR_IB_REPRINT, resultClass=BiReport.class),
	@NamedNativeQuery(name="BiReport.findBiPolicyReprintData", query=ReportConstant.BI_REPORT_FOR_IB_POLICY_REPRINT, resultClass=BiReport.class),
	@NamedNativeQuery(name="BiReport.findBiData", query=ReportConstant.BI_REPORT_FOR_IB, resultClass=BiReport.class),
	@NamedNativeQuery(name="BiReport.findBiPolicyData", query=ReportConstant.BI_REPORT_FOR_IB_POLICY, resultClass=BiReport.class)
})
@Table(name="F_GET_BI_FOR_IB_POLICY_REPRINT")
public class BiReport {

	@Column(name="bulan")
	private String bulan;
	
	@Column(name="periode")
	private String periode;
	
	@Column(name="nama_produk")
	private String namaProduk;
	
	@Column(name="jumlah_polis")
	private Integer jumlahPolis;
	
	@Column(name="jumlah_nasabah")
	private Integer jumlahNasabah;
	
	@Column(name="akumulasi")
	private BigDecimal akumulasi;
	
	@Column(name="bulan_laporan")
	private BigDecimal bulanLaporan;
	
	@Column(name="jenis_model_bisnis")
	private String jenisModelBisnis;
	
	@Column(name="total_pertanggungan")
	private BigDecimal totalPertanggungan;
	
	@Id
	@Column(name="policy_no")
	private String policyNo;
}
