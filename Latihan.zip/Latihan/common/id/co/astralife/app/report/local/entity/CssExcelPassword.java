package id.co.astralife.app.report.local.entity;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Data
@Entity
@Table(name = "CSS_EXCEL_PASSWORD")
public class CssExcelPassword implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@GeneratedValue(generator = "uuid")
	@Column(name = "ID", nullable = false)
	private UUID id;

	@Column(name = "PASSWORD", nullable = false)
	private String password;

	@Column(name = "EFFECTIVE_DATE")
	private Date effectiveDate;

	@Column(name = "CREATE_BY")
	private String createBy;

	@Setter(AccessLevel.NONE)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATE")
	private Date createDate;

	@Column(name = "MODIFY_BY")
	private String modifyBy;

	@Setter(AccessLevel.NONE)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "MODIFY_DATE")
	private Date modifyDate;

	@Column(name = "RECIPIENT_ID", nullable = false)
	private UUID cssRecipientId;
}
