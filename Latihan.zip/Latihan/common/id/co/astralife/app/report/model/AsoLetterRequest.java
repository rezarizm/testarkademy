package id.co.astralife.app.report.model;

import id.co.astralife.app.report.validator.annotation.PolicyNo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AsoLetterRequest {

  @PolicyNo
  private String policyNo;
  private String user;
  private Boolean email = false;
  
}
