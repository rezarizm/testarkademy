package id.co.astralife.app.report.mirror.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.mirror.entity.OutstandingExcess;

public interface OutstandingExcessRepository extends JpaRepository<OutstandingExcess, String>{
	
}
