package id.co.astralife.app.report.common;

public class BillingDetailConstant {

    public static final String QUERY_BILLING_DETAIL_LIST_BILLNO = "SELECT * FROM TABLE(PKG_BILLING_DETAIL.GET_BILLING_DETAIL_TRIGGER(?1, ?2, ?3))";

    private BillingDetailConstant () {
    	throw new IllegalAccessError("Constant Class");
    }
}
