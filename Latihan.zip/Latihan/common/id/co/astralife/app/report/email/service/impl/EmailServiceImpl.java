package id.co.astralife.app.report.email.service.impl;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import id.co.astralife.app.report.common.EmailConstant;
import id.co.astralife.app.report.common.ReportConstant;
import id.co.astralife.app.report.common.util.EmailUtil;
import id.co.astralife.app.report.email.service.EmailService;
import id.co.astralife.app.report.local.entity.AttachDetail;
import id.co.astralife.app.report.local.entity.Email;
import id.co.astralife.app.report.local.repository.AttachDetailRepository;
import id.co.astralife.app.report.local.repository.EmailRepository;
import id.co.astralife.app.report.model.EmailEntity;

@Service
public class EmailServiceImpl implements EmailService{

	public static final Logger LOGGER = LoggerFactory.getLogger(EmailServiceImpl.class);
	
	private final EmailRepository emailRepository;
	private final Environment env;
	private final AttachDetailRepository attachDetailRepository;
	
	@Autowired
	public EmailServiceImpl(EmailRepository emailRepository, Environment env,
			AttachDetailRepository attachDetailRepository) {
		this.emailRepository = emailRepository;
		this.env = env;
		this.attachDetailRepository = attachDetailRepository;
	}
	
	@Override
	public Email findByEmailId(UUID emailId) {
		return emailRepository.findByEmailId(emailId);
	}

	@Override
	public void save(Email email) {
		this.emailRepository.save(email);
	}
	
	@Override
	public void save(List<Email> emails) {
		this.emailRepository.save(emails);
	}

	@Override
	public void emailScheduler(String user) {
		List<Email> emails = emailRepository.findByStatusAndYgEmail(ReportConstant.PROCESSING, EmailConstant.EMAIL);
		List<Email> newEmails = new ArrayList<>();
		if (!emails.isEmpty()) {
			for(Email email : emails) {
				List<AttachDetail> attachDetails = attachDetailRepository.findByEmailId(email.getEmailId());
				EmailEntity<String> emailEntity = EmailUtil.getEmailEntity(email, attachDetails);
				if (emailEntity != null) {
					Email newEmail = this.sendEmail(emailEntity, email, user);
					newEmails.add(newEmail);
				} else {
					email.setStatus(ReportConstant.FAILED);
					email.setModifyBy(user);
					newEmails.add(email);
				}
			}
		}
		this.save(newEmails);
		LOGGER.info("Total Email:{}", newEmails.size());
	}

	@Override
	public Email sendEmail(EmailEntity<String> emailEntity, Email email, String user) {
		
		ObjectMapper mapper = new ObjectMapper();
		String dataString = "";
		try {
			dataString = mapper.writeValueAsString(emailEntity);
		} catch (JsonProcessingException e) {
			LOGGER.error("Json Processing Exception" + e.getMessage(), e);
		}
		ResponseEntity<String> responseEntity = EmailUtil.postForEntity(env.getProperty("email-integration.email"), dataString);
		if(responseEntity.getStatusCode().is2xxSuccessful()){
			LOGGER.info("Response Entity, response:{}, body: {}", responseEntity, dataString);
			email.setStatus(ReportConstant.COMPLETE);
			email.setModifyBy(user);
		} else {
 			email.setStatus(ReportConstant.ERROR);
 			email.setModifyBy(user);
 		}
		return email;
	}

	@Override
	public String render(String template, Map<String, String> params) {
		String emailTemplate;
		for (Entry<String, String> param : params.entrySet()){
			template = template.replaceAll("\\{\\{"+param.getKey()+"\\}\\}", (param.getValue() == null ? "" : param.getValue()));
		}
		emailTemplate = template;
		return emailTemplate;
	}
	
	@Override
	public String renderByTemplate(String templatePath, String charset, Map<String, String> params) {
		StringBuilder sb = new StringBuilder();
		String template = "";
		try {
			List<String> contents = Files.readAllLines(Paths.get(templatePath), Charset.forName(charset));
			for (String content : contents) {
				sb.append(content);
			}
			template = this.render(sb.toString(), params);
		} catch (IOException e) {
			LOGGER.error("IOException: {}", e.getMessage());
		}
		return template;
	}

	@Override
	public Email findBySubjectAndCreateDateBetween(String subject, Date from, Date to) {
		return emailRepository.findFirstBySubjectAndCreateDateBetween(subject, from, to);
	}

	@Override
	public List<Email> findByEmailIdIn(Set<UUID> emailIds) {
		return emailRepository.findByEmailIdIn(emailIds);
	}
	
	@Override
	public List<Email> findByCreateDateBetween(Date startDate, Date endDate) {
		return emailRepository.findByCreateDateBetween(startDate, endDate);
	}

	@Override
	public List<Email> findByFromIdInAndCreateDateBetween(Set<String> fromIds, Date startDate, Date endDate) {
		return emailRepository.findByFromIdInAndCreateDateBetween(fromIds, startDate, endDate);
	}

	@Override
	public List<Email> findByReportIdInAndCreateDateBetween(Set<UUID> rptIds, Date startDate, Date endDate) {
		return emailRepository.findByReportIdInAndCreateDateBetween(rptIds, startDate, endDate);
	}
	
}