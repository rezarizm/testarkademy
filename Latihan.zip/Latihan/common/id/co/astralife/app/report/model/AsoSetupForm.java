package id.co.astralife.app.report.model;

import java.math.BigDecimal;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonProperty;
import id.co.astralife.app.report.validator.annotation.PolicyNo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AsoSetupForm {

    @JsonProperty("policyNo")
    @PolicyNo
    private String policyNo;

    @JsonProperty("threshold")
    @Digits(integer=2, fraction=2, message = "Please input valid number")
    @NotNull
    private BigDecimal threshold;

    @JsonProperty("createBy")
    private String createBy;
}
