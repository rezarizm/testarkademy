package id.co.astralife.app.report.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CashListForm {

	private String type;
	
    private String format;
    
    @NotNull
    @Size(min = 8, max = 8)
    private String startdate;
    
    @NotNull
    @Size(min = 8, max = 8)
    private String enddate;
}
