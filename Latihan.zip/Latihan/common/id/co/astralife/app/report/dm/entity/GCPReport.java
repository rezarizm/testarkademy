package id.co.astralife.app.report.dm.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.GuaranteedCashPaymentConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries(@NamedNativeQuery(name = "GCPReport.countData", query = GuaranteedCashPaymentConstant.GUARANTEED_CASH_PAYMENT_DATA_COUNT, resultClass = GCPReport.class))
@Table(name = "IPCONTRACT")
public class GCPReport {
	
	@Id
	@Column(name = "COUNT_DATA")
	private Long countData;

}
