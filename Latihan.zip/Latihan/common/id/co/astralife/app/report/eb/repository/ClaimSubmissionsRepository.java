package id.co.astralife.app.report.eb.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.eb.entity.ClaimSubmissions;

public interface ClaimSubmissionsRepository extends JpaRepository<ClaimSubmissions, String> {

   List<ClaimSubmissions> findByExported(Long exported);

   List<ClaimSubmissions> findByExportedOrderBySubmittedAtAsc(Long exported);

}
