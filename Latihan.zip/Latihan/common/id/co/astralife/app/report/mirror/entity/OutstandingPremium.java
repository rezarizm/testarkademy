package id.co.astralife.app.report.mirror.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "V_RPT_OUTS_PREM")
public class OutstandingPremium {
	
	@Id
    @Column(name = "AGENT_NO")
    private String agentNo;
	
	@Column(name = "COMPANY_NAME")
    private String companyName;
	
	@Column(name = "TOTAL_OUTS_PREM")
    private BigDecimal totalOutsPrem;
	
}
