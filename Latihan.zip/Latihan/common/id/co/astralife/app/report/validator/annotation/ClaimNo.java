package id.co.astralife.app.report.validator.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import id.co.astralife.app.report.validator.ClaimNoValidator;

@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = ClaimNoValidator.class)
public @interface ClaimNo {
	
	String message() default "Claim No is not valid";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
