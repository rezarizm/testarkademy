package id.co.astralife.app.report.iplus.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.SalesSupportConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries(@NamedNativeQuery(name = "AstraCoop.countDataByDate", query = SalesSupportConstant.ASTRA_COOP_CERT_GET_BY_DATE, resultClass = AstraCoop.class))
@Table(name = "CONTRACT")
public class AstraCoop {
	
	@Id
	@Column(name = "COUNT_DATA")
	private Long countData;

}
