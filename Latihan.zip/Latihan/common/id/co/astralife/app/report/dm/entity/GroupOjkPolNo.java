package id.co.astralife.app.report.dm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.OjkConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries(@NamedNativeQuery(name = "GroupOjkPolNo.findPolicyNoByTransRef", query = OjkConstant.GROUP_OJK_POLNO_QUERY, resultClass = GroupOjkPolNo.class))
@Table(name = "GARTRNPF")
public class GroupOjkPolNo implements Serializable {

	private static final long serialVersionUID = -1728268262208721407L;

	@Id
	@Column(name = "CHDRNUM")
	private String policyNo;

}
