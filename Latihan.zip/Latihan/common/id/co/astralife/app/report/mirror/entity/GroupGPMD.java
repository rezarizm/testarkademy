package id.co.astralife.app.report.mirror.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author fadil.wiranata
 */
@Entity
@Table(name = "GAGPMDPF")
@NamedNativeQueries({
        @NamedNativeQuery(name = "GroupGPMD.maxTranNoByPolicyNoAndMbrNoAndDpntNo",
                query = "select max(gpmd.TRANNO) as TRANNO from GAGPMDPF gpmd where gpmd.CHDRNUM=?1 and gpmd.MBRNO=?2 and gpmd.DPNTNO=?3 group by gpmd.CHDRNUM, gpmd.MBRNO, gpmd.DPNTNO")
})
public class GroupGPMD implements Serializable {

	private static final long serialVersionUID = 2902242287985013405L;

	@Id
    @Column(name = "CHDRCOY")
    private String chdrCoy;

    @Id
    @Column(name = "CHDRNUM")
    private String chdrNum;

    @Id
    @Column(name = "TRANNO")
    private String tranNo;

    @Id
    @Column(name = "BILLNO")
    private String billNo;

    @Column(name = "PEMXTPRM")
    private BigDecimal pPrem;

    @Id
    @Column(name = "PRODTYP")
    private String prodTyp;

    @Id
    @Column(name = "PLANNO")
    private String planNo;

    @Id
    @Column(name = "PEMXTPRM")
    private BigDecimal pemXtPrm;

    @Column(name = "MBRNO")
    private String mbrNo;

    @Column(name = "DPNTNO")
    private String dpntNo;

    @Column(name = "EFFDATE")
    private String effDate;

    @Id
    @Column(name = "PRMFRDT")
    private String prmFrDt;

    @Id
    @Column(name = "PRMTODT")
    private String prmToDt;
}
