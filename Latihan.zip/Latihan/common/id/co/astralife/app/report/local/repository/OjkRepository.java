package id.co.astralife.app.report.local.repository;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import id.co.astralife.app.report.local.entity.Ojk;

public interface OjkRepository extends JpaRepository<Ojk, UUID>{
	
	Long countByCreateDateBetween(Date from, Date to);

	Long countByFrequencyAndCreateDateBetween(String freq, Date from, Date to);
	
	List<Ojk> findByFrequencyAndCreateDateBetween(String freq, Date from, Date to);
	
	List<Ojk> findByCategoryAndSubCategoryAndStatusAndCreateDateBetween(String category, String subCategory, String status, Date from, Date to);
	
	List<Ojk> findByFrequencyAndStatusAndCreateDateBetween(String freq, String status, Date from, Date to);
	
	List<Ojk> findByStatusAndCreateDateBetween(String status, Date from, Date to);
	
	Long countByFrequencyAndStatusAndCreateDateBetween(String freq, String status, Date from, Date to);
	
	List<Ojk> findByPolicyNoAndStatusAndCreateDateBetween(String policyNo, String status, Date from, Date to);
	
	@Transactional
	void deleteByOjkIdIn(Set<UUID> ojkIds);
	
}
