package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GroupPolicyForm {

	String type;
	String policyNo;
	String tranNo;
	String startDate;
	String endDate;
	Boolean policyCertificate;
	Boolean benefitSchedule;
	Boolean premiumSchedule;
	Boolean globalProvisions;
	Boolean duplicate;
}
