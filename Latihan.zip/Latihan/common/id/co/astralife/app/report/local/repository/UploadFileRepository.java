package id.co.astralife.app.report.local.repository;

import java.util.Date;
import java.util.Set;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import id.co.astralife.app.report.local.entity.UploadFile;

public interface UploadFileRepository extends JpaRepository<UploadFile, UUID>{

	Long countByRptTypeAndDescAndStatusInAndCreateDateBetweenAndIsScheduler(String rptType, String desc, Set<String> status, Date from, Date to, boolean isScheduler);
	
	Long countByRptTypeAndStatusAndCreateDateBetweenAndIsScheduler(String rptType, String status, Date from, Date to, boolean isScheduler);
	
	UploadFile findFirstByRptTypeAndDescAndStatusAndCreateDateBetweenAndIsScheduler(String rptType, String desc, String status, Date from, Date to, boolean isScheduler);
	
}
