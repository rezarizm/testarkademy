package id.co.astralife.app.report.common;

public class ClaimReportGasiaConstant {

	public static final String CLAIM_PAID_REPORT = "ClaimPaidReport";
	public static final String CLAIM_PAYABLE_REPORT = "ClaimPayableReport";
	
	/**
	 * @param START_DATE <yyyyMMdd>
	 * @param END_DATE <yyyyMMdd>
	 */
	public static final String COUNT_CLAIM_PAID = "SELECT COUNT(POLICY_NO) FROM TABLE(PKG_CLAIM_PAID_PAYABLE.GET_CLAIM_PAID(?1, ?2))";
	public static final String COUNT_CLAIM_PAYABLE = "SELECT COUNT(POLICY_NO) FROM TABLE(PKG_CLAIM_PAID_PAYABLE.GET_CLAIM_PAYABLE(?1, ?2))";
	
	private ClaimReportGasiaConstant() {
		throw new IllegalAccessError("ClaimReportGasiaConstant Class");
	}
}
