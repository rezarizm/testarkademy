package id.co.astralife.app.report.common.util.exception;

@SuppressWarnings("serial")
public class FTPServiceException extends Exception {
    public FTPServiceException() {
    }

    public FTPServiceException(String message) {
        super(message);
    }

    public FTPServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public FTPServiceException(Throwable cause) {
        super(cause);
    }

    public FTPServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
