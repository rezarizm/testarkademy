package id.co.astralife.app.report.dm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.OjkConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries({@NamedNativeQuery(name = "AsliOjkClient.findAsliByPolicyNoAndIsValid", query = OjkConstant.ASLI_OJK_CLIENT_QUERY, resultClass = AsliOjkClient.class),
	@NamedNativeQuery(name = "AsliOjkClient.findAsliByPolicyNo", query = OjkConstant.ASLI_OJK_CLIENT_QUERY_BY_POLNO, resultClass = AsliOjkClient.class)
})
@Table(name = "IPCONTRACT")
public class AsliOjkClient implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2456027218234239428L;

	@Id
	@Column(name = "POLICY_NO")
	private String policyNo;

	@Column(name = "ID_NO")
	private String idNumber;

	@Column(name = "DOB")
	private String dob;

	@Column(name = "IS_VALID")
	private boolean isValid;

	@Column(name = "ADDRESS01")
	private String address01;

	@Column(name = "ADDRESS02")
	private String address02;

	@Column(name = "ADDRESS03")
	private String address03;

}
