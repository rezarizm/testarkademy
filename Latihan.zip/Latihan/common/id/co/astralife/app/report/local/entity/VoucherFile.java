package id.co.astralife.app.report.local.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.Data;

@Data
@Entity
@Table(name = "RPT_VOUCHER_FILE")
public class VoucherFile {
	
	@Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
	@Column(name="FILE_ID")
	private UUID fileId;

	@Column(name="FILE_NAME")
	private String fileName;

	
	@Column(name="LAST_STATUS")
	private String lastStatus;
	
	@Column(name="LAST_MESSAGE")
	private String lastMessage;
}
