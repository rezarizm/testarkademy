package id.co.astralife.app.report.local.repository;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.local.entity.Config;

public interface ConfigRepository extends JpaRepository<Config, UUID> {
	
	Config findByConfigName(String configName);
	
	@Query("select c from Config c where c.configName = ?1")
	List<Config> findData(String configName);
	
	Config findFirstByConfigNameAndConfigValue(String configName, String configValue);
	
	Config findFirstByConfigName(String configName);
	
	@Query(nativeQuery = true)
	List<Config> findAllNextConfigValueByConfigName(String configName, Long valueNum);
	
	@Query(nativeQuery = true)
	List<Config> findByConfigNameAndRowBetween(String configName, Long start, Long end);
	
	List<Config> findByConfigNameIn(Set<String> configName);
}
