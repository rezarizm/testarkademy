package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssReportDeliveryTemplateRelView;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface CssReportDeliveryTemplateRelRepository extends JpaRepository<CssReportDeliveryTemplateRelView, UUID> {
    List<CssReportDeliveryTemplateRelView> findAllByCssDeliveryGroupId(String cssDeliveryGroupId);
}
