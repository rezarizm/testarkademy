package id.co.astralife.app.report.local.entity;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Entity
@Data
@Table(name = "RPT_REPORT")
public class Report extends BaseEntity {

    private static final long serialVersionUID = -3482651447710632085L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "RPT_ID", nullable = false)
    private UUID reportId;

    @Column(name = "RPT_NAME")
    private String rptName;

    @Column(name = "RPT_DESC")
    private String rptDesc;

    @Column(name = "TEMPLATE")
    private String template;

    @Column(name = "SCHEDULE")
    private String schedule;

    @Column(name = "FORMAT")
    private String format;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "CREATE_BY")
    private String createBy;

    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;
}
