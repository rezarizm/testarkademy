package id.co.astralife.app.report.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OjkRequest {

	private String startDate;
	private String endDate;
	private String sheetName;
	private String user;
	private String breakTime;
	private Integer countHit;
	private List<String> ojkIds;
	private String rptFreq;
	
	// save file service
	private List<String> sheetNames;
	private String filePath;
	
	
}
