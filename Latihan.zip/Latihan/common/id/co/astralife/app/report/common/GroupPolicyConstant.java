package id.co.astralife.app.report.common;

public class GroupPolicyConstant {
	
	public static final String GROUP_LIFE_POLICY = "GroupLifePolicy";
	
	// startDate = ?1 and endDate = ?2
	public static final String DATA_BY_DATE = "select * from table(pkg_grp_lf_policy.get_by_date(?1,?2))";
	// policyNo = ?1 and tranNo = ?2
	public static final String DATA_BY_POLICY = "select * from table(pkg_grp_lf_policy.get_by_policy(?1,?2))";
	// policyNo = ?1 and tranNo = ?2
	public static final String GET_NEXT_ROW = "select * from table(pkg_grp_lf_policy.get_nextrow(?1,?2))";
	// policyNo = ?1 and id = ?2 
	public static final String CHECK_REVERSED = "select * from table(pkg_grp_lf_policy.get_check_reversed(?1,?2))";
	
	public static final String PARAM_POL_NO = "pol_no";
	public static final String PARAM_TRAN_NO = "tran_no";
	public static final String PARAM_CNT_TYPE = "cnt_type";
	public static final String PARAM_PRINT_PC = "show_pc";
	public static final String PARAM_PRINT_BS = "show_bs";
	public static final String PARAM_PRINT_PS = "show_ps";
	public static final String PARAM_PRINT_GP = "show_gp";
	public static final String PARAM_REPRINT = "reprint";
	
	private GroupPolicyConstant(){
		throw new IllegalAccessError("Constant Class");
	}
}