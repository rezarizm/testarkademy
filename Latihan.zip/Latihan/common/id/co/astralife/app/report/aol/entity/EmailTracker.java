package id.co.astralife.app.report.aol.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

@Entity
@Data
@Table(name = "EG_EMAIL_TRACKER")
public class EmailTracker {
	
	@Id
	@Column(name  = "TRACKER_ID")
	private UUID trackerId;
	
	@Column(name = "CONTRACT_NO")
	private String contractNo;

	@Column(name = "SENDER")
	private String sender;
	
	@Column(name = "RECEIVER")
	private String receiver;
	
	@Column(name = "SUBJECT")
	private String subject;
	
	@Column(name = "IS_ERROR")
	private String isError;
	
	@Column(name = "IS_BOUNCE")
	private String isBounce;
	
	@Setter(AccessLevel.NONE)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATE")
	private Date createDate;
}
