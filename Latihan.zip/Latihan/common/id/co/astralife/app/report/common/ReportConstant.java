package id.co.astralife.app.report.common;

/**
 * @author fadil.wiranata
 */
public interface ReportConstant {

    String PROCESSING = "P";
    String COMPLETE = "C";
    String FAILED = "F";
    String ERROR = "ERR";
    
    String MONTHLY = "M";
    String DAILY = "D";
    String WEEKLY = "W";
    String PDF = "PDF";
    String XLS = "XLS";
    String CSV = "CSV";
    String TXT = "TXT";
    String ZIP = "ZIP";
    String TANGO = "TANGO";
	String POI = "POI";

    String CUR_IDR = "IDR";
    String CUR_USD = "USD";

    String SRC_BR = "BR";
    String SRC_IA = "IA";
    String SRC_DI = "DI";
    
    String STCB_DIR = "DIR";
    String STCB_AGT = "AGT";
    String STCB_BRO = "BRO";
    String STCB_IAG = "IAG";
    
    String POLICY_TYPE_GNL = "GNL";
    String POLICY_TYPE_GPA = "GPA";

    String FILENAME_PARAM = "fileName";
    String FILENAME_PREFIX = "prefix";
    String FILENAME_SUFFIX = "suffix";
    String FILEPATH_PARAM = "filePath";
	String FILEQUERY_PARAM = "FileQuery";

    String DATASOURCE = "datasource";
    String DATASOURCE_IPLUS = "iplus";
    String DATASOURCE_AOL = "aol";
    String DATASOURCE_VMS = "vms";
    String DATASOURCE_LOCAL = "local";
    String DATASOURCE_VIT = "vit";
    String DATASOURCE_ODSRPT = "odsrpt";
    String DATASOURCE_DM = "dm";
    
    String PATH_OUTPUT = "pathOutput";
    String IS_VISIBLE = "is_visible";
    
    String MINDSTORE_FOLDER = "mindstore";
    String APPBUDDIES_FOLDER = "appbuddies";
    String INCOMING_FOLDER = "incoming";
    
    String FULL_PENDING = "RMFULLCP";
    String PARTIAL_PENDING = "RMICOMRJ";
    String FULL_REJECT = "RMFULLRJ";
    String PARTIAL_REJECT = "RMPARTRJ";
    String INVESTIGATION  = "RMINVNCP";
    String FULL_PAYMENT = "RMFULLPY";
    
    String ZIP_COMP = "zip_comp";
    String ZIP_PASS = "zip_pass";
    String XLS_PASS = "xls_pass";
    
    String PDFA_1A = "pdfa1a";
    String ICC_FILE_NAME = "srgb.icc";
    String LOGO_FILENAME = "logo.png";
    
    String PRINT = "Y";
    String NO_PRINT = "N";
    
    String ASYNC = "async";
    
    String FINANCE_JOBS = "financeJobs";
    String OPERATION_JOBS = "operationJobs";
    String ACTUARY_JOBS = "actuaryJobs";
    String CSS_JOBS = "salesSupportJobs";
    String EMAIL_JOBS = "emailJobs";
    String IB_JOBS = "ibJobs";
    
    String PAGE_TITLE = "pageTitle";
    String FORM = "form";
    String SUCCESS = "success";
    String ERROR_MESSAGE = "errorMessage";
    String SUCCESS_MESSAGE = "successMessage";
    
    String FIELD_DELIMITER = "fieldDelimiter";
    String DELIMITER_PIPE = " | ";
    String DELIMITER_COMMA = " , ";
    String CSV_FIELD_ENCLOSURE = "CSV_FIELD_ENCLOSURE";
    String DOUBLE_QUOTE = "\"";
    
    String MENU_QUERY = "SELECT DISTINCT menu.* FROM RPT_MENU menu " +
            "INNER JOIN RPT_MENU_FUNCTION mfunc ON mfunc.MENU_ID = menu.MENU_ID " +
            "INNER JOIN RPT_FUNCTION func ON func.FUNC_ID = mfunc.FUNC_ID " +
            "INNER JOIN RPT_FUNCTION_ROLE frole ON frole.FUNC_ID = func.FUNC_ID " +
            "INNER JOIN RPT_ROLE rrole ON rrole.ROLE_ID = frole.ROLE_ID " +
            "WHERE rrole.ROLE_ID IN (SELECT urole.ROLE_ID FROM RPT_USER_ROLE urole INNER JOIN RPT_USER ruser ON ruser.USER_ID = urole.USER_ID WHERE ruser.USER_ID = ?1) " +
            "ORDER BY menu.SEQUENCE";
    
    String REPORT_FILE_QUERY = 
            "select file_id, rpt_id, file_name, folder_path, status, create_by, create_date, modify_by, modify_date from rpt_report_file reportFile where "+
            "reportFile.rpt_id in ( "+
            "  select rpt_id from rpt_role_report "+
            "  where role_id in ( "+
            "    select role_id from rpt_user_role "+
            "    where user_id = ( "+
            "      select user_id from rpt_user where login_id = ?1 "+
            "    ) "+
            "  ) "+
            ") "+
            "and "+
            "create_by in (?2, ?3)";
    
    String YERF_PERIOD_QUERY = "select chdrnum, min(ccdate) ccdate, max(crdate) crdate from ( \n" +
    		"  select rownum, chdrnum, ccdate, crdate from ( \n" +
    		"    select distinct chdrnum, ccdate, crdate from gayerfpf \n" +
    		"    where ccdate < to_char(sysdate,'yyyymmdd') \n" +
    		"    and chdrnum = ?1 \n" +
    		"    order by chdrnum, ccdate desc \n" +
    		"  ) where rownum <= 3 \n" +
    		") group by chdrnum";
    
    String SEHAT_PROTEKSIKU_QUERY = " select count(*) count_data " +
    		" from contract contract " +
    		" inner join product_eligibility prod_elig on contract.fk_product_eligibility = prod_elig.pk_product_eligibility " +
    		" inner join product product on prod_elig.fk_product = product.pk_product and product.code = 'ASP' " +
    		" left join contract_life_assured cont_la on contract.pk_contract = cont_la.fk_contract " +
    		" left join party party on cont_la.fk_party = party.pk_party " +
    		" left join person person on party.pk_party = person.pk_person " +
    		" left join party party_holder on contract.fk_party_owner = party_holder.pk_party " +
    		" left join party party_hol_val on party_holder.code = party_hol_val.code " +
    		" 								 and party_hol_val.valid = 1 " +
    		" left join contract_dispatch_address cont_disp_addr on contract.pk_contract = cont_disp_addr.fk_contract " +
    		" left join party_address party_add_patch on cont_disp_addr.fk_party_address = party_add_patch.pk_party_address " +
    		" left join (select pa.* from ( " +
    		" 		  select max(creation_time) creation_time, fk_party, valid " +
    		" 		  from party_address " +
    		" 		  where fk_lookup_address_type in (select pk_lookup fk_lookup_address_type " +
    		" 										   from lookup where lookup_group = 'ADDRESS_TYPE') " +
    		" 		  and valid = 1 " +
    		" 		  group by fk_party, valid " +
    		" 		  ) pa_max " +
    		" 		  inner join party_address pa on pa_max.fk_party = pa.fk_party " +
    		" 									  and pa_max.valid = pa.valid " +
    		" 									  and pa_max.creation_time = pa.creation_time " +
    		" 		  ) party_add on party_hol_val.pk_party = party_add.fk_party " +
    		" inner join person person_holder on party_holder.pk_party = person_holder.pk_person " +
    		" inner join contract_structure cont_struct on contract.pk_contract = cont_struct.fk_contract " +
    		" 											 and cont_struct.annual_premium <> 0 " +
    		" 											 and cont_struct.valid = 1 " +
    		" inner join component component on cont_struct.component_code = component.code " +
    		" left join contract_reference_no cont_ref on contract.pk_contract = cont_ref.fk_contract " +
    		" 											and cont_ref.fk_lookup_reference_type in " +
    		" 													  (select pk_lookup fk_lookup_reference_type " +
    		" 													   from lookup where code  = '1' " +
    		" 													   and lookup_group = 'REFERENCE_TYPE') " +
    		" left join lookup lookup on prod_elig.fk_lookup_currency = lookup.pk_lookup and " +
    		" 							lookup.lookup_group = 'CURRENCY' and " +
    		" 							lookup.code = 'IDR' " +
    		" left join lookup lookup_gender on lookup_gender.lookup_group = 'GENDER' " +
    		" 								  and lookup_gender.code in ('M', 'F') " +
    		" 								  and person_holder.fk_lookup_gender = lookup_gender.pk_lookup " +
    		" inner join contract_history cont_hist on contract.pk_contract = cont_hist.fk_contract " +
    		" 										 and cont_hist.fk_lookup_transaction_code in " +
    		" 											 (select pk_lookup fk_lookup_transaction_code from lookup " +
    		" 											 where lookup_group = 'AFTER_SALES_SERVICE_TYPE' " +
    		" 											 and code = 'T642') " +
    		" 										 and cont_hist.is_active = 1 " +
    		" where to_char(cont_hist.action_date, 'dd/mm/yyyy') = ?1  ";
    
    String CLAIM_LETTER_LETC = "select * from table(pkg_claim_letter.get_main_claim(?1,?2,?3,?4,?5))";
    
    String CLAIM_LETTER_PKG_CLAIM = " select													" + 				
									" claim.clamnum||claim.gcoccno clamnum_occno,				" +
									" ?2 lettype,												" +
									" ' ' origin_lettype,										" +
									" ' ' lreqdate,												" +
									" claim.*,													" +
									" 0 count_print,											" +
									" 0 count_zz5,												" +
									" 0 count_corr_dt											" +
									" from table(pkg_claim_letter.get_claim(?1,?2,?3,?4)) claim ";
    
    String CLAIM_LETTER_GET_SUBJECT_EMAIL = "select f_get_ga_claim_subject_email(?1,?2,?3) subject_email from dual";
    
    String BI_REPORT_FOR_IB_REPRINT = " select * from table (F_GET_BI_FOR_IB_REPRINT(?1,?2)) ";

    String BI_REPORT_FOR_IB_POLICY_REPRINT = " select * from table (F_GET_BI_FOR_IB_POLICY_REPRINT(?1,?2,?3)) ";
    
    String BI_REPORT_FOR_IB = " select * from table (F_GET_BI_REPORT_FOR_IB(?1,?2)) ";
    
    String BI_REPORT_FOR_IB_POLICY = " select * from table (F_GET_BI_REPORT_FOR_IB_POLICY(?1,?2,?3)) ";
    
    // ?1 = month, ?2 = yearMonth
    String BI_REPORT_GROUP = "select count(*) count_data from table(pkg_bi_grp.get_rpt_sum(?1,?2))";
    
    // ?1 = start_dt, ?2 = end_dt
    String CLAIM_PREG = "select * from table(pkg_clm_prg.get_claim_preg(?1,?2))";
    
    // ?1 = ref_no, ?2 = pol_no, ?3 = mbr_no
    String CLAIM_PREG_EMAIL = "select * from table(pkg_clm_prg.get_clm_eml(?1,?2,?3))";
    
    String FIND_AOL_LOGIN_COUNT = "Select" +
    		"b.LOGIN_ID||ACTIVITY.\"MONTH\"||ACTIVITY.\"YEAR\"||b.LAST_LOGIN_DATE||count(*) as \"ID\"," +
    		"b.login_id," + 
    		"NVL(idm.surname,usr_internal.SURNAME) AS SURNAME," + 
    		"NVL(idm.zemailadd,usr_internal.EMAIL) AS EMAILADD," +
    		"\"ROLE\".DESCRIPTION AS TITLE," +
    		"BRANCH_CODE.LONGDESC AS BRANCH_NAME," +
    		"substr(b.login_id,0,3) AS BRANCH_CODE," +
    		"REGIONAL.zregncde AS REGIONAL," +
    		"AREA.zareacde as Area," +
    		"ACTIVITY.\"MONTH\"," +
    		"ACTIVITY.\"YEAR\"," +
    		"CASE" + 
    		"WHEN COUNT(*) = 1" +
    		"THEN 0" +
    		"WHEN COUNT(*) != 1" +
    		"THEN COUNT(*)" +
    		"END AS NUMBER_OF_LOGIN," +
    		"MAX(ACTIVITY.ACTIVITY_DATE) AS LAST_LOGIN_DATE," +
    		"b.CREATE_DATE as Creation_Date_In_AOL" +
    		"from vitdta.aol_user b" + 
    		"LEFT JOIN idmdta.ifsdmclntpf idm ON idm.clntnum = b.clntnum" +
    		"LEFT JOIN (SELECT USER_ID, TO_CHAR(TRANSACTION_TIME,'YYYY-MM-DD') AS ACTIVITY_DATE," +
    				"EXTRACT(DAY FROM AOL_AUDIT_TRAIL.TRANSACTION_TIME) \"DATE\"," + 
    				"EXTRACT(MONTH FROM AOL_AUDIT_TRAIL.TRANSACTION_TIME) \"MONTH\"," + 
    				"EXTRACT(YEAR FROM AOL_AUDIT_TRAIL.TRANSACTION_TIME) \"YEAR\"," +
    		"case" + 
    		"when EXTRACT(MONTH FROM AOL_AUDIT_TRAIL.TRANSACTION_TIME) in (1,2,3)" +
    		"then 'Q1'" +
    		"when EXTRACT(MONTH FROM AOL_AUDIT_TRAIL.TRANSACTION_TIME) in (4,5,6)" +
    		"then 'Q2'" +
    		"when EXTRACT(MONTH FROM AOL_AUDIT_TRAIL.TRANSACTION_TIME) in (7,8,9)" +
    		"then 'Q3'" +
    		"when EXTRACT(MONTH FROM AOL_AUDIT_TRAIL.TRANSACTION_TIME) in (10,11,12)" +
    		"then 'Q4'" +
    		"end Periode" +   
    		"FROM AOL_AUDIT_TRAIL" + 
    		"WHERE UPPER(TRANSACTION_TYPE) = 'LOGIN TO AAOL'" + 
    		"ORDER BY USER_ID, ACTIVITY_DATE) ACTIVITY ON ACTIVITY.USER_ID = b.LOGIN_ID" +
    		"LEFT JOIN (select longdesc, itemitem" + 
    				"from idmdta.ifsdmt9540" + 
    				"where itemcoy = '1') BRANCH_CODE ON trim(BRANCH_CODE.itemitem) = substr(b.login_id,0,3)" + 
    				"LEFT JOIN (select zregncde, itemitem" + 
    						"from idmdta.ifsdmt9540" + 
    						"where itemcoy = '1') REGIONAL ON trim(REGIONAL.itemitem) = substr(b.login_id,0,3)" +
    						"LEFT JOIN (select zareacde, itemitem" + 
    								"from idmdta.ifsdmt9540" + 
    								"where itemcoy = '1') AREA ON trim(AREA.itemitem) = substr(b.login_id,0,3)" +
    								"LEFT JOIN AOL_USER_INTERNAL usr_internal ON usr_internal.USER_ID = b.USER_ID" +
    								"LEFT JOIN AOL_USER_ROLE usr_role ON usr_role.USER_ID = usr_internal.USER_ID" +
    								"LEFT JOIN AOL_ROLE \"ROLE\" ON usr_role.ROLE_ID = \"ROLE\".ROLE_ID" +
    								"where trim(upper(idm.zemailadd)) like '%PERMATABANK%'" + 
    								"OR trim(upper(idm.zemailadd)) like '%ASTRA%'" +
    								"OR usr_role.ROLE_ID = 'PA'" +
    								"GROUP BY b.LOGIN_ID, idm.SURNAME, usr_internal.SURNAME, idm.ZEMAILADD, \"ROLE\".DESCRIPTION, usr_internal.EMAIL, BRANCH_CODE.LONGDESC, REGIONAL.zregncde, AREA.zareacde, b.LAST_LOGIN_DATE, b.CREATE_DATE, \"MONTH\", \"YEAR\"" +
    								"ORDER BY b.LOGIN_ID, ACTIVITY.\"YEAR\",ACTIVITY.\"MONTH\" ";

    String APE_REPORT_QUERY = "SELECT * FROM TABLE (PKG_APE_AUTO.GET_APE(?,?))";
    
    String EXPORT_CLAIM_COUNTREC = "select case when jml>0 then 1 else 0 end as jml from (" +
    							  "select count(*) as jml from table(pkg_export_claim.get_export_claim_header(?1,?2))) ";
}
