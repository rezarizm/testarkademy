package id.co.astralife.app.report.local.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.UserRole;

public interface UserRoleRepository extends JpaRepository<UserRole, String> {

	List<UserRole> getByUserId(UUID userId);

}
