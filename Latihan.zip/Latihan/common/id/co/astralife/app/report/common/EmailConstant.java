package id.co.astralife.app.report.common;

public class EmailConstant {

    public static final String EMAIL = "E";

    public static final String PARAM_EMAIL_FROM = "from_id";
    public static final String PARAM_YGEMAIL = "ygemail";
    public static final String PARAM_TO_ID = "to_ids";
    public static final String PARAM_CC_ID = "cc_ids";
    public static final String PARAM_BCC_ID = "bcc_ids";
    public static final String PARAM_SUBJECT = "subject";
    public static final String PARAM_CONTENT = "content";
    public static final String PARAM_ATTACH_NAME = "attachment_name";
    public static final String PARAM_FILEPATH = "filepath";
    public static final String PARAM_CONTENT_ID = "content_id";
    public static final String PARAM_CONTENT_PATH = "content_path";
    public static final String PARAM_CONTENT_TYPE = "content_type";

    // set is_visible = true as param if a file should be displayed in file menu
    public static final String IS_VISIBLE = "is_visible";
    
    public static final String EMAIL_SENDER_NO_REPLY = "no-reply@astralife.co.id";
    public static final String EMAIL_SALUTATION = "Dear Bapak/Ibu, <br/><br/>";
    public static final String EMAIL_REGARDS = "<font color=#1f497d>Best Regards,<br/><strong>Astra Life</strong><br/><br/></font>";

    // Claim Letter
    public static final String EMAIL_HELLO_AL = "hello@astralife.co.id";
    public static final String EMAIL_GROUP_CLAIM = "group.claims@astralife.co.id";
    public static final String CONTENT_CLAIM = "Dear Customer, <br/><br/>"
            + "Please find enclosed the claim letter processed. <br/><br/>"
            + "Thank you for your attention. <br/><br/>"
            + "If you still have any queries please do not hesitate to call Hello Astra Life at 1 500 AVA (282)/Fax (021)29124020, or email hello@astralife.co.id <br/><br/>"
            + "<br/><br/>"
            + "Best Regards <br/><br/>"
            + "PT ASTRA AVIVA LIFE";

    // Tax Amnesty
    public static final String EMAIL_FROM_TAX_AMNESTY = "no-reply@astralife.co.id";
    public static final String CONTENT_TAX_AMNESTY = "Dear Pak Adang, <br/><br/>"
            + "Terlampir kami kirimkan Daily Report AVA iPrime Khusus. <br/><br/>"
            + "Terima kasih, <br/><br/>"
            + "PT Astra Aviva Life";

    // Proposal & Cancel
    public static final String EMAIL_FROM_IPLUS_NTU = "no-reply@astralife.co.id";
    public static final String DEAR_CONTENT_IPLUS_NTU = "Dear Bapak/Ibu, <br/><br/>";
    public static final String REGARDS_IPLUS_NTU = "<font color=#1f497d>Best Regards,<br/><strong>Astra Life</strong><br/><br/></font>";
    public static final String SIGNATURE = "<font color=#1f497d>D: +62(21) 304 22000 | F: +62(21) 293 27979<br/><br/>"
    		+ "<strong>\"Kami ada, agar anda dapat mencintai hidup. Menikmati hari ini, berani bermimpi dan mewujudkannya.\" #LoveLife</strong><br/>"
    		+ "<i>\"We are here to help Indonesian to love life. Enjoy today, Dare to dream and Live the dream.\" #LoveLife</i><br/>"
    		+ "<img src=\"http://astralife.co.id/beta/wp-content/themes/Astralife/static/img/astra-life-logo.png\" alt=\"Astra Life\" class=\"float-right\" style=\"-ms-interpolation-mode: bicubic; clear: both; display: block; float: left; max-width: 100%; outline: none; text-align: right; text-decoration: none; width: auto;\"></br></br>"
    		+ "<strong>www.astralife.co.id</strong><br/>"
    		+ "<strong>Follow us on FB, Twitter, Instagram, You Tube: @astralifeID</strong><br/>"
    		+ "<strong>Hello Astra Life : 1500-AVA(282)</strong><br/><br/>"
    		+ "<strong>PT ASTRA AVIVA LIFE</strong><br/>"
    		+ "Pondok Indah Office Tower 3 lantai 1<br/>"
    		+ "Jl. Sultan Iskandar Muda Kav V-TA<br/>"
    		+ "Pondok Indah<br/>"
    		+ "Jakarta Selatan - 12310, Indonesia"
    		+ "</font>";
    
    public static final String SUBJECT_PROP = "[FIF-AAL] Data CRE";
    public static final String CONTENT_PROP = DEAR_CONTENT_IPLUS_NTU
    		+ "Bersama email ini kami lampirkan Data CRE sesuai dengan polis ybs. <br/><br/>Terima Kasih <br/><br/>"
    		+ REGARDS_IPLUS_NTU + SIGNATURE;
    public static final String SUBJECT_CANCEL = "[FIF-AAL] Data Cancel Polis NTU";
    public static final String CONTENT_CANCEL = DEAR_CONTENT_IPLUS_NTU
    		+ "Bersama email ini kami lampirkan Data Cancel Polis / NTU <br/><br/>Terima Kasih <br/><br/>"
    		+ REGARDS_IPLUS_NTU + SIGNATURE;
    public static final String SUBJECT_IPLUS_NTU_IN = "[FIF-AAL] Generate and Send Email Report";
    public static final String CONTENT_IPLUS_NTU_IN = DEAR_CONTENT_IPLUS_NTU
    		+ "Bersama email ini kami informasikan status dari proses generate status "
    		+ "dan proses pengiriman email atas data proposal report dan cancel report.<br/><br/>Terima Kasih <br/><br/>"
    		+ REGARDS_IPLUS_NTU + SIGNATURE;
    
    //Claim Pre-Reg
    public static final String EMP_NAME = "EMP_NAME";
    public static final String REC_DATE = "REC_DATE";
    public static final String POL_NO = "POL_NO";
    public static final String MBR_NO = "MBR_NO";
    public static final String PATIENT_NAME = "PATIENT_NAME";
    public static final String INV_DATE = "INV_DATE";
    public static final String REF_NO = "REF_NO";
    
    public static final String SUBJECT_CLAIMPREG = "Tanda Terima Dokumen Klaim";
    public static final String CONTENT_CLAIMPREG = "Bapak/Ibu {{EMP_NAME}} yang terhormat, <br/><br/>Terimakasih atas kepercayaan yang telah diberikan kepada PT Astra Aviva Life sebagai penyedia jasa layanan asuransi bagi Anda dan Perusahaan. <br/><br/>"
    		+ "Bersama ini kami sampaikan, bahwa kami telah menerima dokumen klaim pada tanggal {{REC_DATE}}, dengan data berikut : <br/><br/>"
    		+ "<table>"
    		+ "<tr><td>Nomor Polis / Member No</td><td>:</td><td>{{POL_NO}}/{{MBR_NO}}</td></tr>"
    		+ "<tr><td>Nama Pasien</td><td>:</td><td>{{PATIENT_NAME}}</td></tr>"
    		+ "<tr><td>Tanggal Kwitansi</td><td>:</td><td>{{INV_DATE}}</td></tr>"
    		+ "<tr><td>No Registrasi Klaim</td><td>:</td><td>{{REF_NO}}</td></tr>"
    		+ "</table><br/>"
    		+ "Keputusan klaim akan diinformasikan kepada Bapak/Ibu {{EMP_NAME}} melalui email/sms. <br/><br/>"
    		+ "Demikian informasi ini kami sampaikan. Untuk informasi lebih lanjut mengenai produk dan layanan Astra Life silakan menghubungi Hello Astra Life di nomor 1-500-AVA (282) yang beroperasi 24/7 (24 jam setiap hari dan 7 hari dalam seminggu) atau melalui <i>e-mail</i> <u><font color=blue>hello@astralife.co.id</font></u>. Kami akan melayani dengan sepenuh hati. <br/>";
    
    public static final String OJK_MONTH_YEAR = "MONTH_YEAR";
    public static final String OJK_YEAR = "YEAR";
    
    // Ojk
    public static final String SUBJECT_OJK_YEAR = "Summary OJK Report on {{" + OJK_YEAR + "}}";
    public static final String SUBJECT_OJK = "Summary OJK Report on {{" + OJK_MONTH_YEAR + "}}";
    public static final String CONTENT_OJK = "Dear Finance Team, <br/><br/>"
    		+ "Kindly check the report as attached. <br/>"
    		+ "If any problem please submit ticket to IT Portal at http://iditamsvr01:8080/portal. <br/><br/>Thanks";
    public static final String SUBJECT_OJK_EMPTY = "Data for OJK Report on {{" + OJK_MONTH_YEAR + "}} is empty";
    public static final String CONTENT_OJK_EMPTY = "Dear Finance Team, <br/><br/>"
    		+ "Data is empty. <br/>Please upload data for OJK to Report Portal at <br/>http://ava-online.astralife.co.id/report-fe. <br/><br/>Thanks";
    
    // Ojk Master
    public static final String SUBJECT_OJK_MASTER = "Uncompleted Data for OJK Report on {{" + OJK_MONTH_YEAR + "}}";
    public static final String CONTENT_OJK_MASTER = "Dear Data Steward Team, <br/><br/>"
    		+ "Please complete data as attached and upload to Report Portal at <br/>http://ava-online.astralife.co.id/report-fe. <br/><br/>Thanks";
    
    public static final String SUBJECT_AOL_LOGIN_COUNT= "[AAL] AOL User Login Generate and Send Email Report";
    public static final String CONTENT_AOL_LOGIN_COUNT = EMAIL_SALUTATION
    		+ "Bersama email ini kami informasikan status dari proses generate "
    		+ "dan proses pengiriman email atas data user login AOL report.<br/><br/>Terima Kasih <br/><br/>"
    		+ EMAIL_REGARDS + SIGNATURE;
    
    public static final String SUBJECT_XML_GENERATOR_NOTIFY_STARTED= "Job Xml Generator Started";
    public static final String CONTENT_XML_GENERATOR_NOTIFY_STARTED = EMAIL_SALUTATION
    		+ "Bersama email ini kami informasikan Job scheduler untuk Xml Generator "
    		+ "mulai berjalan.<br/><br/>Terima Kasih <br/><br/>"
    		+ EMAIL_REGARDS + SIGNATURE;
    
    public static final String SUBJECT_XML_GENERATOR_NOTIFY_ENDED= "Job Xml Generator Ended";
    public static final String CONTENT_XML_GENERATOR_NOTIFY_ENDED = EMAIL_SALUTATION
    		+ "Bersama email ini kami informasikan Job scheduler untuk Xml Generator "
    		+ "selesai berjalan.<br/><br/>Terima Kasih <br/><br/>"
    		+ EMAIL_REGARDS + SIGNATURE;
    		
    // Daily MI Report
    public static final String DAILY_MI_DAY_MONTH_YEAR = "DAY_MONTH_YEAR";
    public static final String SUBJECT_DAILY_MI = "Daily MI Reports - {{" + DAILY_MI_DAY_MONTH_YEAR + "}}";
    public static final String CONTENT_DAILY_MI = "Dear All, <br/><br/>"
    		+ "Kindly find Daily MI Reports - {{" + DAILY_MI_DAY_MONTH_YEAR + "}} in SFTP. <br/><br/>"
    		+ "Terima kasih, <br/><br/>"
    		+ EMAIL_REGARDS + SIGNATURE;
    
    // Daily Commission Isave
    public static final String DAILY_ISAVE_DAY_MONTH_YEAR = "DAY_MONTH_YEAR";
    public static final String SUBJECT_DAILY_ISAVE = "Daily Commission Reports - {{" + DAILY_ISAVE_DAY_MONTH_YEAR + "}}";
    public static final String CONTENT_DAILY_ISAVE = "Dear All, <br/><br/>"
    		+ "Kindly find Daily Commission Reports - {{" + DAILY_ISAVE_DAY_MONTH_YEAR + "}} in SFTP. <br/><br/>"
    		+ "Terima kasih, <br/><br/>"
    		+ EMAIL_REGARDS + SIGNATURE;

    public static final String GROUP_OPERATION = "group.operations@astralife.co.id";
    public static final String CONTENT_BILLING_DETAIL = "Dengan Hormat. <br/><br/> " +
            "Kami telah memproses data terlampir. Bila ada data yang tidak sesuai, mohon konfirmasikan dalam 7 hari kerja melalui hello@astralife.co.id. <br/>" +
            "Untuk informasi, hubungi 1 500 AVA (282) (jam kerja). <br/>" +
            "Terima kasih. <br/><br/>" +
            "Group Policy Services. <br/>" +
            EMAIL_REGARDS + SIGNATURE;
    
    private EmailConstant() {
        throw new IllegalAccessError("Constant Class");
    }
}