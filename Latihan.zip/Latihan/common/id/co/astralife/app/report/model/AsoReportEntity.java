package id.co.astralife.app.report.model;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AsoReportEntity {

  private Integer rn;
  private String policyNo;
  private String productCode;
  private BigDecimal totalClaim;
  private BigDecimal threshold;
  private BigDecimal deposit;
  private String exceedTh;
  
}
