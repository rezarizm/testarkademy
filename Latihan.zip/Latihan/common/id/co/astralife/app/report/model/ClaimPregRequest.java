package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ClaimPregRequest {

	private String user;
	private String startDate;
	private String endDate;
	
}