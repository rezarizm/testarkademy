package id.co.astralife.app.report.local.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

import org.hibernate.annotations.GenericGenerator;

@Data
@Entity
@Table (name = "RPT_ROLE_REPORT")
public class ReportRole extends BaseEntity{
	 
	private static final long serialVersionUID = 3096849394941211790L;

	@Id
	@GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
	@Column(name = "ROLE_ID")
	private UUID roleId;
	
	@ManyToOne
    @JoinColumn(name = "RPT_ID", insertable= false, updatable=false)
    private Report report;
	
	@Column(name = "RPT_ID", nullable = false)
	private UUID rptId;
	
	@Column(name = "CREATE_BY")
    private String createBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;
	
}
