package id.co.astralife.app.report.local.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

@Entity
@Data
@Table(name = "RPT_OJK_MASTER")
public class OjkMaster implements Serializable {

	private static final long serialVersionUID = 1691294573095134419L;

	@Id
	@Column(name = "POLICY_NO", nullable = false)
    private String policyNo;

	@Column(name = "AREA_CODE")
    private String areaCode;
	
	@Column(name = "CITY")
    private String city;
    
    @Column(name = "PROVINCE")
    private String province;
    
    @Column(name = "ID_NO")
    private String idNo;
    
    @Column(name = "ADDRESS")
    private String address;
    
    @Column(name = "CREATE_BY", nullable = false)
    private String createBy;
    
    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;
}
