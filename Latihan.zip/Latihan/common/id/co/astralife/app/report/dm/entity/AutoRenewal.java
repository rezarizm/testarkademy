package id.co.astralife.app.report.dm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.AutoRenewalConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries ({
	@NamedNativeQuery(name = "AutoRenewal.getBillAutoRenewalByPolicyNoAndStartDateAndEndDate", query = AutoRenewalConstant.QUERY_BILL_AUTO_RENEWAL, resultClass = AutoRenewal.class),
	@NamedNativeQuery(name = "AutoRenewal.getProposalRenewalByPolicyNo", query = AutoRenewalConstant.QUERY_PROPOSAL_RENEWAL, resultClass = AutoRenewal.class),
	@NamedNativeQuery(name = "AutoRenewal.getCurrency", query = AutoRenewalConstant.QUERY_GET_CURRENCY, resultClass = AutoRenewal.class),
})
@Table (name = "GAGCHIPF")
public class AutoRenewal implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "POLICY_NO")
	private String policyNo;
	
	@Column(name = "POLICY_HOLDER")
	private String policyHolder;
	
	@Column(name = "CONTRACT_TYPE")
	private String contractType;
	
	@Column(name = "CURR_CODE")
	private String currCode;
	
	@Column(name = "BILLING_CURRENCY")
	private String currDesc;
	
	@Column(name = "EMAIL_TO")
	private String emailTo;
	
	@Column(name = "START_DATE")
	private String startDate;
	
	@Column(name = "EXPIRY_DATE")
	private String expiryDate;
	
	@Column(name = "EXCLUDE")
	private String exclude;
	
	@Column(name = "EXCLUDE_POLICY")
	private String excludePolicy;

	@Column(name = "CHANNEL")
	private String channel;

	@Column(name = "SOB")
	private String sob;
}
