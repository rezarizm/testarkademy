package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmailRequest {
	
	private Integer option;
	private String user;
	private String emailId;
	private String startDate;
	private String endDate;
	private String status;
	private String fromId;
	private String reportId;
}
