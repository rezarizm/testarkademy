package id.co.astralife.app.report.core;

public interface ProtectFileService {

	void protectOoxmlFile(String fileName, String pathInput, String pathOutput, String password);
	
	void makeReadOnly(String fileName, String pathInput, String pathOutput);
}
