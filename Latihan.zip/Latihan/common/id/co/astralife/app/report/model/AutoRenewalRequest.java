package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AutoRenewalRequest {

	private String user;
	private String startDate;
	private String endDate;
	private String monthYear;
	private String policyNo;
	private Boolean email;
	private Boolean duplicate;
	private String type;
}
