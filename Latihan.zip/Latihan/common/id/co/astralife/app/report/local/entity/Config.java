package id.co.astralife.app.report.local.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.OjkConstant;
import lombok.Data;

@Entity
@Data
@NamedNativeQueries({
	@NamedNativeQuery(name = "Config.findAllNextConfigValueByConfigName", query = OjkConstant.OJK_GEOCODE_NEXT_SHEET_DAY_COUNT_QUERY, resultClass = Config.class),
	@NamedNativeQuery(name = "Config.findByConfigNameAndRowBetween", query = OjkConstant.OJK_GEOCODE_CURRENT_SHEET_DAY_COUNT_BETWEEN_QUERY, resultClass = Config.class)
})
@Table(name = "RPT_CONFIG")
public class Config {
    @Id
    @Column(name = "CONFIG_ID")
    private UUID configId;

    @Column(name = "CONFIG_NAME")
    private String configName;
	
	@Column(name = "CONFIG_VALUE")
    private String configValue;
}
