package id.co.astralife.app.report.mirror.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.mirror.entity.BiReportGroup;

public interface BiReportGroupRepository extends JpaRepository<BiReportGroup, String> {

	@Query(nativeQuery=true)
	BiReportGroup getCountData(String month, String yearMonth);
	
}
