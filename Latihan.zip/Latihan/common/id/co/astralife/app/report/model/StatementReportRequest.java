package id.co.astralife.app.report.model;

import java.util.UUID;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatementReportRequest {

	private UUID reportId;
    private String user;
    private String currency;
    private String srcCode;
    
}
