package id.co.astralife.app.report.validator.annotation;

import id.co.astralife.app.report.validator.DependentNoValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author fadil.wiranata
 */
@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = DependentNoValidator.class)
public @interface DependentNo {

    String message() default "Dependent No is not valid";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
