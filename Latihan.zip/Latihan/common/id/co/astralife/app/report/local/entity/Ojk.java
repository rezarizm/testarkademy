package id.co.astralife.app.report.local.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

@Entity
@Data
@Table(name = "RPT_OJK")
public class Ojk implements Serializable {

	private static final long serialVersionUID = -5996897382080248434L;

	@Id
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@GeneratedValue(generator = "uuid")
	@Column(name = "OJK_ID", nullable = false)
	private UUID ojkId;

	@Column(name = "ACCOUNT_CODE", nullable = false)
	private String accountCode;

	@Column(name = "BASE_AMT")
	private BigDecimal baseAmount;

	@Column(name = "JOURNAL_TYPE")
	private String journalType;

	@Column(name = "TRANS_REF", nullable = false)
	private String transRef;

	@Column(name = "POLICY_NO")
	private String policyNo;

	@Column(name = "AREA_CODE")
	private String areaCode;

	@Column(name = "CITY")
	private String city;

	@Column(name = "PROVINCE")
	private String province;

	@Column(name = "TOT_MBR")
	private Long totMember;

	@Column(name = "STATUS", nullable = false)
	private String status;

	@Column(name = "CATEGORY", nullable = false)
	private String category;

	@Column(name = "SUB_CATEGORY", nullable = false)
	private String subCategory;

	@Column(name = "SRC_OF_ADDR")
	private String sourceOfAddress;
	
	@Column(name = "FREQUENCY")
	private String frequency;

	@Column(name = "UP")
	private BigDecimal up;
	
	@Column(name = "CREATE_BY", nullable = false)
	private String createBy;

	@Column(name = "MODIFY_BY")
	private String modifyBy;

	@Setter(AccessLevel.NONE)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATE")
	private Date createDate;

	@Setter(AccessLevel.NONE)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "MODIFY_DATE")
	private Date modifyDate;

	@Override
	public String toString() {
		return String.format("%s;%s;%s", journalType.trim(), policyNo, "");
	}
}
