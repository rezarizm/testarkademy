package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssReportTargetDropdown;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;


public interface CssReportTargetDropdownRepository extends JpaRepository<CssReportTargetDropdown, UUID>{

}
