package id.co.astralife.app.report.model;

import org.springframework.beans.factory.annotation.Value;

import id.co.astralife.app.report.common.OperationConstant;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BiReportForm {

	private String policyNo;
	
	private String month;
	
	private String yearMonth;
	
	private String policyType;
	
	@Value("reprint")
	private String reprint = OperationConstant.PARAM_REPRINT;
}
