package id.co.astralife.app.report.local.entity;

import id.co.astralife.app.report.common.ReportConstant;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * @author fadil.wiranata
 */
@Entity
@Data
@NamedNativeQueries(
        @NamedNativeQuery(name = "Menu.findByUserId", query = ReportConstant.MENU_QUERY, resultClass = Menu.class)
)
@Table(name = "RPT_MENU")
public class Menu extends BaseEntity implements Comparable<Menu> {

    private static final long serialVersionUID = 6590822848728497758L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "MENU_ID", nullable = false)
    private UUID id;

    @Column(name = "MENU_NAME")
    private String menuName;


    @Column(name = "MENU_DESC")
    private String menuDesc;

    @Column(name = "PARENT_ID")
    private UUID parentId;

    @Column(name = "SEQUENCE")
    private int sequence;

    @Column(name = "MENU_URL")
    private String menuUrl;

    @Column(name = "CREATE_BY")
    private String createBy;

    @Transient
    private Set<Menu> children = new HashSet<>();

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;

    @Override
    public int compareTo(Menu menu) {
        return this.sequence > menu.sequence ? 1 : this.sequence < menu.sequence ? -1 : 0;
    }
}
