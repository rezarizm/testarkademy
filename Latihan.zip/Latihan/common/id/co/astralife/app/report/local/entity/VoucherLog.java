package id.co.astralife.app.report.local.entity;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.Data;

@Data
@Entity
@Table(name = "RPT_VOUCHER_LOG")
public class VoucherLog {
	
	@Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
	@Column(name="LOG_ID")
	private UUID logId;

	@Column(name="FILE_ID")
	private UUID fileId;
	
	@Column(name="STATUS")
	private String status;
	
	@Column(name="MESSAGE")
	private String message;
	
}
