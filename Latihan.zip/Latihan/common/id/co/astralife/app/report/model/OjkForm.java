package id.co.astralife.app.report.model;

import org.springframework.web.multipart.MultipartFile;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OjkForm {

	private String option;
	private MultipartFile ojkFile;
	private String rptFreq;
	private String monthUpload;
	
}
