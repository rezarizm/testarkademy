package id.co.astralife.app.report.model;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import lombok.Data;

@Data
public class InternalVoucherTemplate {

	public static final Map<Integer, String> HEADER;
	static{
		Map<Integer, String> temp = new HashMap<>();
		temp.put(0, "AGENT_CODE");
		temp.put(1, "AGENT_CHANNEL");
		temp.put(2, "CHANNEL");
		temp.put(3, "SALES_CHANNEL");
		temp.put(4, "PAYOR_NAME");
		temp.put(5, "PAYOR_EMAIL");
		temp.put(6, "PAYOR_PHONE");
		temp.put(7, "RECEIVER_NAME");
		temp.put(8, "VOUCHER_CATEGORY");
		temp.put(9, "RECEIVER_EMAIL");
		temp.put(10, "SEND_DATE");
		temp.put(11, "MESSAGE");
		temp.put(12, "ORDER_NO");
		HEADER = Collections.unmodifiableMap(temp);
	}

	private String agentCode;
	private String agentChannel;
	private String channel;
	private String salesChannel;
	private String payorName;
	private String payorEmail;
	private String payorPhone;
	private String receiverName;
	private String voucherCategory;
	private String receiverEmail;
	private Date sendDate;
	private String message;
	private String orderNo;
	
}
