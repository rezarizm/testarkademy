package id.co.astralife.app.report.dm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.common.ClaimReportGasiaConstant;
import id.co.astralife.app.report.dm.entity.ClaimPaidPayable;

public interface ClaimPaidPayableRepository extends JpaRepository<ClaimPaidPayable, String> {
	
	@Query(nativeQuery = true, value = ClaimReportGasiaConstant.COUNT_CLAIM_PAID)
	Long countClaimPaid(String startDate, String endDate);
	
	@Query(nativeQuery = true, value = ClaimReportGasiaConstant.COUNT_CLAIM_PAYABLE)
	Long countClaimPayable(String startDate, String endDate);

}
