package id.co.astralife.app.report.aol.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.aol.entity.EmailTracker;

public interface EmailTrackerRepository extends JpaRepository<EmailTracker, Long>{

	List<EmailTracker> findByCreateDateBetween(Date startDate, Date endDate);
	
}
