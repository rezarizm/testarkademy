package id.co.astralife.app.report.local.enumeration;

public enum DropDownGroup {

	UPLOAD_PARTNER, 
	OJK_REPORT, 
	UPLOAD_FILE,
	CLAIM_LETTER,
	ASO_POLICY_CLAIM,
	OJK_REPORT_FREQ;

}
