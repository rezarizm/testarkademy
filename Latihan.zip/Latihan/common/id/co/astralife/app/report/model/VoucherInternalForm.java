package id.co.astralife.app.report.model;

import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;
import lombok.Setter;

/**
 * POJO for upload voucher internal.
 *
 * @since 5 Mei 2017
 * @version 1.0
 * @author sayid.sidqi
 */
@Getter
@Setter
public class VoucherInternalForm {

//	private String agentCode;
//	
//	@NotBlank
//	private String buyerName;
//	
//	@Email
//	@NotBlank
//	private String emailAddress;
	
	private MultipartFile voucherFile;
	
}