package id.co.astralife.app.report.mirror.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.mirror.entity.GroupPolicy;

public interface GroupPolicyRepository extends JpaRepository<GroupPolicy, String>{

	@Query(nativeQuery = true)
	List<GroupPolicy> findByDateBetween(String startDate, String endDate);
	
	@Query(nativeQuery = true)
	GroupPolicy findByPolicyNoAndTranNo(String policyNo, String tranNo);
	
	@Query(nativeQuery = true)
	GroupPolicy findForNextRow(String policyNo, String tranNo);
	
	@Query(nativeQuery = true)
	GroupPolicy findCheckReversed(String policyNo, Long id);
}