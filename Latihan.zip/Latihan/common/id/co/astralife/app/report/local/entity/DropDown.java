package id.co.astralife.app.report.local.entity;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import id.co.astralife.app.report.common.UploadConstant;
import id.co.astralife.app.report.local.enumeration.DropDownGroup;
import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Entity for RPT_DROPDOWN table.
 *
 * @since 22 Mei 2017
 * @version 1.0
 * @author sayid.sidqi
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@NoArgsConstructor
@Entity
@NamedNativeQueries(
	@NamedNativeQuery(name = "DropDown.findAllByGroupAndUserNameOrderByDescription", query = UploadConstant.DROWN_BY_ROLE_QUERY, resultClass = DropDown.class
	)
)
@Table(name = "RPT_DROPDOWN")
public class DropDown extends BaseEntity {
	
	private static final long serialVersionUID = -2707202264791757724L;
	
	@Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "DROWN_ID", nullable = false)
    private UUID id;

    @Column(name = "DROWN_CODE", nullable = false)
    private String code;

    @Column(name = "DROWN_DESC", nullable = false)
    private String description;
    
    @Column(name = "DROWN_GROUP", nullable = false)
    @Enumerated(EnumType.STRING)
    private DropDownGroup group;

    @Column(name = "CREATE_BY")
    private String createBy;

    @Column(name = "MODIFY_BY")
    private String modifyBy;
    
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;

}
