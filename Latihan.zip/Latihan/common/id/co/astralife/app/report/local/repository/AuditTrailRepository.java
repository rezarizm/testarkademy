package id.co.astralife.app.report.local.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.AuditTrail;

import java.util.List;
import java.util.UUID;

public interface AuditTrailRepository extends JpaRepository<AuditTrail, UUID> {

	List<AuditTrail> findAll();
	List<AuditTrail> findByAuditTrailId(UUID auditTrailId);
}
