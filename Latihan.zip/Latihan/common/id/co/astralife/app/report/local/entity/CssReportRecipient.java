package id.co.astralife.app.report.local.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.UUID;

@Data
@Entity
@Table(name = "CSS_REPORT_RECIPIENT")
public class CssReportRecipient implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@GeneratedValue(generator = "uuid")
	@Column(name = "RECIPIENT_ID", nullable = false)
	private UUID cssRecipientId;

	@Column(name = "RECIPIENT_ADDRESS", nullable = false)
	private String cssRecipientAddress;

	@Column(name = "RECIPIENT_NAME", nullable = false)
	private String cssRecipientName;
}
