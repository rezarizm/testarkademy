package id.co.astralife.app.report.model;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AsoLetterEntity {

  private String letterNo;
  private String policyNo;
  private String phName;
  private String companyName;
  private String address01;
  private String address02;
  private String address03;
  private String address04;
  private String address05;
  private BigDecimal deposit;
  private BigDecimal totalClaim;
  private BigDecimal savings;
  private Boolean exceedThStatus; 
  
}
