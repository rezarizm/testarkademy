package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssReportDeliveryTemplateRelView;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface CssReportDeliveryTemplateRelViewRepository extends JpaRepository<CssReportDeliveryTemplateRelView, UUID> {
    List<CssReportDeliveryTemplateRelView> findCssReportDeliveryTemplateRelViewByCssDeliveryGroupId(String cssDeliveryGroupId);

    List<CssReportDeliveryTemplateRelView> findByCssDeliveryGroupId(String cssDeliveryGroupId);
}
