package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssReportRecipient;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface CssReportRecipientRepository extends JpaRepository<CssReportRecipient, UUID> {
    CssReportRecipient findRecipientByCssRecipientId(UUID cssRecipientId);
}
