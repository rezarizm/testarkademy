package id.co.astralife.app.report.dm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.common.AutoRenewalConstant;
import id.co.astralife.app.report.dm.entity.AutoRenewal;

public interface AutoRenewalRepository extends JpaRepository<AutoRenewal, String>{

	@Query(nativeQuery = true)
	List<AutoRenewal> getBillAutoRenewalByPolicyNoAndStartDateAndEndDate(String startDate, String endDate);
	
	@Query(nativeQuery = true)
 	AutoRenewal getProposalRenewalByPolicyNo(String policyNo);
	
	@Query(nativeQuery = true, value = AutoRenewalConstant.QUERY_COUNT_PROPOSAL_RENEWAL)
	AutoRenewal countValidateProposalRenewalByPolicyNo(String policyNo);
	
	@Query(nativeQuery = true, value = AutoRenewalConstant.QUERY_GET_CNT_TYPE)
	List<String> getContractType();
	
	@Query(nativeQuery = true, value = AutoRenewalConstant.QUERY_GET_CURRENCY)
	AutoRenewal getCurrency(String policyNo);
}
