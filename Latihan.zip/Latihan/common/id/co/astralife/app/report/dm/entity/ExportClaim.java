package id.co.astralife.app.report.dm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table (name = "LFHCLHPF")
public class ExportClaim implements Serializable {
	
	private static final long serialVersionUID = -5074690312466153589L;

	@Id
	@Column(name = "JML")
	private Integer recordcount;
	
}
