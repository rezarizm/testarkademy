package id.co.astralife.app.report.validator;

import id.co.astralife.app.report.validator.annotation.MemberNo;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * @author fadil.wiranata
 */
public class MemberNoValidator implements ConstraintValidator<MemberNo, String> {

    @Override
    public void initialize(MemberNo annotation) {
    	//
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
        // Member No either null, empty or length 5
        return value == null || value.length() == 0 || value.length() == 5;

    }
}
