package id.co.astralife.app.report.local.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.UUID;

@Entity
@Data
@Table(name = "CSS_REPORT_FILE_GROUP_TEMP_R")
public class CssReportFileGroupAndTemplateRelationship implements Serializable {

    @Id
    @Column(name = "ID_REL", nullable = false)
    private UUID idRelationship;

    @Column(name = "FILE_GROUP_ID")
    private String fileGroupId;

    @Column(name = "REPORT_FILE_GROUP")
    private String reportFileGroup;

    @Column(name = "CATEGORY_ID")
    private String categoryId;

    @Column(name = "VALUE")
    private String value;

    @Column(name = "TEMPLATE_ID")
    private String templateId;

    @Column(name = "TEMPLATE_NAME")
    private String templateName;

    @Column(name = "TEMPLATE_TYPE")
    private String templateType;

    @Column(name = "TEMPLATE_SERVICE_NAME")
    private String templateServiceName;
}
