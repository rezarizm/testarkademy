package id.co.astralife.app.report.dm.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@Entity
@Table(name = "CSS_NON_RIDER")
public class CssReportNonRider implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "COMPONENT")
    private String component;

    @Column(name = "COMPONENTDESC")
    private String componentDesc;
}
