package id.co.astralife.app.report.local.entity;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * @author fadil.wiranata
 */
@Data
@Entity
@Table(name = "RPT_ROLE")
public class Role extends BaseEntity {

    private static final long serialVersionUID = -6104068834539550021L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "ROLE_ID", nullable = false)
    private UUID roleId;

    @Column(name = "ROLE_NAME")
    private String roleName;

    @Column(name = "ROLE_DESC")
    private String roleDesc;

    @Column(name = "CREATE_BY")
    private String createBy;

    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(name = "RPT_FUNCTION_ROLE", 
        joinColumns = {@JoinColumn(name = "ROLE_ID", nullable = false, updatable = false)},
        inverseJoinColumns = {@JoinColumn(name = "FUNC_ID", nullable = false, updatable = false)}
    )    
    private List<Function> functions = new ArrayList<>();
    
    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;
}
