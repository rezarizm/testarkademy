package id.co.astralife.app.report.dm.entity;

import id.co.astralife.app.report.common.ClaimLetterGasiaConstant;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@NamedNativeQueries({
    @NamedNativeQuery(name = "ClaimLetterGasia.getClaimLetterGasiaByReqDate", query = ClaimLetterGasiaConstant.QUERY_CLAIM_LETTER_GASIA, resultClass = ClaimLetterGasia.class),
    @NamedNativeQuery(name = "ClaimLetterGasia.getClaimLetterGasiaByClaimNoAndOccurrenceNo", query = ClaimLetterGasiaConstant.QUERY_CLAIM_LETTER_GASIA_CLAIM, resultClass = ClaimLetterGasia.class),
    @NamedNativeQuery(name = "ClaimLetterGasia.getClaimLetterGasiaByProvorg", query = ClaimLetterGasiaConstant.QUERY_CLAIM_LETTER_GASIA_RECAP, resultClass = ClaimLetterGasia.class)
})
@Table(name = "GALETCPF")
public class ClaimLetterGasia implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "RN")
    private Integer rn;

    @Column(name = "LETTER_TYPE")
    private String letterType;

    @Column(name = "POLICY_NO")
    private String policyNo;

    @Column(name = "CLIENT_NO")
    private String clientNo;

    @Column(name = "PROVORG")
    private String provorg;

    @Column(name = "CLAIM_NO")
    private String claimNo;

    @Column(name = "OCCURRENCE_NO")
    private String occurrenceNo;

    @Column(name = "MEMBER_NO")
    private String memberNo;

    @Column(name = "DEPENDENT_NO")
    private String dependentNo;

    @Column(name = "REQ_DATE")
    private String reqDate;

    @Column(name = "JETFORM_ID")
    private String jetformId;

    @Column(name = "DATIME")
    private String datime;

    @Column(name = "XML_TAG")
    private String xmlTag;

    @Column(name = "REFUND_PAYMENT_TYPE")
    private String refundPaymentType;
}
