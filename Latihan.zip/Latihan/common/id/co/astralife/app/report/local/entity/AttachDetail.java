package id.co.astralife.app.report.local.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

@Data
@Entity
@Table(name = "RPT_ATTACH_DETAIL")
public class AttachDetail implements Serializable {

	private static final long serialVersionUID = 3543538088390803459L;

	@Id
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@GeneratedValue(generator = "uuid")
	@Column (name = "ATTACH_DETAIL_ID", nullable = false)
	private UUID attachDetailId;
	
	@Column(name = "ATTACH_NAME", nullable = false)
	private String attachName;
	
	@Column(name = "ATTACH_PATH", nullable = false)
	private String attachPath;
	
	@Column(name = "EMAIL_ID", nullable = false)
	private UUID emailId;
	
	@ManyToOne
    @JoinColumn(name = "EMAIL_ID", insertable= false, updatable=false)
    private Email email;
	
	@Column(name = "CREATE_BY", nullable = false)
	private String createBy;
	
	@Setter(AccessLevel.NONE)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATE")
	private Date createDate;
	
	@Column(name = "MODIFY_BY")
	private String modifyBy;
	
	@Setter(AccessLevel.NONE)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "MODIFY_DATE")
	private Date modifyDate;
	
}
