package id.co.astralife.app.report.validator;

import id.co.astralife.app.report.validator.annotation.DependentNo;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * @author fadil.wiranata
 */
public class DependentNoValidator implements ConstraintValidator<DependentNo, String> {

    @Override
    public void initialize(DependentNo annotation) {
    	//
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
        return value == null || value.length() == 0 || value.length() == 2;
    }
}
