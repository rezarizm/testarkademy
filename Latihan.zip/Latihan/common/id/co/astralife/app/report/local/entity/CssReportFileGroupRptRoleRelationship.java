package id.co.astralife.app.report.local.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.UUID;

@Data
@Entity
@Table(name = "CSS_RPRT_CTGRY_FL_GRP_ROLE_REL")
public class CssReportFileGroupRptRoleRelationship implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID_REL", nullable = false)
	private UUID idRel;

	@Column(name = "ROLE_ID", nullable = false)
	private UUID roleId;

	@Column(name = "ROLE_NAME", nullable = false)
	private String roleName;

	@Column(name = "ROLE_DESC", nullable = false)
	private String roleDesc;

	@Column(name = "FILE_GROUP_ID", nullable = false)
	private String fileGroupId;

	@Column(name = "REPORT_FILE_GROUP", nullable = false)
	private String cssReportFileGroup;

	@Column(name = "VALUE", nullable = false)
	private String cssReportFileGroupValue;

	@Column(name = "CATEGORY_ID", nullable = false)
	private String categoryId;

	@Column(name = "CATEGORY_NAME", nullable = false)
	private String cssMenuCategory;
	
	@Column(name = "CATEGORY_VALUE", nullable = false)
	private String cssMenuCategoryValue;
}
