package id.co.astralife.app.report.common;

public class SalesSupportConstant {

	public static final String AGENT_COMMISSION = "AgentCommission";
	public static final String AGENT_COMMISSION_ECOM = "AgentCommissionECom";
	public static final String NEW_BUSINESS_AFC = "NewBusinessAfc";
	public static final String REPORT_VOUCHER = "ReportVoucher";
	public static final String DAILY_REPORT = "DailyReport";
	public static final String INCENTIVE_REPORT = "IncentiveReport";
	public static final String FEE_BASED_REPORT = "FeeBasedReport";
	
	public static final String NB_FILENAME = "New_Business_Report_";
	public static final String AC_AFC_FILENAME = "Commission_Report_AFC_";
	public static final String AC_ECOMM_FILENAME = "Commission_Report_Digital_";

	public static final String COMMISSION_DETAIL = "DailyCommissionDetail";
	public static final String COMMISSION_SUMMARY = "DailyCommissionSummary";
	public static final String COMM_DETAIL_FILENAME = "Daily_Commission_MindStores_Detail_Report_";
	public static final String COMM_SUMMARY_FILENAME = "Daily_Commission_MindStores_Summary_Report_";
	
	public static final String COMMISSION_APPBUDDIES_DETAIL = "DailyCommissionAppBuddiesDetail";
	public static final String COMMISSION_APPBUDDIES_SUMMARY = "DailyCommissionAppBuddiesSummary";
	public static final String COMM_APPBUDDIES_DETAIL_FILENAME = "Daily_Commission_AppBuddies_Detail_Report_";
	public static final String COMM_APPBUDDIES_SUMMARY_FILENAME = "Daily_Commission_AppBuddies_Summary_Report_";
	
	
	public static final String AOL_USER_LOGIN = "AolUserPermataLoginDetail";
	public static final String RMCS_SELLING_TOKEN = "AktivasiTokenRmcsReport";
	
	public static final String DAILY_COMMISSION_ISAVE = "DailyCommissionIsave";
	public static final String MONTHLY_COMMISSION_ISAVE = "MonthlyCommissionIsave";
	public static final String BANK_REWARD = "BankReward";

	public static final String FINANCE_PRODUCTION = "FinanceProduction";
	public static final String FP_FILENAME = "Daily_Production_Finance_Report_Digital_";

	public static final String PARAM_START_DATE = "startdate";
	public static final String PARAM_END_DATE = "enddate";
	public static final String DATE_PARAM = "date_param";
	
	public static final String DAILY_REPORT_EMAIL = "DAILY_REPORT_EMAIL";
	public static final String DAILY_COMMISSION_ISAVE_EMAIL = "DAILY_COMMISSION_ISAVE_EMAIL";
	
	public static final String RENOVA_MAX_ROW = "RENOVA_MAX_ROW";

	public static final String ASTRA_COOP_CERT = "AstraCooperation";
	public static final String ASTRA_COOP_CERT_FILENAME = "Certificate_Polis_Koperasi_Astra";
	
	public static final String AGENT_COMMISSION_ECOM_ASTRA_COOP = "CommissionDailyAstraCoop";
	public static final String AGENT_COMMISSION_ECOM_ASTRA_COOP_FILENAME = "Commission_Daily_Koperasi_Astra_CreditLife_";
	
	public static final String NEW_BUSINESS_ASTRA = "NewBusinessAstra";
	public static final String NB_ASTRA_FILENAME = "NBU_Report_Koperasi_Astra_Production_";
	
	//ddMMyyyy
	public static final String ASTRA_COOP_CERT_GET_BY_DATE = "select count(*) count_data from table(pkg_rpt_astra_coop.get_data_by_date(?1))";
	
	private SalesSupportConstant (){
		throw new IllegalAccessError("Constant Class");
	}
}