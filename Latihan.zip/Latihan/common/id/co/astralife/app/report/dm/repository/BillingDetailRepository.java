package id.co.astralife.app.report.dm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.common.BillingDetailConstant;
import id.co.astralife.app.report.dm.entity.BillingDetail;

public interface BillingDetailRepository extends JpaRepository<BillingDetail, String>{

	@Query(nativeQuery = true, value = BillingDetailConstant.QUERY_BILLING_DETAIL_LIST_BILLNO)
	List<BillingDetail> getBillingDetail(String billNo, String startDate, String endDate);
	
}
