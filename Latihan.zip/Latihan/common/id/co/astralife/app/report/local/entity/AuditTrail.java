package id.co.astralife.app.report.local.entity;

import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.Data;

@Entity
@Data
@Table(name = "RPT_AUDIT_TRAIL")
public class AuditTrail {

	@Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
	@Column(name="AUDIT_TRAIL_ID")
	private UUID auditTrailId;
	
	@Column(name="LOGIN_ID")
	private String loginId;
	
	@Column(name="TRANSACTION_TIME")
	private Timestamp transactionTime;
	
	@Column(name="TRANSACTION_TYPE")
	private String transactionType;
	
	@Column(name="TRANSACTION_STATUS")
	private Integer transactionStatus;
	
	@Column(name="DESCRIPTION")
	private String description;
}
