package id.co.astralife.app.report.local.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.UUID;

@Data
@Entity
@Table(name = "CSS_REPORT_TARGET_DROPDOWN")
public class CssReportTargetDropdown extends BaseEntity {
	
	private static final long serialVersionUID = 7383561406331789816L;

	@Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "ID_DROPDOWN")
    private UUID idDropdown;
	
	 @Column(name = "DROPDOWN_TARGET")
	 private String dropdownTarget;
	
	 @Column(name = "DROPDOWN_VALUE")
	 private String dropdownValue;
}
