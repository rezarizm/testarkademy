package id.co.astralife.app.report.dm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.SmePolicyConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries({
		@NamedNativeQuery(name = "SmePolicy.findByDateBetween", query = SmePolicyConstant.SME_BY_ISSDATE, resultClass = SmePolicy.class),
		@NamedNativeQuery(name = "SmePolicy.findByPolicyNoAndTranNo", query = SmePolicyConstant.SME_BY_POLICY_NO, resultClass = SmePolicy.class),
		@NamedNativeQuery(name = "SmePolicy.findForNextRow", query = SmePolicyConstant.SME_POLICY_NEXT_ROW, resultClass = SmePolicy.class),
		@NamedNativeQuery(name = "SmePolicy.findCheckReversed", query = SmePolicyConstant.SME_POLICY_CHECK_REVERSED, resultClass = SmePolicy.class)
})
@Table(name = "GAGIDTPF")
public class SmePolicy implements Serializable {

	private static final long serialVersionUID = 4878300103416845762L;

	@Id
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "POLICY_NO")
	private String policyNo;
	
	@Column(name = "TRAN_NO")
	private String tranNo;
	
	@Column(name = "ISSUED_DATE")
	private String issDate;
	
	@Column(name = "EFF_DATE")
	private String effDate;
	
	@Column(name = "CNT_TYPE")
	private String cntType;
	
	@Column(name = "BATC_CODE")
	private String batcCode;
	
}
