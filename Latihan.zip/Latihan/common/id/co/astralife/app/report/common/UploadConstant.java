package id.co.astralife.app.report.common;

public class UploadConstant {

    public static final String AREA = "area";
    public static final String OJK_MASTER = "ojkm";

    public static final String AREA_ROW_HEADER = "AREA_ROW_HEADER";
    public static final String OJK_MASTER_HEADER = "OJK_MASTER_HEADER";

    public static final String AREA_CODE = "area code";
    public static final String AREA_CITY = "city";
    public static final String AREA_PROV = "province";

    //CSS Report Start
    //Target Header
    public static final String CSS_TARGET_AREA_HEADER = "CSS_TARGET_AREA_HEADER";
    public static final String CSS_TARGET_CHANNEL_HEADER = "CSS_TARGET_CHANNEL_HEADER";
    public static final String CSS_TARGET_PRODUCT_HEADER = "CSS_TARGET_PRODUCT_HEADER";
    public static final String CSS_TARGET_RM_HEADER = "CSS_TARGET_RM_HEADER";
    public static final String CSS_NON_RIDER_HEADER = "CSS_NON_RIDER_HEADER";

    //Target Area
    public static final String TARGET_AREA_APE = "ape";
    public static final String TARGET_AREA_AREA = "area";
    public static final String TARGET_AREA_ASM_CODE = "asm_code";
    public static final String TARGET_AREA_ASM_NAME = "asm_name";
    public static final String TARGET_AREA_RSM_CODE = "rsm_code";
    public static final String TARGET_AREA_RSM_NAME = "rsm_name";
    public static final String TARGET_AREA_MONTH = "month";
    public static final String TARGET_AREA_YEAR = "year";
    public static final String TARGET_AREA_RSM_REGION = "region";

    //Target Channel
    public static final String TARGET_CHANNEL_SOB = "sob";
    public static final String TARGET_CHANNEL_PRODUCT = "product";
    public static final String TARGET_CHANNEL_CHANNEL = "channel";
    public static final String TARGET_CHANNEL_PRODUCT_NAME = "product name";
    public static final String TARGET_CHANNEL_PARTNER = "partner";
    public static final String TARGET_CHANNEL_CORE = "core";

    //Target Product
    public static final String TARGET_PRODUCT_PRODUCT = "product";
    public static final String TARGET_PRODUCT_MONTH = "month";
    public static final String TARGET_PRODUCT_YEAR = "year";
    public static final String TARGET_PRODUCT_APE = "ape";

    //Target RM
    public static final String TARGET_RM_JABATAN = "jabatan";
    public static final String TARGET_RM_TARGET = "target";

    //Non Rider
    public static final String NON_RIDER_COMPONENT = "component";
    public static final String NON_RIDER_COMPONENTDESC = "componentdesc";

    //CSS Report End

    public static final String DROWN_BY_ROLE_QUERY = "select * from rpt_dropdown " +
            "where drown_group = ?1 " +
            "and drown_id in (select drown_id from rpt_dropdown_role " +
            "                    where role_id in (select role_id from rpt_user_role " +
            "                                      where user_id in (select user_id from rpt_user " +
            "                                                        where login_id = ?2))) " +
            "order by drown_desc asc ";

    private UploadConstant() {
        throw new IllegalAccessError("Constant Class");
    }
}
