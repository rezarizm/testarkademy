package id.co.astralife.app.report.mirror.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.ReportConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries(
		@NamedNativeQuery(name = "ClaimPreg.findClaimPregByReceivedDateBetween", query = ReportConstant.CLAIM_PREG, resultClass = ClaimPreg.class)
)
@Table(name = "GAYCRHPF")
public class ClaimPreg implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8474408180010416799L;

	@Id
	@Column(name = "REF_NO")
	private String refNo;
	
	@Column(name = "USER_ID")
	private String user;

	@Column(name = "CLAIM_NO")
	private String claimNo;

	@Column(name = "POL_NO")
	private String policyNo;

	@Column(name = "MBR_NO")
	private String memberNo;

	@Column(name = "POL_HOLDER")
	private String policyHolder;

	@Column(name = "SUBS")
	private String subsidiary;

	@Column(name = "BRANCH")
	private String branch;

	@Column(name = "RECV_DATE")
	private String receivedDate;

	@Column(name = "INV_DATE")
	private String invoiceDate;
	
	@Column(name = "EMP_NO")
	private String employeeNo;

	@Column(name = "EMP_NAME")
	private String emplooyeeName;

	@Column(name = "PTNT_NAME")
	private String patientName;

	@Column(name = "PRODUCT")
	private String product;

	@Column(name = "TOT_AMT_INC")
	private String totAmtInc;

	@Column(name = "REMARKS")
	private String remarks;

}
