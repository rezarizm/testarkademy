package id.co.astralife.app.report.dm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.AutoRenewalConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries({
    @NamedNativeQuery(name = "EmailCc.getEmailCcBySob", query = AutoRenewalConstant.QUERY_EMAIL_CC, resultClass = EmailCc.class)
})
@Table(name = "GAGCHIPF")
public class EmailCc implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "EMAIL_CC")
    private String emailCc;
}
