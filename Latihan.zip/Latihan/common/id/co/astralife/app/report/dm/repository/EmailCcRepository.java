package id.co.astralife.app.report.dm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.dm.entity.EmailCc;

import java.util.List;

public interface EmailCcRepository extends JpaRepository<EmailCc, String> {

    @Query(nativeQuery = true)
    List<EmailCc> getEmailCcBySob(String sob);
}
