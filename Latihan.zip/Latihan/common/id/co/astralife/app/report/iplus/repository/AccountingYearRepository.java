package id.co.astralife.app.report.iplus.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.iplus.entity.AccountingYear;

public interface AccountingYearRepository extends JpaRepository<AccountingYear, Long> {
	
	AccountingYear findFirstByEndDate(Date endDate);
}
