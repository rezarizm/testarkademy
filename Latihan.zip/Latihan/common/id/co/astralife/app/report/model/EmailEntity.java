package id.co.astralife.app.report.model;

import java.util.List;

import lombok.Data;

@Data
public class EmailEntity<T> {

	@Data
	public static class AttachmentDetail{
		private String attachmentName;
		private String attachmentPath;
	}
	
	@Data
	public static class ContentDetail{
		private String contentId;
		private String contentPath;
		private String contentType;
	}

	private String subject; 
	private String fromId;

	private List<String> toIds;
	private List<String> ccIds;
	private List<String> bccIds;
	
	private List<AttachmentDetail> attachmentDetails;
	
	private T content;
	private boolean attachmentStatus;
	
	private List<ContentDetail> contentDetails;
	
}
