package id.co.astralife.app.report.model;

import lombok.Data;

import java.util.List;

@Data
public class TemplateFileGroupRelationForm {
    List<String> cssFileGroupId;

    String cssTemplateId;
}
