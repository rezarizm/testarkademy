package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BillingDetailForm {

	private String startDate;
	private String endDate;
	private String billNo;
	private String contractType;
	private String policyNo;
}
