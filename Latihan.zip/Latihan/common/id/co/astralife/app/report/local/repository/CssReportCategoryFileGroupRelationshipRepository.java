package id.co.astralife.app.report.local.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.CssReportCategoryFileGroupRelationship;

public interface CssReportCategoryFileGroupRelationshipRepository extends JpaRepository<CssReportCategoryFileGroupRelationship, String> {	
	CssReportCategoryFileGroupRelationship getCategoryIdByCssFileGroupId(String fileGroupId);
}
