package id.co.astralife.app.report.local.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.UUID;

@Data
@Entity
@Table(name = "CSS_RPORT_FILE_GROUP_ROLE_REL")
public class CssReportFileGroupRoleRelationship implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "ID_REL", nullable = false)
    private UUID idREl;

    @Column(name = "ROLE_ID", nullable = false)
    private UUID roleId;

    @Column(name = "FILE_GROUP_ID", nullable = false)
    private String cssFileGroupId;
}
