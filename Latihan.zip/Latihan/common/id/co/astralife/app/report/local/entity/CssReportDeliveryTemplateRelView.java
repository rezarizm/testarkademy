package id.co.astralife.app.report.local.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.UUID;

@Data
@Entity
@Table(name = "CSS_RPRT_DLIVERY_TMPLATE_REL_V")
public class CssReportDeliveryTemplateRelView implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID_REL", nullable = false)
    private UUID idRel;

    @Column(name = "PARAMETER", nullable = false)
    private String parameter;

    @Column(name = "DELIVERY_GROUP_ID", nullable = false)
    private String cssDeliveryGroupId;

    @Column(name = "DELIVERY_GROUP_NAME")
    private String cssDeliveryGroupName;

    @Column(name = "CRON_EXPRESSION")
    private String cronExpression;

    @Column(name = "TEMPLATE_ID", nullable = false)
    private String cssTemplateId;

    @Column(name = "TEMPLATE_NAME")
    private String cssTemplateName;

    @Column(name = "TEMPLATE_SERVICE_NAME")
    private String cssTemplateServiceName;

    @Column(name = "TEMPLATE_TYPE")
    private String cssTemplateType;

}
