package id.co.astralife.app.report.model;

import java.math.BigDecimal;
import java.util.UUID;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AsoPolicyClaimDTO {

    @JsonProperty("detId")
    private UUID id;

    @JsonProperty("policyNo")
    private String policyNo;

    @JsonProperty("amount")
    private BigDecimal amount;

    @JsonProperty("type")
    private String type;

    @JsonProperty("createBy")
    private String createBy;

    @JsonProperty("createDate")
    private String createDate;
}
