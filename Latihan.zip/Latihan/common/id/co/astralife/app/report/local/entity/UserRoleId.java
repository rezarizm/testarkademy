package id.co.astralife.app.report.local.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.UUID;

/**
 * @author fadil.wiranata
 */
@Data
public class UserRoleId implements Serializable {

    private static final long serialVersionUID = -1736797098102412944L;

    private UUID roleId;

    private UUID userId;
}
