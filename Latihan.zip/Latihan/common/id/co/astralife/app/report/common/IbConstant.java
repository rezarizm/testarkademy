package id.co.astralife.app.report.common;

public class IbConstant {

    public static final String EXPORT_CLAIM = "ExportClaimReport";
    public static final String EXPORT_CLAIM_EMAIL_TO = "EXPORT_CLAIM_EMAIL_TO";
    public static final String START_DATE = "start_date";
    public static final String END_DATE = "end_date";

    public static final String EXPORT_CLAIM_TITLE = "Export Claim Report";
    public static final String EXPORT_CLAIM_REQUEST = "exportClaimRequest";

    public static final String IS_SUCCESS = "success";
    public static final String IS_FAILED = "failed";
    public static final String ERROR_MESSAGE = "errorMessage";

    private IbConstant() {
        throw new IllegalAccessError("Constant Class");
    }
}
