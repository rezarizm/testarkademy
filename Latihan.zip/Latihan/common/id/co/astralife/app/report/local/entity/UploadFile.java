package id.co.astralife.app.report.local.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

@Entity
@Data
@Table(name = "RPT_UPLOAD_FILE")
public class UploadFile implements Serializable {

	private static final long serialVersionUID = 2096210198143215694L;

	@Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "UPL_ID", nullable = false)
    private UUID uploadId;

	@Column(name = "FILE_NAME", nullable = false)
    private String fileName;
	
	@Column(name = "FILE_PATH")
    private String filePath;
    
    @Column(name = "RPT_TYPE")
    private String rptType;
    
    @Column(name = "DESCRIPTION")
    private String desc;
    
    @Column(name = "STATUS")
    private String status;
    
    @Column(name = "IS_SCHEDULER")
    private boolean isScheduler;
    
    @Column(name = "CREATE_BY", nullable = false)
    private String createBy;
    
    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;
}
