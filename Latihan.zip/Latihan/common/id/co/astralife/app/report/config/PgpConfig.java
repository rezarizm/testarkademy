package id.co.astralife.app.report.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import id.co.astralife.app.report.common.util.CryptoService;
import id.co.astralife.app.report.common.util.impl.PGPServiceImpl;

@Configuration
public class PgpConfig {

	@Autowired
	private Environment env;

	@Bean
	public CryptoService pgpServiceConfig() {
		PGPServiceImpl ps = new PGPServiceImpl();
		ps.setTempFolder(env.getProperty("dir.pathTempFolder"));
		return ps;
	}
}
