package id.co.astralife.app.report.local.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.CssReportCategory;

public interface CssReportCategoryRepository extends JpaRepository<CssReportCategory, String> {
    CssReportCategory findCssReportCategoryByCssCategoryId(String cssCategoryId);
}
