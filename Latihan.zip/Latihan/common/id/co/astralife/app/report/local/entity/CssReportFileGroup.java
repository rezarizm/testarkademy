package id.co.astralife.app.report.local.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
@Entity
@Data
@Table(name = "CSS_REPORT_FILE_GROUP")
public class CssReportFileGroup implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "FILE_GROUP_ID", nullable = false)
	private String cssFileGroupId;

	@Column(name = "REPORT_FILE_GROUP")
	private String cssReportFileGroupName;
	
	@Column(name = "VALUE")
	private String cssReportFileGroupValue;
	
	@Column(name = "CATEGORY_ID")
	private String cssCategoryId;
}
