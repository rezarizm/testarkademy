package id.co.astralife.app.report.tango.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.ReportConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries({
	@NamedNativeQuery(name="PremiumRate.findPremiumRate", query="SELECT ROWNUM AS ID, RATE FROM PREMIUM_RATE_TABLE WHERE COMP= ? AND GENDER = ? AND AGE = ? ", resultClass=PremiumRate.class),
})
@Table(name="PREMIUM_RATE_TABLE")
public class PremiumRate {

	
	@Id
	@Column(name="ID")
	private Long ID;
	
	@Column(name="RATE")
	private Float rate;
}
