package id.co.astralife.app.report.local.entity;

import javax.persistence.MappedSuperclass;
import java.io.Serializable;

/**
 * @author fadil.wiranata
 */
@MappedSuperclass
public class BaseEntity implements Serializable {

    private static final long serialVersionUID = -5364731424705067254L;

}
