package id.co.astralife.app.report.local.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

/**
 * @author fadil.wiranata
 */
@Data
@Entity
@IdClass(UserRoleId.class)
@Table(name = "RPT_USER_ROLE")
public class UserRole extends BaseEntity {

    private static final long serialVersionUID = 7982986454187012762L;

    @Id
    @Column(name = "USER_ID")
    private UUID userId;

    @Id
    @Column(name = "ROLE_ID")
    private UUID roleId;

    @Column(name = "CREATE_BY")
    private String createBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;

}
