package id.co.astralife.app.report.mirror.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.mirror.entity.BiReport;

public interface BiReportRepository extends JpaRepository<BiReport, String> {

	@Query(nativeQuery=true)
	List<BiReport> findBiReprintData(String month, String yearMonth);
	
	@Query(nativeQuery=true)
	List<BiReport> findBiPolicyReprintData(String month, String yearMonth, String policyNo);
	
	@Query(nativeQuery=true)
	List<BiReport> findBiData(String month, String yearMonth);
	
	@Query(nativeQuery=true)
	List<BiReport> findBiPolicyData(String month, String yearMonth, String policyNo);
}
