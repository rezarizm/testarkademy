package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssReportFileGroupRptRoleRelationship;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface CssReportFileGroupRptRoleRelationshipRepository extends JpaRepository<CssReportFileGroupRptRoleRelationship, UUID> {

	List<CssReportFileGroupRptRoleRelationship> getFileGroupIdByRoleId(UUID roleId);
	
	List<CssReportFileGroupRptRoleRelationship> getFileGroupIdByCategoryIdAndRoleId(String categoryId, UUID roleId);

    CssReportFileGroupRptRoleRelationship findFileGroupByIdRel(UUID idRel);
}
