package id.co.astralife.app.report.mirror.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.mirror.entity.YerfPeriod;

public interface YerfPeriodRepository extends JpaRepository<YerfPeriod, String> {
	
	@Query(nativeQuery=true)
	YerfPeriod findByChdrNum(String chdrNum);
}
