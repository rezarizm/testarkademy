package id.co.astralife.app.report.common.util.exception;

@SuppressWarnings("serial")
public class CryptoServiceException extends Exception {
	public CryptoServiceException() {
    }

    public CryptoServiceException(String message) {
        super(message);
    }

    public CryptoServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public CryptoServiceException(Throwable cause) {
        super(cause);
    }

    public CryptoServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
