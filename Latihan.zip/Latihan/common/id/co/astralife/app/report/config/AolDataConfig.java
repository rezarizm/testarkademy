package id.co.astralife.app.report.config;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaDialect;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableJpaRepositories(
		basePackages = "id.co.astralife.app.report.aol", 
		entityManagerFactoryRef = "aolEntityManager", 
		transactionManagerRef = "aolTransactionManager")
public class AolDataConfig {

	@Autowired
	private Environment env;

	@Autowired
	@Qualifier("oracleVendorAdapter")
	private JpaVendorAdapter jpaVendorAdapter;

	@Autowired
	@Qualifier("oracleDialect")
	private JpaDialect jpaDialect;

	@Bean
	public DataSource aolDataSource() {
		BasicDataSource ds = new BasicDataSource();
		ds.setDriverClassName(env.getProperty("spring.datasource.driver-class-name"));
		ds.setUrl(env.getProperty("spring.datasource4.url"));
		ds.setUsername(env.getProperty("spring.datasource4.username"));
		ds.setPassword(env.getProperty("spring.datasource4.password"));
		ds.setInitialSize(10);
		ds.setMaxActive(50);
		ds.setMaxIdle(25);
		ds.setValidationQuery("SELECT 1 FROM DUAL");
		return ds;
	}

	@Bean
	public LocalContainerEntityManagerFactoryBean aolEntityManager() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		em.setDataSource(aolDataSource());
		em.setJpaVendorAdapter(jpaVendorAdapter);
		em.setJpaDialect(jpaDialect);
		em.setPackagesToScan("id.co.astralife.app.report.aol");
		return em;
	}

	@Bean
	public PlatformTransactionManager aolTransactionManager() {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(aolEntityManager().getObject());
		return transactionManager;
	}
}
