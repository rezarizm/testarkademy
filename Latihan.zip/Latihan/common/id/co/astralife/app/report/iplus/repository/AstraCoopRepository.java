package id.co.astralife.app.report.iplus.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.iplus.entity.AstraCoop;

public interface AstraCoopRepository extends JpaRepository<AstraCoop, Long>{

	@Query(nativeQuery = true)
	AstraCoop countDataByDate(String dateString);
}
