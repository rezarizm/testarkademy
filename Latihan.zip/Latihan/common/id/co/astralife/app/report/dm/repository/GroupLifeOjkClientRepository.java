package id.co.astralife.app.report.dm.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.dm.entity.GroupLifeOjkClient;

public interface GroupLifeOjkClientRepository extends JpaRepository<GroupLifeOjkClient, String>{

	@Query (nativeQuery = true)
	GroupLifeOjkClient findGroupByPolicyNoAndIsValid(String policyNo, boolean isValid);
	
	@Query (nativeQuery = true)
	GroupLifeOjkClient findLifeByPolicyNoAndIsValid(String policyNo, boolean isValid);

	@Query(value = "select count(*) from odsdta.gagmhdpf "
			+ "where chdrnum = ?1 "
			+ "and dtetrm = 99999999", 
			nativeQuery = true)
	Long countGroupPremiHealthTotalMember(String policyNo);
	
	@Query (nativeQuery = true)
	GroupLifeOjkClient findGroupByPolicyNo(String policyNo);
	
	@Query (nativeQuery = true)
	GroupLifeOjkClient findLifeByPolicyNo(String policyNo);
	
	@Query (value = "select sum(sumins) sumins from odsdta.lfcovrpf " + 
			"where chdrnum = ?1 " + 
			"and validflag = '1'", 
			nativeQuery = true)
	BigDecimal getUpLifeByPolicyNo(String policyNo);
	
	@Query (value = "select sum(suminsu) suminsu from odsdta.gagxhipf " + 
			"where dtetrm = 99999999 " + 
			"and chdrnum = ?1 ",
			nativeQuery = true)
	BigDecimal getUpGroupByPolicyNo(String policyNo);
	
	@Query (value = "select trim(cnttype) cnttype from odsdta.gachdrpf " + 
			" where validflag = '1' " + 
			" and chdrnum = ?1 ",
			nativeQuery = true)
	String getGroupContractTypeByPolicyNo(String policyNo);
}
