package id.co.astralife.app.report.validator;

import id.co.astralife.app.report.validator.annotation.ProviderCode;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ProviderCodeValidator implements ConstraintValidator<ProviderCode, String> {

    @Override
    public void initialize(ProviderCode annotation) {
        //
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
        return  value == null || value.length() == 0 || value.length() == 7 || value.length() == 8;
    }
}
