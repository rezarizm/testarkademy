package id.co.astralife.app.report.dm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.dm.entity.GCPReport;

public interface GCPReportRepository extends JpaRepository<GCPReport, Long>{

	@Query(nativeQuery = true)
	GCPReport countData(String startDate, String endDate);
}
