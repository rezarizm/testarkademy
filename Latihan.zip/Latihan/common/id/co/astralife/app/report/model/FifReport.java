package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author Michael
 *
 */
@Getter
@Setter
public class FifReport {

	private String fileCode;
	private String fileDate;
}
