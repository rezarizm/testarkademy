package id.co.astralife.app.report.dm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.OjkConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries({
		@NamedNativeQuery(name = "GroupLifeOjkClient.findGroupByPolicyNoAndIsValid", query = OjkConstant.GROUP_OJK_CLIENT_QUERY, resultClass = GroupLifeOjkClient.class),
		@NamedNativeQuery(name = "GroupLifeOjkClient.findLifeByPolicyNoAndIsValid", query = OjkConstant.LIFE_OJK_CLIENT_QUERY, resultClass = GroupLifeOjkClient.class),
		@NamedNativeQuery(name = "GroupLifeOjkClient.findGroupByPolicyNo", query = OjkConstant.GROUP_OJK_CLIENT_QUERY_BY_POLNO, resultClass = GroupLifeOjkClient.class),
		@NamedNativeQuery(name = "GroupLifeOjkClient.findLifeByPolicyNo", query = OjkConstant.LIFE_OJK_CLIENT_QUERY_BY_POLNO, resultClass = GroupLifeOjkClient.class)
})
@Table(name = "GACLNTPF")
public class GroupLifeOjkClient implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 957201285959430078L;

	@Id
	@Column(name = "POLICY_NO")
	private String policyNo;

	@Column(name = "ID_NO")
	private String idNumber;

	@Column(name = "DOB")
	private String dob;

	@Column(name = "IS_VALID")
	private boolean isValid;

	@Column(name = "ADDRESS01")
	private String address01;

	@Column(name = "ADDRESS02")
	private String address02;

	@Column(name = "ADDRESS03")
	private String address03;

}
