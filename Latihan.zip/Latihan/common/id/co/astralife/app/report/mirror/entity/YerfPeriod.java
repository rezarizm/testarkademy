package id.co.astralife.app.report.mirror.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.ReportConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries(
        @NamedNativeQuery(name = "YerfPeriod.findByChdrNum", query = ReportConstant.YERF_PERIOD_QUERY, resultClass = YerfPeriod.class)
)
@Table(name = "GAYERFPF")
public class YerfPeriod implements Serializable {
	
	private static final long serialVersionUID = -3993733007008627666L;

	@Id
    @Column(name = "CHDRNUM")
    private String chdrNum;

	@Id
    @Column(name = "CCDATE")
    private Long ccDate;
	
	@Id
    @Column(name = "CRDATE")
    private Long crDate;
}
