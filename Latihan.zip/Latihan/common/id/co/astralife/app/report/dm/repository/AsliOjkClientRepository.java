package id.co.astralife.app.report.dm.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.dm.entity.AsliOjkClient;

public interface AsliOjkClientRepository extends JpaRepository<AsliOjkClient, String>{

	@Query (nativeQuery = true)
	AsliOjkClient findAsliByPolicyNoAndIsValid(String policyNo, boolean isValid);
	
	@Query (nativeQuery = true)
	AsliOjkClient findAsliByPolicyNo(String policyNo);
	
	@Query (value = "select sum(ics.sum_assured) sum_assured from odsdta.ipcontract_structure ics " + 
			"inner join (select pk_contract from odsdta.ipcontract " + 
			"            where contract_no = ?1 " + 
			"            ) ic on ics.fk_contract = ic.pk_contract " + 
			"                    and ics.valid = 1",
			nativeQuery = true)
	BigDecimal getUpAsliByPolicyNo(String policyNo);
	
}
