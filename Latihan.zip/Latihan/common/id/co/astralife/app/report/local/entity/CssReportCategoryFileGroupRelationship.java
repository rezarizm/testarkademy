package id.co.astralife.app.report.local.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@Entity
@Table(name = "CSS_RPRT_CTGORY_FILE_GROUP_REL")
public class CssReportCategoryFileGroupRelationship implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "FILE_GROUP_ID", nullable = false)
	private String cssFileGroupId;

	@Column(name = "REPORT_FILE_GROUP", nullable = false)
	private String cssReportFileGroupName;

	@Column(name = "CATEGORY_ID", nullable = false)
	private String cssCategoryId;

	@Column(name = "CATEGORY_NAME", nullable = false)
	private String cssCategoryName;
}
