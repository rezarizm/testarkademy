package id.co.astralife.app.report.iplus.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.ReportConstant;
import lombok.Data;

@Entity
@Data
@NamedNativeQueries(
		@NamedNativeQuery(name = "Contract.findCountData", query = ReportConstant.SEHAT_PROTEKSIKU_QUERY, resultClass = Contract.class))
@Table(name="CONTRACT")
public class Contract {

	@Id
	@Column(name = "COUNT_DATA")
	private Long countData;

}
