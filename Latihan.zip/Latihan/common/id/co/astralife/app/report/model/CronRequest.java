package id.co.astralife.app.report.model;

import lombok.Data;

/**
 * Created by fadil.wiranata.
 */
@Data
public class CronRequest {

    private String triggerGroup;
    private String triggerName;
    private String cronExpression;
}
