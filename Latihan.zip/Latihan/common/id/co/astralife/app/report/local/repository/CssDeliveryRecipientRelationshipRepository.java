package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssDeliveryRecipientRelationship;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface CssDeliveryRecipientRelationshipRepository extends JpaRepository<CssDeliveryRecipientRelationship, UUID> {
    CssDeliveryRecipientRelationship findDeliveryRecipientByIdRel(UUID idRel);

    List<CssDeliveryRecipientRelationship> findByCssRecipientId(UUID cssRecipientId);

    List<CssDeliveryRecipientRelationship> findRecipientByCssDeliveryGroupId(String cssDeliveryGroupId);
}
