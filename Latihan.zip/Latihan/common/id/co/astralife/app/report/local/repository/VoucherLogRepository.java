package id.co.astralife.app.report.local.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import id.co.astralife.app.report.local.entity.VoucherLog;

public interface VoucherLogRepository extends JpaRepository<VoucherLog, UUID> {

}
