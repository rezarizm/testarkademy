package id.co.astralife.app.report.common.util;

import java.io.File;

import id.co.astralife.app.report.common.util.exception.FTPServiceException;

public interface FTPService {
	void uploadFile(File fileToUpload, String hostDir) throws FTPServiceException;
	
}
