package id.co.astralife.app.report.mirror.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.ReportConstant;
import lombok.Data;

@Data
@Entity
@Table(name="AOL_USER")
@NamedNativeQueries({
	@NamedNativeQuery(name = "AolUserLogin.findAolLoginCount", query = ReportConstant.FIND_AOL_LOGIN_COUNT, resultClass = AolUserLogin.class)
})
public class AolUserLogin implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = 8428287168180367352L;

	@Id
	@Column(name="ID")
	private String id;

	@Column(name="LOGIN_ID")
	private String loginId; 

	@Column(name="SURNAME")
	private String surname; 

	@Column(name="EMAILADD")
	private String email;

	@Column(name="TITLE")
	private String title;

	@Column(name="BRANCH_NAME")
	private String branchName;

	@Column(name="BRANCH_CODE")
	private String branchCode;

	@Column(name="REGIONAL")
	private String regional;

	@Column(name="AREA")
	private String area;

	@Column(name="MONTH")
	private String month;

	@Column(name="YEAR")
	private String year;

	@Column(name="NUMBER_OF_LOGIN")
	private String numberOfLogin;

	@Column(name="LAST_LOGIN_DATE")
	private String lastLoginDate;

	@Column(name="Creation_Date_In_AOL")
	private String creationDateInAol;

}
