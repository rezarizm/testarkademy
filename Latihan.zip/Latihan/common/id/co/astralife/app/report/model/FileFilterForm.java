package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FileFilterForm {
    private String createBy; 
    private String rptId; 
    private String startDate;
    private String endDate;
}
