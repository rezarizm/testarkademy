package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BillingDetailRequest {

	private String user;
	private String billNo = "";
	private String startDate;
	private String endDate;

}
