package id.co.astralife.app.report.mirror.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import id.co.astralife.app.report.common.GroupPolicyConstant;
import lombok.Data;

@Data
@Entity
@NamedNativeQueries({
	@NamedNativeQuery(name = "GroupPolicy.findByDateBetween", query = GroupPolicyConstant.DATA_BY_DATE, resultClass = GroupPolicy.class),
	@NamedNativeQuery(name = "GroupPolicy.findByPolicyNoAndTranNo", query = GroupPolicyConstant.DATA_BY_POLICY, resultClass = GroupPolicy.class),
	@NamedNativeQuery(name = "GroupPolicy.findForNextRow", query = GroupPolicyConstant.GET_NEXT_ROW, resultClass = GroupPolicy.class),
	@NamedNativeQuery(name = "GroupPolicy.findCheckReversed", query = GroupPolicyConstant.CHECK_REVERSED, resultClass = GroupPolicy.class)
})
@Table(name = "GAGIDTPF")
public class GroupPolicy implements Serializable{

	private static final long serialVersionUID = -152661876967760172L;

	@Id
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "POLICY_NO")
	private String policyNo;
	
	@Column(name = "TRAN_NO")
	private String tranNo;
	
	@Column(name = "ISSUED_DATE")
	private String issDate;
	
	@Column(name = "EFF_DATE")
	private String effDate;
	
	@Column(name = "CNT_TYPE")
	private String cntType;
	
	@Column(name = "BATC_CODE")
	private String batcCode;
	
}
