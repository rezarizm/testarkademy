package id.co.astralife.app.report.mirror.repository;

import id.co.astralife.app.report.mirror.entity.GroupGIDT;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author fadil.wiranata
 */
public interface GroupGIDTRepository extends JpaRepository<GroupGIDT, String> {

    public GroupGIDT findByChdrNumAndTranNo(String chdrNum, String tranNo);

    public String maxIssDateByChdrNum(String chdrNum);
}
