package id.co.astralife.app.report.model;

import id.co.astralife.app.report.validator.annotation.DependentNo;
import id.co.astralife.app.report.validator.annotation.MemberNo;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * Created by fadil.wiranata.
 */
@Data
@NoArgsConstructor
public class GroupCertificateForm {

    @NotNull
    private String policyType;

    @NotNull
    @Size(min = 8, max = 8)
    private String policyNo;

    @MemberNo
    private String memberNo;

    @DependentNo
    private String dependentNo;

    private Boolean duplicate;
}
