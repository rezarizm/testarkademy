package id.co.astralife.app.report.local.entity;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;

import java.util.*;

/**
 * @author fadil.wiranata
 */
@Data
@Entity
@Table(name = "RPT_USER")
public class User extends BaseEntity implements UserDetails {

    private static final long serialVersionUID = 5395643850656160555L;

    @Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "USER_ID", nullable = false)
    private UUID userId;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "LOGIN_ID")
    private String loginId;

    @Transient
    @Setter(AccessLevel.NONE)
    private String password;

    @Column(name = "LOGIN_FAILURE")
    private Long loginFailure;

    @Column(name = "LAST_LOGIN_DATE")
    private Date lastLoginDate;

    @Column(name = "LAST_LOGOUT_DATE")
    private Date lastLogoutDate;

    @Column(name = "CREATE_BY")
    private String createBy;

    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(name = "RPT_USER_ROLE",
        joinColumns = {@JoinColumn(name = "USER_ID", nullable = false, updatable = false)},
        inverseJoinColumns = {@JoinColumn(name = "ROLE_ID", nullable = false, updatable = false)}
    )
    private List<Role> roles = new ArrayList<>();

    @Transient
    private List<GrantedAuthority> authorities;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @Fetch(FetchMode.SUBSELECT)
    @JoinColumns({
            @JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID", updatable = false, insertable = true)})
    private List<UserRole> userRole = new ArrayList<>();

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;

    @Override
    public String getUsername() {
        return loginId;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return ("A").equals(status);
    }
}
