package id.co.astralife.app.report.local.repository;

import id.co.astralife.app.report.local.entity.CssReportFileGroupAndTemplateRelationship;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface CssReportFileGroupAndTemplateRelationshipRepository extends JpaRepository<CssReportFileGroupAndTemplateRelationship, UUID>{

	List<CssReportFileGroupAndTemplateRelationship> getTemplatesByFileGroupId(String fileGroupId);

}
