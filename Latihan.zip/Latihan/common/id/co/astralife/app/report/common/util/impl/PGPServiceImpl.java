package id.co.astralife.app.report.common.util.impl;

import id.co.astralife.app.report.common.util.CryptoService;
import id.co.astralife.app.report.common.util.exception.CryptoServiceException;
import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.*;
import org.bouncycastle.openpgp.jcajce.JcaPGPObjectFactory;
import org.bouncycastle.openpgp.jcajce.JcaPGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.jcajce.JcaPGPSecretKeyRingCollection;
import org.bouncycastle.openpgp.operator.PBESecretKeyDecryptor;
import org.bouncycastle.openpgp.operator.PGPDigestCalculatorProvider;
import org.bouncycastle.openpgp.operator.PublicKeyDataDecryptorFactory;
import org.bouncycastle.openpgp.operator.jcajce.*;
import org.bouncycastle.util.io.Streams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Files;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;

public class PGPServiceImpl implements CryptoService {
    private static Logger logger = LoggerFactory.getLogger(PGPServiceImpl.class.getName());

    private String tempFolder;

    public PGPServiceImpl() {
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
    }

    static PGPPublicKey getPublicKey(String armoredString) throws CryptoServiceException, IOException, PGPException {

        InputStream in = new ByteArrayInputStream(armoredString.getBytes());
        in = org.bouncycastle.openpgp.PGPUtil.getDecoderStream(in);

        JcaPGPPublicKeyRingCollection pgpPub = new JcaPGPPublicKeyRingCollection(in);
        in.close();

        PGPPublicKey key = null;
        Iterator<PGPPublicKeyRing> rIt = pgpPub.getKeyRings();
        while (key == null && rIt.hasNext()) {
            PGPPublicKeyRing kRing = rIt.next();
            Iterator<PGPPublicKey> kIt = kRing.getPublicKeys();
            while (key == null && kIt.hasNext()) {
                PGPPublicKey k = kIt.next();

                if (k.isEncryptionKey()) {
                    key = k;
                }
            }
        }
        return key;
    }

    static PGPPrivateKey getPrivateKey(String armoredString, String passphrase) throws CryptoServiceException, IOException, PGPException {

        PGPPrivateKey returnedPrivateKey = null;

        InputStream in = new ByteArrayInputStream(armoredString.getBytes());
        in = org.bouncycastle.openpgp.PGPUtil.getDecoderStream(in);

        JcaPGPSecretKeyRingCollection pgpPub = new JcaPGPSecretKeyRingCollection(in);
        in.close();

        PGPDigestCalculatorProvider digestCalc = new JcaPGPDigestCalculatorProviderBuilder().build();

        Provider provider = new BouncyCastleProvider();
        PBESecretKeyDecryptor decryptor = new JcePBESecretKeyDecryptorBuilder(digestCalc)
                .setProvider(provider)
                .build(passphrase.toCharArray());

        PGPPrivateKey key = null;
        Iterator<PGPSecretKeyRing> rIt = pgpPub.getKeyRings();
        while (key == null && rIt.hasNext()) {

            PGPSecretKeyRing kRing = rIt.next();
            PGPSecretKey sec = kRing.getSecretKey();

            Iterator<PGPSecretKey> kIt = kRing.getSecretKeys();
            while (key == null && kIt.hasNext()) {
                PGPSecretKey k = kIt.next();


                if (k.isMasterKey()) {
                    key = sec.extractPrivateKey(decryptor);
                }
            }
        }

        return key;
    }


    @Override
    public byte[] encrypt(byte[] data, String publicKey) throws CryptoServiceException {
        ByteArrayOutputStream bOut = new ByteArrayOutputStream();
        PGPLiteralDataGenerator lData = new PGPLiteralDataGenerator();

        OutputStream pOut = null;
        try {
            pOut = lData.open(bOut,
                    PGPLiteralData.BINARY,
                    PGPLiteralData.CONSOLE,
                    data.length,
                    new Date());
            pOut.write(data);
            pOut.close();
        } catch (IOException e) {
            throw new CryptoServiceException(e);
        } finally {
            if (pOut != null)
                try {
                    pOut.close();
                } catch (IOException e) {
                    throw new CryptoServiceException(e);
                }
        }

        ByteArrayOutputStream encOut = new ByteArrayOutputStream();
        OutputStream cOut = null;
        try {
            byte[] plainText = bOut.toByteArray();


            PGPEncryptedDataGenerator encGen = new PGPEncryptedDataGenerator(
                    new JcePGPDataEncryptorBuilder(SymmetricKeyAlgorithmTags.AES_256)
                            .setWithIntegrityPacket(true)
                            .setSecureRandom(new SecureRandom())
                            .setProvider("BC"));

            PGPPublicKey pgpPublicKey = getPublicKey(publicKey);
            encGen.addMethod(new JcePublicKeyKeyEncryptionMethodGenerator(pgpPublicKey).setProvider("BC"));

            cOut = encGen.open(encOut, plainText.length);
            cOut.write(plainText);
        } catch (CryptoServiceException | IOException | PGPException e) {
            throw new SecurityException(e);
        } finally {
            if (cOut != null)
                try {
                    cOut.close();
                } catch (IOException e) {
                    throw new CryptoServiceException(e);
                }
        }

        return encOut.toByteArray();
    }

    @Override
    public void encrypt(File plainFile, File chiperFileDestination, String publicKey) throws CryptoServiceException {

        logger.info("Starting pgp encryption " + plainFile.toPath().toString());
        logger.info("Plain file size: " + plainFile.length());

        Date dateNow = new Date();

        File tmpFolder = new File(this.tempFolder);
        if (!tmpFolder.isDirectory()) {
            tmpFolder.mkdirs();
        }

        String stagingTmpFileName = this.tempFolder + File.separator + "stagingTmpFilePgp_" + dateNow.getTime() + ".tmp";
        File stagingTmpFile = new File(stagingTmpFileName);

        FileOutputStream bOut = null;
        PGPLiteralDataGenerator lData = new PGPLiteralDataGenerator();

        OutputStream pOut = null;
        try {
            stagingTmpFile.createNewFile();
            bOut = new FileOutputStream(stagingTmpFile);

            pOut = lData.open(bOut,
                    PGPLiteralData.BINARY,
                    PGPLiteralData.CONSOLE,
                    plainFile.length(),
                    dateNow);
            Files.copy(plainFile.toPath(), pOut);
            //pOut.write(Files.readAllBytes(plainFile.toPath()));
        } catch (IOException e) {
            throw new CryptoServiceException(e);
        } finally {
            if (pOut != null)
                try {
                    pOut.close();
                    bOut.close();
                } catch (IOException e) {
                    throw new CryptoServiceException(e);
                }
        }

        OutputStream cOut = null;
        FileOutputStream encOut = null;
        RandomAccessFile rafStg = null;
        PGPEncryptedDataGenerator encGen = null;
        try {

            encOut = new FileOutputStream(chiperFileDestination);

            encGen = new PGPEncryptedDataGenerator(
                    new JcePGPDataEncryptorBuilder(SymmetricKeyAlgorithmTags.AES_256)
                            .setWithIntegrityPacket(true)
                            .setSecureRandom(new SecureRandom())
                            .setProvider("BC"));

            PGPPublicKey pgpPublicKey = getPublicKey(publicKey);
            encGen.addMethod(new JcePublicKeyKeyEncryptionMethodGenerator(pgpPublicKey).setProvider("BC"));


            cOut = encGen.open(encOut, stagingTmpFile.length());

            {

                rafStg = new RandomAccessFile(stagingTmpFile, "r");
                final int bufferSize = 1048576;
                boolean continued = true;
                long cycle = 0;

                while (continued) {
                    byte[] buffer = new byte[bufferSize];

                    rafStg.seek(cycle * bufferSize);
                    int numberOfReadBytes = rafStg.read(buffer, 0, bufferSize);

                    if (numberOfReadBytes < bufferSize) {
                        continued = false;

                        byte[] newBuffer = new byte[numberOfReadBytes];
                        newBuffer = Arrays.copyOf(buffer, newBuffer.length);

                        buffer = newBuffer;
                    }

                    cOut.write(buffer);
                    cycle++;
                }
            }


        } catch (CryptoServiceException | IOException | PGPException e) {
            throw new CryptoServiceException(e);
        } finally {
            try {
                if (encGen != null)
                    encGen.close();

                if (cOut != null)
                    cOut.flush();
                    cOut.close();

                if (encOut != null)
                    encOut.flush();
                    encOut.close();

                if (rafStg != null)
                    rafStg.close();

                if (stagingTmpFile.delete()) {
                    logger.info(stagingTmpFile.getName() + " is deleted!");
                } else {
                    logger.info(stagingTmpFile.getName() + " failed to delete");
                }

            } catch (IOException e) {
                throw new CryptoServiceException(e);
            }
        }
        logger.info("Chiper text size: " + chiperFileDestination.length());
    }

    @Override
    public byte[] decrypt(byte[] plainText, String privateKeyString, String passPhrase) throws CryptoServiceException {
        PGPObjectFactory pgpFact = new JcaPGPObjectFactory(plainText);

        try {
            PGPEncryptedDataList encList = null;
            encList = (PGPEncryptedDataList) pgpFact.nextObject();

            PGPPublicKeyEncryptedData encData = (PGPPublicKeyEncryptedData) encList.get(0);

            PGPPrivateKey privateKey = getPrivateKey(privateKeyString, passPhrase);
            PublicKeyDataDecryptorFactory dataDecryptorFactory = new JcePublicKeyDataDecryptorFactoryBuilder().setProvider("BC").build(privateKey);

            InputStream clear = encData.getDataStream(dataDecryptorFactory);

            byte[] literalData = Streams.readAll(clear);

            if (encData.verify()) {
                PGPObjectFactory litFact = new JcaPGPObjectFactory(literalData);
                PGPLiteralData litData = (PGPLiteralData) litFact.nextObject();

                byte[] data = Streams.readAll(litData.getInputStream());

                return data;
            }
        } catch (Exception e) {
            throw new CryptoServiceException(e.getMessage(), e);
        }

        throw new IllegalStateException("modification check failed");

    }

    @Override
    public void decrypt(File chiperFile, File plainFileDestination, String publicKey, String passPhrase) throws CryptoServiceException {

    }

    public String getTempFolder() {
        return tempFolder;
    }

    public void setTempFolder(String tempFolder) {
        this.tempFolder = tempFolder;
    }
}
