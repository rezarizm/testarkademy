package id.co.astralife.app.report.model;

import id.co.astralife.app.report.validator.annotation.DependentNo;
import id.co.astralife.app.report.validator.annotation.MemberNo;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Getter
@Setter
public class OperationReportForm {

    @NotNull
    private String policyType;

    @NotNull
    @Size(min = 8, max = 8)
    private String policyNo;

    @MemberNo
    private String memberNo;

    @DependentNo
    private String dependentNo;

    private String issuedDate;
    
    private Boolean duplicate;

    private Boolean subsidiary;
    
    @NotNull
    private String effDate;
    
    @NotNull
    private String trDate;
    
    private String month;
    
    private String yearMonth;
}
