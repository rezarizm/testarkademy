package id.co.astralife.app.report.iplus.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Entity
@Data
@Table (name = "VW_NTU_JOB_MONITOR")
public class NtuJobMonitor {
	
	@Id
	@Column(name = "PK_JOB_MONITOR")
	private Long jobMonitorId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "START_TIME")
	private Date startTime;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "END_TIME")
	private Date endTime;
	
	@Column(name = "DURATION")
	private Long duration;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "REMARK")
	private String remark;

}
