package id.co.astralife.app.report.local.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "RPT_EXREPRSH_LOG")
public class ExreprshLog {
	
	@Id
	@SequenceGenerator(name = "SEQ_EXREPRSH", allocationSize = 1, sequenceName = "SEQ_EXREPRSH")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_EXREPRSH")
    @Column(name = "LOG_ID", nullable = false)
    Long logId;
	
    @Column(name = "POLICY_NO")
    private String policyNo;

    @Column(name = "CCDATE")
    private Long ccDate;
	
    @Column(name = "CRDATE")
    private Long crDate;
    
    @Column(name = "CREATED_AT")
    private Date createdAt;
}
