package id.co.astralife.app.report.dm.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@Entity
@Table(name = "CSS_MAPPING_CHANNEL")
public class CssReportTargetChannel implements Serializable {

    private static final long serialVersionUID = 7383561406331789766L;

    @Column(name = "SOB")
    private String sob;

    @Id
    @Column(name = "PRODUCT")
    private String product;

    @Column(name = "CHANNEL")
    private String channel;

    @Column(name = "PRODUCT_NAME")
    private String productName;

    @Column(name = "PARTNER")
    private String partner;

    @Column(name = "CORE")
    private String core;

}
