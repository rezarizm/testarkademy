package id.co.astralife.app.report.eb.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;

@Data
@Entity
@Table(name = "CLAIM_SUBMISSIONS")
public class ClaimSubmissions implements Serializable {

   private static final long serialVersionUID = 3801973823357149208L;

   @Id
   @Column(name = "REFERENCE_NO")
   private String referenceNo;

   @Column(name = "POLICY_NO")
   private String policyNo;

   @Column(name = "MEMBER_NO")
   private String memberNo;

   @Column(name = "BENEFIT_TYPE")
   private String benefitType;

   @Column(name = "TREATMENT_PLACE")
   private String treatmentPlace;

   @Column(name = "INVOICE_DATE")
   private Date invoiceDate;

   @Column(name = "TOTAL_INVOICE_AMOUNT")
   private BigInteger totalInvoiceAmount;

   @Column(name = "EXPORTED")
   private Long exported;

   @Column(name = "EXPORT_FILE_ID")
   private UUID exportFileId;

   @Temporal(TemporalType.TIMESTAMP)
   @Column(name = "SUBMITTED_AT")
   private Date submittedAt;

   @Column(name = "SESSION_ID")
   private String sessionId;
   
   @Column(name = "CLAIM_NO")
   private String claimNo;
   
   @Column(name = "CLAIM_TYPE")
   private String claimType;
   
   @Column(name = "MEMBER_NAME")
   private String memberName;
   
}