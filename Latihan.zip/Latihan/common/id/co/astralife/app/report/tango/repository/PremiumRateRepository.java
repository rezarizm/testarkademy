package id.co.astralife.app.report.tango.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.tango.entity.PremiumRate;

public interface PremiumRateRepository extends JpaRepository<PremiumRate, Long> {

	@Query(nativeQuery=true)
	PremiumRate findPremiumRate(String comp, String gender, Integer age);
}
