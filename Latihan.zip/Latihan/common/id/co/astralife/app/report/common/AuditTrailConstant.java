package id.co.astralife.app.report.common;

public class AuditTrailConstant {

    public static final Integer STATUS_SUCCESS = 0;
    public static final Integer STATUS_FAILED = 1;

    public static final String TRANSACTION_TYPE_LOGIN = "LOGIN";
    public static final String TRANSACTION_TYPE_VIEW = "VIEW";
    public static final String TRANSACTION_TYPE_GENERATE = "GENERATE";

    private AuditTrailConstant() {
        throw new IllegalAccessError("Constant Class");
    }
}
