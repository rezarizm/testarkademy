package id.co.astralife.app.report.local.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@Entity
@Table(name = "CSS_REPORT_DELIVERY_GROUP")
public class CssReportDeliveryGroup implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
    @Id
    @Column(name = "DELIVERY_GROUP_ID", nullable = false)
    private String cssDeliveryGroupId;

    @Column(name = "DELIVERY_GROUP_NAME", nullable = false)
    private String cssDeliveryGroupName;

    @Column(name = "CRON_EXPRESSION", nullable = false)
    private String cronExpression;
}