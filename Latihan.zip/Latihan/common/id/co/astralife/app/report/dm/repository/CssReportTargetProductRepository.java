package id.co.astralife.app.report.dm.repository;

import id.co.astralife.app.report.dm.entity.CssReportTargetProduct;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CssReportTargetProductRepository  extends JpaRepository<CssReportTargetProduct, String> {
}
