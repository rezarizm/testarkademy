package id.co.astralife.app.report.common;

/**
 * @author fadil.wiranata
 */
public class FinanceConstant {

    public static final String PREMIUM_SUMMARY = "SummaryPremiumBr";
    public static final String PREMIUM_DETAIL = "DetailPremium";
    public static final String PREMIUM_DETAIL_IA_DI = "DetailPremiumIaDi";
    public static final String EXCESS_SUMMARY = "SummaryExcessBr";
    public static final String EXCESS_DETAIL = "DetailExcess";
    public static final String PRODUCTION = "Production";
    public static final String PRODUCTION_PDF = "ProductionPdf";
    public static final String PERSISTENCY = "Persistency";
    public static final String VAT = "VatOnCommision";
    public static final String VAT_XLS = "VatOnCommisionXls";
    public static final String CASH_RECEIPT_PDF = "CashReceiptPdf";
    public static final String CASH_RECEIPT_XLS = "CashReceiptXls";
    public static final String CASH_PAYMENT_PDF = "CashPaymentPdf";
    public static final String CASH_PAYMENT_XLS = "CashPaymentXls";
    public static final String DAILY_REPORT_IPRIME_KHUSUS = "DailyReportiPrimeKhusus";
    public static final String MASTER_AGENT_AFC = "MasterAgentAFC";

    public static final String PARAM_CURRENCY = "bill_curr";
    public static final String PARAM_SOURCE = "src_code";
    public static final String PARAM_START_DATE = "startdate";
    public static final String PARAM_END_DATE = "enddate";
    public static final String PARAM_STCB = "stcb";
    public static final String PARAM_YEARS = "years";
    public static final String PARAM_START_MONTH = "startmonth";
    public static final String PARAM_END_MONTH = "endmonth";
    public static final String PARAM_MONTH = "month";
    public static final String PARAM_TRANS_DATE = "trans_date";

    public static final String TAX_AMNESTY_EMAIL = "TAX_AMNESTY_EMAIL";
    
    private FinanceConstant() {
        throw new IllegalAccessError("Constant Class");
    }
}
