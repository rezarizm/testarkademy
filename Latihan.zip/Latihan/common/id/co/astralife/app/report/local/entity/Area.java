package id.co.astralife.app.report.local.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

@Data
@Entity
@Table(name = "RPT_AREA")
public class Area implements Serializable {

	private static final long serialVersionUID = 7260924864952055034L;

	@Id
	@Column(name = "AREA_CODE")
	private String areaCode;

	@Column(name = "CITY")
	private String city;
	
	@Column(name = "PROVINCE")
	private String province;
	
	@Column(name = "CREATE_BY", nullable = false)
    private String createBy;
    
    @Column(name = "MODIFY_BY")
    private String modifyBy;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Setter(AccessLevel.NONE)
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFY_DATE")
    private Date modifyDate;
}
