package id.co.astralife.app.report.model;

import id.co.astralife.app.report.validator.annotation.ClaimNo;
import id.co.astralife.app.report.validator.annotation.OccurrenceNo;
import id.co.astralife.app.report.validator.annotation.ProviderCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ClaimReportForm {

	@ClaimNo
	private String claimNo;
	
	@OccurrenceNo
	private String occNo;

	@ProviderCode
	private String provorg;
	
	private String startDate;
	
	private String endDate;
	
	private Boolean duplicate;
	
	private Boolean email;
	
	private String type;

	private String user;

	private String authDate;
}
