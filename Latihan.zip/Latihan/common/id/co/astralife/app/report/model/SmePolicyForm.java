package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SmePolicyForm {

	String policyNo;
	String tranNo;
	String startDate;
	String endDate;
	Boolean duplicate;
	String type;
}
