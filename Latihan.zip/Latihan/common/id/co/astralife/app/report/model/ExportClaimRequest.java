package id.co.astralife.app.report.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExportClaimRequest {

    private String startDate;
    private String endDate;
    private String user;
    private boolean send;
}
