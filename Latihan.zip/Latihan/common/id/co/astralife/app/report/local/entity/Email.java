package id.co.astralife.app.report.local.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

@Data
@Entity
@Table (name= "RPT_EMAIL")
public class Email implements Serializable {
	
	private static final long serialVersionUID = 7677626325796819930L;

	@Id
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @GeneratedValue(generator = "uuid")
    @Column(name = "EMAIL_ID", nullable = false)
	private UUID emailId;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "YGEMAIL")
	private String ygEmail;
	
	@Column(name = "FROM_ID")
	private String fromId;
	
	@Column(name = "TO_ID")
	private String toId;
	
	@Column(name = "CC_ID")
	private String ccId;
	
	@Column(name = "BCC_ID")
	private String bccId;
	
	@Column(name = "SUBJECT")
	private String subject;
	
	@Column(name = "CONTENT")
	private String content;
	
	@Column(name = "ATTACH_NAME")
	private String attachName;
	
	@Column(name = "ATTACH_PATH")
	private String attachPath;
	
	@Column(name = "CONTENT_ID")
	private String contentId;
	
	@Column(name = "CONTENT_PATH")
	private String contentPath;
	
	@Column(name = "CONTENT_TYPE")
	private String contentType;
	
	@Column(name = "CREATE_BY")
	private String createBy;
	
	@Column(name = "RPT_ID")
	private UUID reportId;
	
	@Setter(AccessLevel.NONE)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATE")
	private Date createDate;
	
	@Column(name = "MODIFY_BY")
	private String modifyBy;
	
	@Setter(AccessLevel.NONE)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "MODIFY_DATE")
	private Date modifyDate;
	
}
