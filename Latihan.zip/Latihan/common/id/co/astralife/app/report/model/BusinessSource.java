package id.co.astralife.app.report.model;

/**
 * @author fadil.wiranata
 */
public enum BusinessSource {

    BR("BR"), IA("IA"), DI("DI");

    private final String name;

    BusinessSource(final String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
