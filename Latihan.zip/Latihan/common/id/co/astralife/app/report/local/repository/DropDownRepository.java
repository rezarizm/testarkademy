package id.co.astralife.app.report.local.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import id.co.astralife.app.report.local.entity.DropDown;
import id.co.astralife.app.report.local.enumeration.DropDownGroup;

/**
 * {@link DropDown} repository.
 *
 * @since 22 Mei 2017
 * @version 1.0
 * @author sayid.sidqi
 */
public interface DropDownRepository extends JpaRepository<DropDown, UUID> {
	
	public List<DropDown> findAllByGroup(DropDownGroup group);

	List<DropDown> findAllByGroupOrderByDescriptionAsc(DropDownGroup group);
	
	@Query(nativeQuery = true)
	List<DropDown> findAllByGroupAndUserNameOrderByDescription(String group, String userName);
	
}
