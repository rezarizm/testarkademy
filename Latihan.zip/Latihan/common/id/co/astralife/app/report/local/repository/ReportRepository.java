package id.co.astralife.app.report.local.repository;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import id.co.astralife.app.report.local.entity.Report;

public interface ReportRepository extends JpaRepository<Report, String>{

	Report findByReportId (UUID reportId);
	
	Report findByRptName (String rtpName);
	
	Report findByTemplate (String template);

	List<Report> findBySchedule(String schedule);
	
	@Query( "select rep from Report rep where "+
            " rep.reportId in ( "+
            "  select rr.rptId from ReportRole rr "+
            "  where rr.roleId in ( "+
            "    select ur.roleId from UserRole ur "+
            "    where ur.userId = ( "+
            "      select u.userId from User u where u.loginId = :userName "+
            "    ) "+
            "  ) "+
            ") order by rep.rptDesc asc ")
    List<Report> findByUserName(@Param("userName") String userName);
	
	List<Report> findByRptNameIn(Set<String> rptNames);	
}
